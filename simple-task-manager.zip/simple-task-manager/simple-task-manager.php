<?php
/**
 * Plugin Name: Simple Task Management
 * Plugin URI:  https://amandubey.com
 * Description: A task management plugin for WordPress admin with assignment, rewards, and role-based access.
 * Version:     1.8.23
 * Author:      Aman Dubey
 * License:     GPL-2.0-or-later
 * Text Domain: simple-task-management
 */

if (! defined('ABSPATH')) {
    exit;
}

final class STM_Simple_Task_Management {
    const VERSION           = '1.8.23';
    const OPTION_SETTINGS   = 'stm_settings';
    const OPTION_DB_VERSION = 'stm_db_version';
    const USER_POINTS_META  = 'stm_reward_points';

    public static function init() {
        register_activation_hook(__FILE__, array(__CLASS__, 'activate'));

        add_action('admin_init', array(__CLASS__, 'maybe_upgrade'));
        add_action('admin_init', array(__CLASS__, 'maybe_restrict_dashboard_access'));
        add_action('admin_menu', array(__CLASS__, 'register_admin_menu'));
        add_shortcode('stm_frontend_dashboard', array(__CLASS__, 'render_frontend_dashboard_shortcode'));
        add_filter('login_redirect', array(__CLASS__, 'filter_login_redirect'), 10, 3);
        add_filter('logout_redirect', array(__CLASS__, 'filter_logout_redirect'), 10, 3);
        add_action('rest_api_init', array(__CLASS__, 'register_rest_routes'));

        add_action('admin_post_stm_save_task', array(__CLASS__, 'handle_save_task'));
        add_action('admin_post_stm_delete_task', array(__CLASS__, 'handle_delete_task'));
        add_action('admin_post_stm_update_status', array(__CLASS__, 'handle_update_status'));
        add_action('admin_post_stm_save_settings', array(__CLASS__, 'handle_save_settings'));
        add_action('admin_post_stm_manage_leaderboard', array(__CLASS__, 'handle_manage_leaderboard'));
        add_action('admin_post_stm_task_data_tools', array(__CLASS__, 'handle_task_data_tools'));
        add_action('admin_post_stm_submit_overdue_reason', array(__CLASS__, 'handle_submit_overdue_reason'));
        add_action('admin_post_stm_review_overdue_reason', array(__CLASS__, 'handle_review_overdue_reason'));
    }

    public static function activate() {
        self::run_db_migration();
        self::ensure_default_settings();
    }

    public static function maybe_upgrade() {
        $stored_version = get_option(self::OPTION_DB_VERSION, '0.0.0');

        if (version_compare((string) $stored_version, self::VERSION, '<')) {
            self::run_db_migration();
            self::ensure_default_settings();
        }
    }

    private static function run_db_migration() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $tasks_table      = self::table_name();
        $logs_table       = self::reward_log_table_name();
        $charset_collate  = $wpdb->get_charset_collate();

        $sql_tasks = "CREATE TABLE {$tasks_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(255) NOT NULL,
            description TEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'todo',
            priority VARCHAR(20) NOT NULL DEFAULT 'medium',
            due_date DATE NULL,
            reward_points INT UNSIGNED NOT NULL DEFAULT 0,
            assigned_to BIGINT UNSIGNED NULL,
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            completed_at DATETIME NULL,
            overdue_reason TEXT NULL,
            overdue_status VARCHAR(20) NOT NULL DEFAULT 'none',
            overdue_submitted_at DATETIME NULL,
            overdue_reviewed_by BIGINT UNSIGNED NULL,
            overdue_reviewed_at DATETIME NULL,
            overdue_review_note TEXT NULL,
            PRIMARY KEY (id),
            KEY status (status),
            KEY priority (priority),
            KEY due_date (due_date),
            KEY overdue_status (overdue_status),
            KEY assigned_to (assigned_to),
            KEY created_by (created_by)
        ) {$charset_collate};";

        $sql_logs = "CREATE TABLE {$logs_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            task_id BIGINT UNSIGNED NOT NULL,
            points INT UNSIGNED NOT NULL,
            event VARCHAR(30) NOT NULL DEFAULT 'completion',
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY task_id (task_id),
            KEY event (event)
        ) {$charset_collate};";

        dbDelta($sql_tasks);
        dbDelta($sql_logs);

        update_option(self::OPTION_DB_VERSION, self::VERSION);
    }

    private static function table_name() {
        global $wpdb;

        return $wpdb->prefix . 'stm_tasks';
    }

    private static function reward_log_table_name() {
        global $wpdb;

        return $wpdb->prefix . 'stm_reward_logs';
    }

    private static function default_settings() {
        return array(
            'access_roles'      => array('administrator', 'editor'),
            'settings_roles'    => array('administrator', 'editor'),
            'frontend_roles'    => array('administrator', 'editor'),
            'frontend_enabled'  => 0,
            'frontend_page_id'  => 0,
            'frontend_redirect' => 0,
            'frontend_tasks_home_url' => '',
            'frontend_login_url' => '',
            'frontend_login_redirect_param' => 'redirect_to',
            'frontend_logout_redirect_url' => '',
            'guest_login_title' => 'Please Log In To View Tasks',
            'guest_login_subtitle' => 'Access your task dashboard, track progress, and check reward points after signing in.',
            'guest_login_button_text' => 'Login To Continue',
            'guest_login_note' => 'Need access? Contact your administrator for task dashboard permissions.',
            'guest_login_button_color_start' => '#2563eb',
            'guest_login_button_color_end' => '#4f46e5',
            'guest_login_button_text_color' => '#ffffff',
            'guest_login_button_radius' => 12,
            'dashboard_title'   => 'Daily Taks',
            'frontend_force_tasks_only' => 1,
            'employee_own_tasks_only' => 1,
            'admin_employee_filter_enabled' => 1,
            'auto_refresh_enabled'  => 0,
            'auto_refresh_frontend' => 1,
            'auto_refresh_backend'  => 1,
            'auto_refresh_user_scope' => 'all',
            'auto_refresh_only_visible' => 1,
            'auto_refresh_interval' => 60,
            'tasks_per_page' => 10,
            'slack_enabled' => 0,
            'slack_signing_secret' => '',
            'slack_bot_token' => '',
            'slack_channel_id' => '',
            'slack_notify_on_assign' => 1,
            'slack_notify_on_assign_dm' => 1,
            'slack_allow_create_from_command' => 1,
            'slack_user_map' => array(),
            'visibility'        => 'all',
            'default_status'    => 'todo',
            'default_priority'  => 'medium',
            'require_due_date'  => 0,
            'allow_user_edit'   => 0,
            'allow_user_delete' => 0,
            'rewards_enabled'   => 1,
            'reward_low'        => 5,
            'reward_medium'     => 10,
            'reward_high'       => 20,
            'reward_award_mode' => 'once',
        );
    }

    private static function ensure_default_settings() {
        $current = get_option(self::OPTION_SETTINGS, array());
        if (! is_array($current)) {
            $current = array();
        }

        $merged = wp_parse_args($current, self::default_settings());
        update_option(self::OPTION_SETTINGS, self::sanitize_settings($merged));
    }

    private static function get_settings() {
        $saved = get_option(self::OPTION_SETTINGS, array());
        if (! is_array($saved)) {
            $saved = array();
        }

        return self::sanitize_settings(wp_parse_args($saved, self::default_settings()));
    }

    private static function sanitize_settings($settings) {
        $roles = array_keys(self::available_roles());

        $access_roles = isset($settings['access_roles']) && is_array($settings['access_roles']) ? array_map('sanitize_key', $settings['access_roles']) : array();
        $access_roles = array_values(array_intersect($access_roles, $roles));
        if (empty($access_roles)) {
            $access_roles = array('administrator', 'editor');
        }

        $settings_roles = isset($settings['settings_roles']) && is_array($settings['settings_roles']) ? array_map('sanitize_key', $settings['settings_roles']) : array();
        $settings_roles = array_values(array_intersect($settings_roles, $roles));
        if (empty($settings_roles)) {
            $settings_roles = array('administrator', 'editor');
        }

        $frontend_roles = isset($settings['frontend_roles']) && is_array($settings['frontend_roles']) ? array_map('sanitize_key', $settings['frontend_roles']) : array();
        $frontend_roles = array_values(array_intersect($frontend_roles, $roles));
        if (empty($frontend_roles)) {
            $frontend_roles = $access_roles;
        }

        $visibility = isset($settings['visibility']) ? sanitize_key((string) $settings['visibility']) : 'all';
        if (! in_array($visibility, array('all', 'own'), true)) {
            $visibility = 'all';
        }

        $default_status = isset($settings['default_status']) ? sanitize_key((string) $settings['default_status']) : 'todo';
        if (! in_array($default_status, array_keys(self::allowed_statuses()), true)) {
            $default_status = 'todo';
        }

        $default_priority = isset($settings['default_priority']) ? sanitize_key((string) $settings['default_priority']) : 'medium';
        if (! in_array($default_priority, array_keys(self::allowed_priorities()), true)) {
            $default_priority = 'medium';
        }

        $reward_award_mode = isset($settings['reward_award_mode']) ? sanitize_key((string) $settings['reward_award_mode']) : 'once';
        if (! in_array($reward_award_mode, array('once', 'repeat'), true)) {
            $reward_award_mode = 'once';
        }

        $auto_refresh_user_scope = isset($settings['auto_refresh_user_scope']) ? sanitize_key((string) $settings['auto_refresh_user_scope']) : 'all';
        if (! in_array($auto_refresh_user_scope, array('all', 'admin_editor_only', 'users_only'), true)) {
            $auto_refresh_user_scope = 'all';
        }

        $dashboard_title = isset($settings['dashboard_title']) ? sanitize_text_field((string) $settings['dashboard_title']) : 'Daily Taks';
        if ('' === $dashboard_title) {
            $dashboard_title = 'Daily Taks';
        }
        $frontend_login_redirect_param = isset($settings['frontend_login_redirect_param']) ? (string) $settings['frontend_login_redirect_param'] : 'redirect_to';
        $frontend_login_redirect_param = preg_replace('/[^a-zA-Z0-9_-]/', '', $frontend_login_redirect_param);
        if ('' === $frontend_login_redirect_param) {
            $frontend_login_redirect_param = 'redirect_to';
        }
        $guest_login_title = isset($settings['guest_login_title']) ? sanitize_text_field((string) $settings['guest_login_title']) : 'Please Log In To View Tasks';
        if ('' === $guest_login_title) {
            $guest_login_title = 'Please Log In To View Tasks';
        }
        $guest_login_subtitle = isset($settings['guest_login_subtitle']) ? sanitize_text_field((string) $settings['guest_login_subtitle']) : 'Access your task dashboard, track progress, and check reward points after signing in.';
        if ('' === $guest_login_subtitle) {
            $guest_login_subtitle = 'Access your task dashboard, track progress, and check reward points after signing in.';
        }
        $guest_login_button_text = isset($settings['guest_login_button_text']) ? sanitize_text_field((string) $settings['guest_login_button_text']) : 'Login To Continue';
        if ('' === $guest_login_button_text) {
            $guest_login_button_text = 'Login To Continue';
        }
        $guest_login_note = isset($settings['guest_login_note']) ? sanitize_text_field((string) $settings['guest_login_note']) : 'Need access? Contact your administrator for task dashboard permissions.';
        if ('' === $guest_login_note) {
            $guest_login_note = 'Need access? Contact your administrator for task dashboard permissions.';
        }
        $guest_btn_start = self::sanitize_color_hex(isset($settings['guest_login_button_color_start']) ? (string) $settings['guest_login_button_color_start'] : '', '#2563eb');
        $guest_btn_end = self::sanitize_color_hex(isset($settings['guest_login_button_color_end']) ? (string) $settings['guest_login_button_color_end'] : '', '#4f46e5');
        $guest_btn_text = self::sanitize_color_hex(isset($settings['guest_login_button_text_color']) ? (string) $settings['guest_login_button_text_color'] : '', '#ffffff');
        $guest_btn_radius = isset($settings['guest_login_button_radius']) ? max(0, min(30, absint($settings['guest_login_button_radius']))) : 12;
        $slack_user_map = array();
        if (isset($settings['slack_user_map']) && is_array($settings['slack_user_map'])) {
            foreach ($settings['slack_user_map'] as $user_id => $slack_id_raw) {
                $uid = absint($user_id);
                if ($uid < 1) {
                    continue;
                }
                $sid = strtoupper(trim((string) $slack_id_raw));
                $sid = preg_replace('/[^A-Z0-9]/', '', $sid);
                if ('' !== $sid) {
                    $slack_user_map[$uid] = $sid;
                }
            }
        }

        return array(
            'access_roles'      => $access_roles,
            'settings_roles'    => $settings_roles,
            'frontend_roles'    => $frontend_roles,
            'frontend_enabled'  => ! empty($settings['frontend_enabled']) ? 1 : 0,
            'frontend_page_id'  => isset($settings['frontend_page_id']) ? absint($settings['frontend_page_id']) : 0,
            'frontend_redirect' => ! empty($settings['frontend_redirect']) ? 1 : 0,
            'frontend_tasks_home_url' => isset($settings['frontend_tasks_home_url']) ? esc_url_raw((string) $settings['frontend_tasks_home_url']) : '',
            'frontend_login_url' => isset($settings['frontend_login_url']) ? esc_url_raw((string) $settings['frontend_login_url']) : '',
            'frontend_login_redirect_param' => $frontend_login_redirect_param,
            'frontend_logout_redirect_url' => isset($settings['frontend_logout_redirect_url']) ? esc_url_raw((string) $settings['frontend_logout_redirect_url']) : '',
            'guest_login_title' => $guest_login_title,
            'guest_login_subtitle' => $guest_login_subtitle,
            'guest_login_button_text' => $guest_login_button_text,
            'guest_login_note' => $guest_login_note,
            'guest_login_button_color_start' => $guest_btn_start,
            'guest_login_button_color_end' => $guest_btn_end,
            'guest_login_button_text_color' => $guest_btn_text,
            'guest_login_button_radius' => $guest_btn_radius,
            'dashboard_title'   => $dashboard_title,
            'frontend_force_tasks_only' => ! empty($settings['frontend_force_tasks_only']) ? 1 : 0,
            'employee_own_tasks_only' => ! empty($settings['employee_own_tasks_only']) ? 1 : 0,
            'admin_employee_filter_enabled' => ! empty($settings['admin_employee_filter_enabled']) ? 1 : 0,
            'auto_refresh_enabled'  => ! empty($settings['auto_refresh_enabled']) ? 1 : 0,
            'auto_refresh_frontend' => ! empty($settings['auto_refresh_frontend']) ? 1 : 0,
            'auto_refresh_backend'  => ! empty($settings['auto_refresh_backend']) ? 1 : 0,
            'auto_refresh_user_scope' => $auto_refresh_user_scope,
            'auto_refresh_only_visible' => ! empty($settings['auto_refresh_only_visible']) ? 1 : 0,
            'auto_refresh_interval' => isset($settings['auto_refresh_interval']) ? max(10, min(3600, absint($settings['auto_refresh_interval']))) : 60,
            'tasks_per_page' => isset($settings['tasks_per_page']) ? max(1, min(100, absint($settings['tasks_per_page']))) : 10,
            'slack_enabled' => ! empty($settings['slack_enabled']) ? 1 : 0,
            'slack_signing_secret' => isset($settings['slack_signing_secret']) ? sanitize_text_field((string) $settings['slack_signing_secret']) : '',
            'slack_bot_token' => isset($settings['slack_bot_token']) ? sanitize_text_field((string) $settings['slack_bot_token']) : '',
            'slack_channel_id' => isset($settings['slack_channel_id']) ? sanitize_text_field((string) $settings['slack_channel_id']) : '',
            'slack_notify_on_assign' => ! empty($settings['slack_notify_on_assign']) ? 1 : 0,
            'slack_notify_on_assign_dm' => ! empty($settings['slack_notify_on_assign_dm']) ? 1 : 0,
            'slack_allow_create_from_command' => ! empty($settings['slack_allow_create_from_command']) ? 1 : 0,
            'slack_user_map' => $slack_user_map,
            'visibility'        => $visibility,
            'default_status'    => $default_status,
            'default_priority'  => $default_priority,
            'require_due_date'  => ! empty($settings['require_due_date']) ? 1 : 0,
            'allow_user_edit'   => ! empty($settings['allow_user_edit']) ? 1 : 0,
            'allow_user_delete' => ! empty($settings['allow_user_delete']) ? 1 : 0,
            'rewards_enabled'   => ! empty($settings['rewards_enabled']) ? 1 : 0,
            'reward_low'        => isset($settings['reward_low']) ? max(0, absint($settings['reward_low'])) : 5,
            'reward_medium'     => isset($settings['reward_medium']) ? max(0, absint($settings['reward_medium'])) : 10,
            'reward_high'       => isset($settings['reward_high']) ? max(0, absint($settings['reward_high'])) : 20,
            'reward_award_mode' => $reward_award_mode,
        );
    }

    private static function available_roles() {
        if (! function_exists('wp_roles')) {
            return array();
        }

        $roles = wp_roles()->roles;
        $role_labels = array();

        foreach ($roles as $key => $data) {
            $role_labels[$key] = isset($data['name']) ? (string) $data['name'] : $key;
        }

        return $role_labels;
    }

    private static function sanitize_color_hex($value, $default) {
        $sanitized = sanitize_hex_color((string) $value);
        if ($sanitized) {
            return $sanitized;
        }

        $fallback = sanitize_hex_color((string) $default);
        return $fallback ? $fallback : '#2563eb';
    }

    public static function register_rest_routes() {
        register_rest_route(
            'stm/v1',
            '/slack-command',
            array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'handle_slack_command'),
                'permission_callback' => '__return_true',
            )
        );
    }

    private static function slack_default_created_by() {
        $admins = get_users(
            array(
                'role'   => 'administrator',
                'fields' => array('ID'),
                'number' => 1,
            )
        );
        if (! empty($admins) && isset($admins[0]->ID)) {
            return (int) $admins[0]->ID;
        }
        return 1;
    }

    private static function slack_user_id_by_slack_id($slack_id, $settings) {
        $target = strtoupper(trim((string) $slack_id));
        if ('' === $target || empty($settings['slack_user_map']) || ! is_array($settings['slack_user_map'])) {
            return 0;
        }
        foreach ($settings['slack_user_map'] as $user_id => $mapped_slack_id) {
            if (strtoupper((string) $mapped_slack_id) === $target) {
                return absint($user_id);
            }
        }
        return 0;
    }

    private static function slack_id_by_user_id($user_id, $settings) {
        $uid = absint($user_id);
        if ($uid < 1 || empty($settings['slack_user_map']) || ! is_array($settings['slack_user_map'])) {
            return '';
        }
        return isset($settings['slack_user_map'][$uid]) ? strtoupper((string) $settings['slack_user_map'][$uid]) : '';
    }

    private static function normalized_identity_token($value) {
        $value = strtolower(trim((string) $value));
        return preg_replace('/[^a-z0-9]/', '', $value);
    }

    private static function slack_lookup_user_id_by_handle($handle, $settings) {
        $token = isset($settings['slack_bot_token']) ? trim((string) $settings['slack_bot_token']) : '';
        $handle = strtolower(trim(ltrim((string) $handle, '@')));
        $handle_norm = self::normalized_identity_token($handle);
        $handle_core = preg_replace('/^[^a-z]+/i', '', $handle);
        $handle_core_norm = self::normalized_identity_token($handle_core);
        if ('' === $token || '' === $handle) {
            return '';
        }

        $cursor = '';
        $pages  = 0;
        while ($pages < 5) {
            $pages++;
            $api_url = 'https://slack.com/api/users.list?limit=200';
            if ('' !== $cursor) {
                $api_url = add_query_arg('cursor', rawurlencode($cursor), $api_url);
            }

            $response = wp_remote_get(
                $api_url,
                array(
                    'timeout' => 15,
                    'headers' => array(
                        'Authorization' => 'Bearer ' . $token,
                    ),
                )
            );

            if (is_wp_error($response)) {
                return '';
            }

            $body = json_decode((string) wp_remote_retrieve_body($response), true);
            if (! is_array($body) || empty($body['ok']) || empty($body['members']) || ! is_array($body['members'])) {
                return '';
            }

            foreach ($body['members'] as $member) {
                if (! is_array($member) || empty($member['id'])) {
                    continue;
                }
                $name = isset($member['name']) ? strtolower((string) $member['name']) : '';
                $profile = isset($member['profile']) && is_array($member['profile']) ? $member['profile'] : array();
                $display_name = isset($profile['display_name']) ? strtolower((string) $profile['display_name']) : '';
                $real_name = isset($profile['real_name']) ? strtolower((string) $profile['real_name']) : '';
                $name_norm = self::normalized_identity_token($name);
                $display_norm = self::normalized_identity_token($display_name);
                $real_norm = self::normalized_identity_token($real_name);

                if (
                    $handle === $name ||
                    $handle === $display_name ||
                    $handle === $real_name ||
                    ('' !== $handle_norm && (
                        $handle_norm === $name_norm ||
                        $handle_norm === $display_norm ||
                        $handle_norm === $real_norm ||
                        ('' !== $display_norm && 0 === strpos($display_norm, $handle_norm)) ||
                        ('' !== $real_norm && 0 === strpos($real_norm, $handle_norm))
                    )) ||
                    ('' !== $handle_core_norm && (
                        $handle_core_norm === $name_norm ||
                        $handle_core_norm === $display_norm ||
                        $handle_core_norm === $real_norm ||
                        ('' !== $name_norm && false !== strpos($name_norm, $handle_core_norm)) ||
                        ('' !== $display_norm && false !== strpos($display_norm, $handle_core_norm)) ||
                        ('' !== $real_norm && false !== strpos($real_norm, $handle_core_norm))
                    ))
                ) {
                    return strtoupper((string) $member['id']);
                }
            }

            $cursor = '';
            if (isset($body['response_metadata']) && is_array($body['response_metadata']) && ! empty($body['response_metadata']['next_cursor'])) {
                $cursor = (string) $body['response_metadata']['next_cursor'];
            }
            if ('' === $cursor) {
                break;
            }
        }

        return '';
    }

    private static function slack_resolve_assignee_user($mention, $settings) {
        $mention = trim((string) $mention);
        if ('' === $mention) {
            return 0;
        }

        $resolved_user_id = 0;
        if (preg_match('/^<@([A-Z0-9]+)(?:\\|[^>]+)?>$/', $mention, $m)) {
            $resolved_user_id = self::slack_user_id_by_slack_id($m[1], $settings);
        } elseif (preg_match('/^@?[UW][A-Z0-9]+$/', strtoupper($mention))) {
            $resolved_user_id = self::slack_user_id_by_slack_id(ltrim($mention, '@'), $settings);
        } else {
            // Strict Slack resolution:
            // @handle -> Slack user ID via Slack API -> mapped Slack ID in settings.
            $slack_handle = trim(ltrim($mention, '@'));
            if ('' === $slack_handle) {
                return 0;
            }
            $slack_id_from_handle = self::slack_lookup_user_id_by_handle($slack_handle, $settings);
            if ('' !== $slack_id_from_handle) {
                $resolved_user_id = self::slack_user_id_by_slack_id($slack_id_from_handle, $settings);
            }
        }

        if ($resolved_user_id < 1) {
            return 0;
        }

        $assignable_users = self::get_assignable_users();
        $assignable_ids = wp_list_pluck($assignable_users, 'ID');
        if (! in_array($resolved_user_id, $assignable_ids, true)) {
            return 0;
        }
        return $resolved_user_id;
    }

    private static function slack_verify_request($request, $settings) {
        $secret = isset($settings['slack_signing_secret']) ? trim((string) $settings['slack_signing_secret']) : '';
        if ('' === $secret) {
            return false;
        }

        $timestamp = $request->get_header('x_slack_request_timestamp');
        $signature = $request->get_header('x_slack_signature');
        if ('' === $timestamp || '' === $signature) {
            return false;
        }

        if (abs(time() - (int) $timestamp) > 300) {
            return false;
        }

        $body = (string) $request->get_body();
        $basestring = 'v0:' . $timestamp . ':' . $body;
        $expected = 'v0=' . hash_hmac('sha256', $basestring, $secret);

        return hash_equals($expected, $signature);
    }

    private static function slack_send_message($text, $settings, $channel_id = '') {
        $token = isset($settings['slack_bot_token']) ? trim((string) $settings['slack_bot_token']) : '';
        $channel = '' !== $channel_id ? $channel_id : (isset($settings['slack_channel_id']) ? trim((string) $settings['slack_channel_id']) : '');
        if ('' === $token || '' === $channel || '' === trim((string) $text)) {
            return false;
        }

        $response = wp_remote_post(
            'https://slack.com/api/chat.postMessage',
            array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json; charset=utf-8',
                ),
                'body'    => wp_json_encode(
                    array(
                        'channel' => $channel,
                        'text'    => (string) $text,
                    )
                ),
            )
        );

        if (is_wp_error($response)) {
            return false;
        }

        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        return is_array($body) && ! empty($body['ok']);
    }

    private static function slack_send_dm_to_user($slack_user_id, $text, $settings) {
        $token = isset($settings['slack_bot_token']) ? trim((string) $settings['slack_bot_token']) : '';
        $slack_user_id = strtoupper(trim((string) $slack_user_id));
        if ('' === $token || '' === $slack_user_id || '' === trim((string) $text)) {
            return false;
        }

        $open_response = wp_remote_post(
            'https://slack.com/api/conversations.open',
            array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json; charset=utf-8',
                ),
                'body'    => wp_json_encode(
                    array(
                        'users' => $slack_user_id,
                    )
                ),
            )
        );
        if (is_wp_error($open_response)) {
            return self::slack_send_message($text, $settings, $slack_user_id);
        }
        $open_body = json_decode((string) wp_remote_retrieve_body($open_response), true);
        if (! is_array($open_body) || empty($open_body['ok']) || empty($open_body['channel']['id'])) {
            return self::slack_send_message($text, $settings, $slack_user_id);
        }

        return self::slack_send_message($text, $settings, (string) $open_body['channel']['id']);
    }

    private static function slack_notify_task_assignment($task, $settings) {
        if (empty($settings['slack_enabled']) || empty($task)) {
            return;
        }

        $assigned_to = isset($task->assigned_to) ? (int) $task->assigned_to : 0;
        if ($assigned_to < 1) {
            return;
        }

        $slack_id = self::slack_id_by_user_id($assigned_to, $settings);
        $assigned_by_name = self::user_name((int) $task->created_by);
        $due = ! empty($task->due_date) ? (string) $task->due_date : 'No due date';
        $mention = '' !== $slack_id ? '<@' . $slack_id . '>' : self::user_name($assigned_to);
        $msg = sprintf(
            'New task assigned to %s by %s: %s (Due: %s, Priority: %s, Reward: +%d)',
            $mention,
            $assigned_by_name,
            (string) $task->title,
            $due,
            ucfirst((string) $task->priority),
            (int) $task->reward_points
        );

        if (! empty($settings['slack_notify_on_assign'])) {
            self::slack_send_message($msg, $settings);
        }

        if (! empty($settings['slack_notify_on_assign_dm']) && '' !== $slack_id) {
            $dm_msg = sprintf(
                'You have a new task from %s: %s (Due: %s, Priority: %s, Reward: +%d)',
                $assigned_by_name,
                (string) $task->title,
                $due,
                ucfirst((string) $task->priority),
                (int) $task->reward_points
            );
            self::slack_send_dm_to_user($slack_id, $dm_msg, $settings);
        }
    }

    public static function handle_slack_command($request) {
        $settings = self::get_settings();
        if (empty($settings['slack_enabled']) || empty($settings['slack_allow_create_from_command'])) {
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'Slack task integration is disabled.',
                ),
                200
            );
        }

        if (! self::slack_verify_request($request, $settings)) {
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'Invalid Slack signature.',
                ),
                403
            );
        }

        $params = $request->get_params();
        $text = isset($params['text']) ? trim((string) $params['text']) : '';
        $channel_id = isset($params['channel_id']) ? trim((string) $params['channel_id']) : '';
        $from_slack_user_id = isset($params['user_id']) ? trim((string) $params['user_id']) : '';

        $allowed_channel = isset($settings['slack_channel_id']) ? trim((string) $settings['slack_channel_id']) : '';
        $allowed_channel = ltrim($allowed_channel, '#');
        if ('' !== $allowed_channel) {
            $allowed_channel = strtoupper($allowed_channel);
        }
        $incoming_channel = strtoupper(trim((string) $channel_id));
        if ('' !== $allowed_channel && '' !== $incoming_channel && $incoming_channel !== $allowed_channel) {
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'This command is not allowed in this channel. Expected channel ID: ' . $allowed_channel . ', got: ' . $incoming_channel,
                ),
                200
            );
        }

        $parts = array_map('trim', explode('|', $text));
        if (count($parts) < 2) {
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'Use format: @username|Task title|Description|due:YYYY-MM-DD|priority:low|reward:10',
                ),
                200
            );
        }

        $assignee_token = $parts[0];
        $title = isset($parts[1]) ? sanitize_text_field($parts[1]) : '';
        $description = isset($parts[2]) ? sanitize_textarea_field($parts[2]) : '';
        if ('' === $title) {
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'Task title is required.',
                ),
                200
            );
        }

        $assigned_to = self::slack_resolve_assignee_user($assignee_token, $settings);
        if ($assigned_to < 1) {
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'Assignee not mapped. Use Slack mention (<@U...>) or map Slack username to Slack User ID in plugin settings (Slack scope users:read required for @username). Provided assignee: ' . $assignee_token,
                ),
                200
            );
        }

        $priority = 'medium';
        $due_date = null;
        $reward_points = self::default_reward_for_priority($priority);
        foreach ($parts as $idx => $part) {
            if ($idx < 3) {
                continue;
            }
            if (0 === stripos($part, 'due:')) {
                $raw_due = trim(substr($part, 4));
                $date = date_create_from_format('Y-m-d', $raw_due);
                if ($date && $date->format('Y-m-d') === $raw_due) {
                    $due_date = $raw_due;
                }
            } elseif (0 === stripos($part, 'priority:')) {
                $raw_priority = sanitize_key(trim(substr($part, 9)));
                if (in_array($raw_priority, array('low', 'medium', 'high'), true)) {
                    $priority = $raw_priority;
                }
            } elseif (0 === stripos($part, 'reward:')) {
                $reward_points = max(0, absint(trim(substr($part, 7))));
            }
        }
        if ($reward_points < 1) {
            $reward_points = self::default_reward_for_priority($priority);
        }

        global $wpdb;
        $created_by = self::slack_user_id_by_slack_id($from_slack_user_id, $settings);
        if ($created_by < 1) {
            $created_by = self::slack_default_created_by();
        }
        $status = isset($settings['default_status']) ? (string) $settings['default_status'] : 'todo';
        $now = current_time('mysql');
        $inserted = $wpdb->insert(
            self::table_name(),
            array(
                'title'         => $title,
                'description'   => $description,
                'status'        => $status,
                'priority'      => $priority,
                'due_date'      => $due_date,
                'assigned_to'   => $assigned_to,
                'reward_points' => $reward_points,
                'created_by'    => $created_by,
                'created_at'    => $now,
                'updated_at'    => $now,
                'completed_at'  => 'done' === $status ? $now : null,
            ),
            array('%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s')
        );

        if (false === $inserted) {
            $db_error = isset($wpdb->last_error) ? (string) $wpdb->last_error : '';
            return new WP_REST_Response(
                array(
                    'response_type' => 'ephemeral',
                    'text'          => 'Task creation failed in WordPress. ' . ($db_error !== '' ? 'DB error: ' . $db_error : 'Please check plugin database migration.'),
                ),
                200
            );
        }

        $task_id = (int) $wpdb->insert_id;
        $task = $task_id > 0 ? self::get_task($task_id) : null;
        if ($task) {
            self::slack_notify_task_assignment($task, $settings);
        }

        return new WP_REST_Response(
            array(
                'response_type' => 'in_channel',
                'text'          => sprintf('Task created and assigned to %s: %s', self::user_name($assigned_to), $title),
            ),
            200
        );
    }

    private static function default_reward_for_priority($priority) {
        $settings = self::get_settings();

        if ('high' === $priority) {
            return (int) $settings['reward_high'];
        }

        if ('low' === $priority) {
            return (int) $settings['reward_low'];
        }

        return (int) $settings['reward_medium'];
    }

    private static function get_assignable_users() {
        $settings = self::get_settings();

        $users = get_users(
            array(
                'role__in' => $settings['access_roles'],
                'orderby'  => 'display_name',
                'order'    => 'ASC',
            )
        );

        return is_array($users) ? $users : array();
    }

    private static function user_name($user_id) {
        $user_id = absint($user_id);
        if ($user_id < 1) {
            return __('Unassigned', 'simple-task-management');
        }

        $user = get_user_by('id', $user_id);
        if (! $user) {
            return __('Unknown user', 'simple-task-management');
        }

        return $user->display_name;
    }

    private static function current_user_has_role($allowed_roles) {
        $user = wp_get_current_user();

        if (! $user || empty($user->roles)) {
            return false;
        }

        foreach ($user->roles as $role) {
            if (in_array($role, $allowed_roles, true)) {
                return true;
            }
        }

        return false;
    }

    private static function user_has_any_role($user, $allowed_roles) {
        if (! $user || empty($user->roles)) {
            return false;
        }

        foreach ($user->roles as $role) {
            if (in_array($role, $allowed_roles, true)) {
                return true;
            }
        }

        return false;
    }

    private static function current_user_can_manage_tasks() {
        $settings = self::get_settings();

        return self::current_user_has_role($settings['access_roles']);
    }

    private static function current_user_can_manage_settings() {
        $settings = self::get_settings();

        return self::current_user_has_role($settings['settings_roles']);
    }

    private static function current_user_can_access_frontend_dashboard() {
        $settings = self::get_settings();

        if (empty($settings['frontend_enabled'])) {
            return false;
        }

        return self::current_user_has_role($settings['frontend_roles']);
    }

    private static function auto_refresh_allowed_for_scope($scope, $is_settings_manager) {
        if ('admin_editor_only' === $scope) {
            return (bool) $is_settings_manager;
        }

        if ('users_only' === $scope) {
            return ! $is_settings_manager;
        }

        return true;
    }

    private static function current_user_can_view_task_item($task) {
        if (! self::current_user_can_manage_tasks()) {
            return false;
        }

        $settings = self::get_settings();
        if (self::current_user_can_manage_settings()) {
            return true;
        }

        if (! empty($settings['employee_own_tasks_only'])) {
            $user_id = get_current_user_id();

            return (int) $task->created_by === $user_id || (int) $task->assigned_to === $user_id;
        }

        if ('own' === $settings['visibility']) {
            $user_id = get_current_user_id();

            return (int) $task->created_by === $user_id || (int) $task->assigned_to === $user_id;
        }

        return true;
    }

    private static function current_user_can_edit_task_item($task) {
        if (! self::current_user_can_view_task_item($task)) {
            return false;
        }

        if (self::current_user_can_manage_settings()) {
            return true;
        }

        $settings = self::get_settings();

        return ! empty($settings['allow_user_edit']);
    }

    private static function current_user_can_delete_task_item($task) {
        if (! self::current_user_can_view_task_item($task)) {
            return false;
        }

        if (self::current_user_can_manage_settings()) {
            return true;
        }

        $settings = self::get_settings();

        return ! empty($settings['allow_user_delete']);
    }

    private static function current_user_can_change_task_status_item($task) {
        if (self::current_user_can_view_task_item($task)) {
            return true;
        }

        if (! is_user_logged_in() || ! self::current_user_can_access_frontend_dashboard()) {
            return false;
        }

        $user_id = get_current_user_id();
        return (int) $task->assigned_to === $user_id || (int) $task->created_by === $user_id;
    }

    public static function register_admin_menu() {
        add_menu_page(
            __('Task Manager', 'simple-task-management'),
            __('Task Manager', 'simple-task-management'),
            'read',
            'stm-task-manager',
            array(__CLASS__, 'render_admin_page'),
            'dashicons-yes-alt',
            26
        );

        add_submenu_page(
            'stm-task-manager',
            __('Task Manager Settings', 'simple-task-management'),
            __('Settings', 'simple-task-management'),
            'read',
            'stm-task-manager-settings',
            array(__CLASS__, 'render_settings_page')
        );
    }

    public static function handle_save_settings() {
        if (! self::current_user_can_manage_settings()) {
            wp_die(esc_html__('You are not allowed to manage settings.', 'simple-task-management'));
        }

        check_admin_referer('stm_save_settings');

        $roles         = self::available_roles();
        $access_roles  = isset($_POST['access_roles']) && is_array($_POST['access_roles']) ? wp_unslash($_POST['access_roles']) : array();
        $setting_roles = isset($_POST['settings_roles']) && is_array($_POST['settings_roles']) ? wp_unslash($_POST['settings_roles']) : array();
        $frontend_roles = isset($_POST['frontend_roles']) && is_array($_POST['frontend_roles']) ? wp_unslash($_POST['frontend_roles']) : array();

        $settings = array(
            'access_roles'      => array_values(array_intersect(array_map('sanitize_key', $access_roles), array_keys($roles))),
            'settings_roles'    => array_values(array_intersect(array_map('sanitize_key', $setting_roles), array_keys($roles))),
            'frontend_roles'    => array_values(array_intersect(array_map('sanitize_key', $frontend_roles), array_keys($roles))),
            'frontend_enabled'  => isset($_POST['frontend_enabled']) ? 1 : 0,
            'frontend_page_id'  => isset($_POST['frontend_page_id']) ? absint($_POST['frontend_page_id']) : 0,
            'frontend_redirect' => isset($_POST['frontend_redirect']) ? 1 : 0,
            'frontend_tasks_home_url' => isset($_POST['frontend_tasks_home_url']) ? esc_url_raw(wp_unslash($_POST['frontend_tasks_home_url'])) : '',
            'frontend_login_url' => isset($_POST['frontend_login_url']) ? esc_url_raw(wp_unslash($_POST['frontend_login_url'])) : '',
            'frontend_login_redirect_param' => isset($_POST['frontend_login_redirect_param']) ? sanitize_text_field(wp_unslash($_POST['frontend_login_redirect_param'])) : 'redirect_to',
            'frontend_logout_redirect_url' => isset($_POST['frontend_logout_redirect_url']) ? esc_url_raw(wp_unslash($_POST['frontend_logout_redirect_url'])) : '',
            'guest_login_title' => isset($_POST['guest_login_title']) ? sanitize_text_field(wp_unslash($_POST['guest_login_title'])) : 'Please Log In To View Tasks',
            'guest_login_subtitle' => isset($_POST['guest_login_subtitle']) ? sanitize_text_field(wp_unslash($_POST['guest_login_subtitle'])) : 'Access your task dashboard, track progress, and check reward points after signing in.',
            'guest_login_button_text' => isset($_POST['guest_login_button_text']) ? sanitize_text_field(wp_unslash($_POST['guest_login_button_text'])) : 'Login To Continue',
            'guest_login_note' => isset($_POST['guest_login_note']) ? sanitize_text_field(wp_unslash($_POST['guest_login_note'])) : 'Need access? Contact your administrator for task dashboard permissions.',
            'guest_login_button_color_start' => isset($_POST['guest_login_button_color_start']) ? sanitize_text_field(wp_unslash($_POST['guest_login_button_color_start'])) : '#2563eb',
            'guest_login_button_color_end' => isset($_POST['guest_login_button_color_end']) ? sanitize_text_field(wp_unslash($_POST['guest_login_button_color_end'])) : '#4f46e5',
            'guest_login_button_text_color' => isset($_POST['guest_login_button_text_color']) ? sanitize_text_field(wp_unslash($_POST['guest_login_button_text_color'])) : '#ffffff',
            'guest_login_button_radius' => isset($_POST['guest_login_button_radius']) ? absint($_POST['guest_login_button_radius']) : 12,
            'dashboard_title'   => isset($_POST['dashboard_title']) ? sanitize_text_field(wp_unslash($_POST['dashboard_title'])) : 'Daily Taks',
            'frontend_force_tasks_only' => isset($_POST['frontend_force_tasks_only']) ? 1 : 0,
            'employee_own_tasks_only' => isset($_POST['employee_own_tasks_only']) ? 1 : 0,
            'admin_employee_filter_enabled' => isset($_POST['admin_employee_filter_enabled']) ? 1 : 0,
            'auto_refresh_enabled'  => isset($_POST['auto_refresh_enabled']) ? 1 : 0,
            'auto_refresh_frontend' => isset($_POST['auto_refresh_frontend']) ? 1 : 0,
            'auto_refresh_backend'  => isset($_POST['auto_refresh_backend']) ? 1 : 0,
            'auto_refresh_user_scope' => isset($_POST['auto_refresh_user_scope']) ? sanitize_key(wp_unslash($_POST['auto_refresh_user_scope'])) : 'all',
            'auto_refresh_only_visible' => isset($_POST['auto_refresh_only_visible']) ? 1 : 0,
            'auto_refresh_interval' => isset($_POST['auto_refresh_interval']) ? absint($_POST['auto_refresh_interval']) : 60,
            'tasks_per_page' => isset($_POST['tasks_per_page']) ? absint($_POST['tasks_per_page']) : 10,
            'slack_enabled' => isset($_POST['slack_enabled']) ? 1 : 0,
            'slack_signing_secret' => isset($_POST['slack_signing_secret']) ? sanitize_text_field(wp_unslash($_POST['slack_signing_secret'])) : '',
            'slack_bot_token' => isset($_POST['slack_bot_token']) ? sanitize_text_field(wp_unslash($_POST['slack_bot_token'])) : '',
            'slack_channel_id' => isset($_POST['slack_channel_id']) ? sanitize_text_field(wp_unslash($_POST['slack_channel_id'])) : '',
            'slack_notify_on_assign' => isset($_POST['slack_notify_on_assign']) ? 1 : 0,
            'slack_notify_on_assign_dm' => isset($_POST['slack_notify_on_assign_dm']) ? 1 : 0,
            'slack_allow_create_from_command' => isset($_POST['slack_allow_create_from_command']) ? 1 : 0,
            'slack_user_map' => isset($_POST['slack_user_map']) && is_array($_POST['slack_user_map']) ? wp_unslash($_POST['slack_user_map']) : array(),
            'visibility'        => isset($_POST['visibility']) ? sanitize_key(wp_unslash($_POST['visibility'])) : 'all',
            'default_status'    => isset($_POST['default_status']) ? sanitize_key(wp_unslash($_POST['default_status'])) : 'todo',
            'default_priority'  => isset($_POST['default_priority']) ? sanitize_key(wp_unslash($_POST['default_priority'])) : 'medium',
            'require_due_date'  => isset($_POST['require_due_date']) ? 1 : 0,
            'allow_user_edit'   => isset($_POST['allow_user_edit']) ? 1 : 0,
            'allow_user_delete' => isset($_POST['allow_user_delete']) ? 1 : 0,
            'rewards_enabled'   => isset($_POST['rewards_enabled']) ? 1 : 0,
            'reward_low'        => isset($_POST['reward_low']) ? absint($_POST['reward_low']) : 5,
            'reward_medium'     => isset($_POST['reward_medium']) ? absint($_POST['reward_medium']) : 10,
            'reward_high'       => isset($_POST['reward_high']) ? absint($_POST['reward_high']) : 20,
            'reward_award_mode' => isset($_POST['reward_award_mode']) ? sanitize_key(wp_unslash($_POST['reward_award_mode'])) : 'once',
        );

        update_option(self::OPTION_SETTINGS, self::sanitize_settings($settings));

        self::redirect_with_notice('success', 'Settings saved successfully.', 'stm-task-manager-settings');
    }

    public static function handle_manage_leaderboard() {
        if (! self::current_user_can_manage_settings()) {
            wp_die(esc_html__('You are not allowed to manage leaderboard.', 'simple-task-management'));
        }

        check_admin_referer('stm_manage_leaderboard');

        $operation = isset($_POST['operation']) ? sanitize_key(wp_unslash($_POST['operation'])) : '';

        if ('reset_all' === $operation) {
            delete_metadata('user', 0, self::USER_POINTS_META, '', true);
            self::redirect_with_notice('success', 'Leaderboard points reset for all users.', 'stm-task-manager-settings');
        }

        if ('remove_user' === $operation) {
            $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
            if ($user_id < 1) {
                self::redirect_with_notice('error', 'Please select a user.', 'stm-task-manager-settings');
            }

            delete_user_meta($user_id, self::USER_POINTS_META);
            self::redirect_with_notice('success', 'User removed from leaderboard.', 'stm-task-manager-settings');
        }

        if ('set_points' === $operation) {
            $user_id = isset($_POST['user_id']) ? absint($_POST['user_id']) : 0;
            $points  = isset($_POST['points']) ? max(0, absint($_POST['points'])) : 0;

            if ($user_id < 1) {
                self::redirect_with_notice('error', 'Please select a user.', 'stm-task-manager-settings');
            }

            update_user_meta($user_id, self::USER_POINTS_META, $points);
            self::redirect_with_notice('success', 'Leaderboard points updated.', 'stm-task-manager-settings');
        }

        self::redirect_with_notice('error', 'Invalid leaderboard action.', 'stm-task-manager-settings');
    }

    public static function handle_task_data_tools() {
        if (! self::current_user_can_manage_settings()) {
            wp_die(esc_html__('You are not allowed to manage task data tools.', 'simple-task-management'));
        }

        check_admin_referer('stm_task_data_tools');

        $operation = isset($_POST['operation']) ? sanitize_key(wp_unslash($_POST['operation'])) : '';

        if ('reset_tasks' === $operation) {
            global $wpdb;

            $result = $wpdb->query('TRUNCATE TABLE ' . self::table_name());
            if (false === $result) {
                self::redirect_with_notice('error', 'Failed to reset tasks.', 'stm-task-manager-settings');
            }

            self::redirect_with_notice('success', 'All tasks were reset successfully.', 'stm-task-manager-settings');
        }

        if ('export_tasks' === $operation) {
            $format = isset($_POST['export_format']) ? sanitize_key(wp_unslash($_POST['export_format'])) : 'csv';
            self::download_task_export($format);
        }

        self::redirect_with_notice('error', 'Invalid task data tools operation.', 'stm-task-manager-settings');
    }

    private static function export_task_rows() {
        global $wpdb;

        $rows = $wpdb->get_results('SELECT * FROM ' . self::table_name() . ' ORDER BY created_at DESC');
        if (! is_array($rows)) {
            return array();
        }

        $statuses = self::allowed_statuses();
        $priorities = self::allowed_priorities();
        $export_rows = array();

        foreach ($rows as $row) {
            $status_key = isset($row->status) ? (string) $row->status : '';
            $priority_key = isset($row->priority) ? (string) $row->priority : '';
            $export_rows[] = array(
                'ID' => (int) $row->id,
                'Title' => (string) $row->title,
                'Description' => (string) $row->description,
                'Status' => isset($statuses[$status_key]) ? (string) $statuses[$status_key] : $status_key,
                'Priority' => isset($priorities[$priority_key]) ? (string) $priorities[$priority_key] : $priority_key,
                'Due Date' => ! empty($row->due_date) ? (string) $row->due_date : 'No due date',
                'Reward Points' => (int) $row->reward_points,
                'Assigned To' => self::user_name((int) $row->assigned_to),
                'Assigned By' => self::user_name((int) $row->created_by),
                'Created At' => (string) $row->created_at,
                'Updated At' => (string) $row->updated_at,
            );
        }

        return $export_rows;
    }

    private static function download_task_export($format) {
        $rows = self::export_task_rows();
        $headers = array('ID', 'Title', 'Description', 'Status', 'Priority', 'Due Date', 'Reward Points', 'Assigned To', 'Assigned By', 'Created At', 'Updated At');
        $timestamp = current_time('Y-m-d-H-i-s');

        if ('csv' === $format) {
            nocache_headers();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="stm-tasks-' . $timestamp . '.csv"');

            $out = fopen('php://output', 'w');
            if ($out) {
                fputcsv($out, $headers);
                foreach ($rows as $row) {
                    fputcsv($out, array_values($row));
                }
                fclose($out);
            }
            exit;
        }

        if ('xlsx' === $format) {
            nocache_headers();
            header('Content-Type: application/vnd.ms-excel; charset=utf-8');
            header('Content-Disposition: attachment; filename="stm-tasks-' . $timestamp . '.xls"');
            echo self::task_export_table_html($headers, $rows, false);
            exit;
        }

        if ('pdf' === $format) {
            nocache_headers();
            header('Content-Type: text/html; charset=utf-8');
            header('Content-Disposition: attachment; filename="stm-tasks-' . $timestamp . '-pdf-ready.html"');
            echo self::task_export_table_html($headers, $rows, true);
            exit;
        }

        self::redirect_with_notice('error', 'Invalid export format.', 'stm-task-manager-settings');
    }

    private static function task_export_table_html($headers, $rows, $pdf_ready = false) {
        ob_start();
        ?>
        <!doctype html>
        <html>
        <head>
            <meta charset="utf-8" />
            <title>Task Export</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; color: #111827; }
                h1 { margin: 0 0 10px; font-size: 20px; }
                p.meta { margin: 0 0 14px; color: #475569; font-size: 12px; }
                table { border-collapse: collapse; width: 100%; table-layout: fixed; }
                th, td { border: 1px solid #cbd5e1; padding: 8px; font-size: 12px; text-align: left; vertical-align: top; word-wrap: break-word; }
                th { background: #f1f5f9; font-weight: 700; }
                .print-note { margin-bottom: 12px; font-size: 12px; color: #334155; }
                @media print {
                    .print-note { display: none; }
                }
            </style>
        </head>
        <body>
            <h1>Simple Task Management - Task Export</h1>
            <p class="meta">Generated: <?php echo esc_html(current_time('Y-m-d H:i:s')); ?></p>
            <?php if ($pdf_ready) : ?>
                <p class="print-note">Use your browser Print option and select "Save as PDF".</p>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <?php foreach ($headers as $header_col) : ?>
                            <th><?php echo esc_html((string) $header_col); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)) : ?>
                        <tr><td colspan="<?php echo esc_attr((string) count($headers)); ?>">No task data found.</td></tr>
                    <?php else : ?>
                        <?php foreach ($rows as $row) : ?>
                            <tr>
                                <?php foreach ($headers as $header_col) : ?>
                                    <td><?php echo esc_html(isset($row[$header_col]) ? (string) $row[$header_col] : ''); ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </body>
        </html>
        <?php

        return (string) ob_get_clean();
    }

    private static function frontend_dashboard_url() {
        $settings = self::get_settings();

        if (empty($settings['frontend_page_id'])) {
            return '';
        }

        $url = get_permalink((int) $settings['frontend_page_id']);

        return $url ? $url : '';
    }

    private static function frontend_tasks_home_url() {
        $settings = self::get_settings();

        if (! empty($settings['frontend_tasks_home_url'])) {
            return (string) $settings['frontend_tasks_home_url'];
        }

        $frontend_page_url = self::frontend_dashboard_url();
        if ('' !== $frontend_page_url) {
            return $frontend_page_url;
        }

        return home_url('/tasks/');
    }

    private static function frontend_login_url($redirect_target = '') {
        $settings = self::get_settings();
        $redirect_target = '' !== $redirect_target ? $redirect_target : self::frontend_tasks_home_url();
        $login_url = ! empty($settings['frontend_login_url']) ? (string) $settings['frontend_login_url'] : '';

        if ('' === $login_url) {
            return wp_login_url($redirect_target);
        }

        $param = isset($settings['frontend_login_redirect_param']) ? (string) $settings['frontend_login_redirect_param'] : 'redirect_to';
        $param = preg_replace('/[^a-zA-Z0-9_-]/', '', $param);
        if ('' === $param) {
            $param = 'redirect_to';
        }

        return add_query_arg($param, $redirect_target, $login_url);
    }

    public static function filter_login_redirect($redirect_to, $requested_redirect_to, $user) {
        if (is_wp_error($user) || ! $user) {
            return $redirect_to;
        }

        $settings = self::get_settings();
        $is_frontend_role = self::user_has_any_role($user, $settings['frontend_roles']);
        $is_settings_role = self::user_has_any_role($user, $settings['settings_roles']);
        $frontend_url = self::frontend_tasks_home_url();

        if (
            ! empty($settings['frontend_enabled']) &&
            ! empty($settings['frontend_force_tasks_only']) &&
            $is_frontend_role &&
            ! $is_settings_role &&
            '' !== $frontend_url
        ) {
            return $frontend_url;
        }

        $requested_redirect_to = is_string($requested_redirect_to) ? trim($requested_redirect_to) : '';
        if ('' !== $requested_redirect_to) {
            $safe_requested = wp_validate_redirect($requested_redirect_to, '');
            if ('' !== $safe_requested) {
                return $safe_requested;
            }
        }

        if (empty($settings['frontend_enabled']) || empty($settings['frontend_redirect'])) {
            return $redirect_to;
        }

        if (! $is_frontend_role) {
            return $redirect_to;
        }

        if ('' === $frontend_url) {
            return $redirect_to;
        }

        return $frontend_url;
    }

    public static function filter_logout_redirect($redirect_to, $requested_redirect_to, $user) {
        $settings = self::get_settings();
        $custom_logout_url = isset($settings['frontend_logout_redirect_url']) ? trim((string) $settings['frontend_logout_redirect_url']) : '';

        if ('' === $custom_logout_url) {
            return $redirect_to;
        }

        $safe_custom = wp_validate_redirect($custom_logout_url, '');
        if ('' !== $safe_custom) {
            return $safe_custom;
        }

        return $redirect_to;
    }

    public static function maybe_restrict_dashboard_access() {
        if (! is_admin() || ! is_user_logged_in()) {
            return;
        }

        if ((function_exists('wp_doing_ajax') && wp_doing_ajax()) || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }

        global $pagenow;
        if (in_array((string) $pagenow, array('admin-post.php', 'admin-ajax.php', 'profile.php', 'user-edit.php'), true)) {
            return;
        }

        $settings = self::get_settings();
        if (empty($settings['frontend_enabled']) || empty($settings['frontend_force_tasks_only'])) {
            return;
        }

        $user = wp_get_current_user();
        if (! $user || ! self::user_has_any_role($user, $settings['frontend_roles'])) {
            return;
        }

        if (self::user_has_any_role($user, $settings['settings_roles'])) {
            return;
        }

        $frontend_url = self::frontend_tasks_home_url();
        if ('' === $frontend_url) {
            return;
        }

        wp_safe_redirect($frontend_url);
        exit;
    }

    public static function handle_save_task() {
        if (! self::current_user_can_manage_tasks()) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'simple-task-management'));
        }

        check_admin_referer('stm_save_task');

        global $wpdb;

        $task_id       = isset($_POST['task_id']) ? absint($_POST['task_id']) : 0;
        $title         = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '';
        $description   = isset($_POST['description']) ? sanitize_textarea_field(wp_unslash($_POST['description'])) : '';
        $settings      = self::get_settings();
        $priority      = isset($_POST['priority']) ? sanitize_key(wp_unslash($_POST['priority'])) : $settings['default_priority'];
        $due_date_raw  = isset($_POST['due_date']) ? sanitize_text_field(wp_unslash($_POST['due_date'])) : '';
        $assigned_to   = isset($_POST['assigned_to']) ? absint($_POST['assigned_to']) : 0;
        $reward_raw    = isset($_POST['reward_points']) ? sanitize_text_field(wp_unslash($_POST['reward_points'])) : '';

        $allowed_priorities = self::allowed_priorities();
        $assignable_users   = self::get_assignable_users();
        $assignable_ids     = wp_list_pluck($assignable_users, 'ID');

        if ('' === $title) {
            self::redirect_with_notice('error', 'Task title is required.');
        }

        if (! in_array($priority, array_keys($allowed_priorities), true)) {
            $priority = $settings['default_priority'];
        }

        if ($assigned_to > 0 && ! in_array($assigned_to, $assignable_ids, true)) {
            self::redirect_with_notice('error', 'Selected assignee is not allowed for task access roles.');
        }

        $due_date = null;
        if ('' !== $due_date_raw) {
            $date = date_create_from_format('Y-m-d', $due_date_raw);
            if ($date && $date->format('Y-m-d') === $due_date_raw) {
                $due_date = $due_date_raw;
            } else {
                self::redirect_with_notice('error', 'Due date must be in YYYY-MM-DD format.');
            }
        }

        if (! $due_date && ! empty($settings['require_due_date'])) {
            self::redirect_with_notice('error', 'Due date is required by current plugin settings.');
        }

        $reward_points = '' === trim($reward_raw) ? self::default_reward_for_priority($priority) : absint($reward_raw);
        $now           = current_time('mysql');

        if ($task_id < 1 && ! self::current_user_can_manage_settings()) {
            self::redirect_with_notice('error', 'Only admin/editor can create new tasks.');
        }

        if ($task_id > 0) {
            $task = self::get_task($task_id);

            if (! $task) {
                self::redirect_with_notice('error', 'Task not found.');
            }

            if (! self::current_user_can_edit_task_item($task)) {
                self::redirect_with_notice('error', 'You are not allowed to edit this task.');
            }

            $status = $task->status;
            $previous_assigned_to = (int) $task->assigned_to;

            $wpdb->update(
                self::table_name(),
                array(
                    'title'         => $title,
                    'description'   => $description,
                    'status'        => $status,
                    'priority'      => $priority,
                    'due_date'      => $due_date,
                    'assigned_to'   => $assigned_to > 0 ? $assigned_to : null,
                    'reward_points' => $reward_points,
                    'updated_at'    => $now,
                ),
                array('id' => $task_id),
                array('%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s'),
                array('%d')
            );

            $updated_task = self::get_task($task_id);
            if ($updated_task && (int) $updated_task->assigned_to > 0 && (int) $updated_task->assigned_to !== $previous_assigned_to) {
                self::slack_notify_task_assignment($updated_task, $settings);
            }

            self::redirect_with_notice('success', 'Task updated successfully.');
        }

        $status = $settings['default_status'];

        $wpdb->insert(
            self::table_name(),
            array(
                'title'         => $title,
                'description'   => $description,
                'status'        => $status,
                'priority'      => $priority,
                'due_date'      => $due_date,
                'assigned_to'   => $assigned_to > 0 ? $assigned_to : null,
                'reward_points' => $reward_points,
                'created_by'    => get_current_user_id(),
                'created_at'    => $now,
                'updated_at'    => $now,
                'completed_at'  => 'done' === $status ? $now : null,
            ),
            array('%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s')
        );

        $new_task = self::get_task((int) $wpdb->insert_id);
        self::maybe_award_points_for_completion(null, $new_task, get_current_user_id());
        if ($new_task && (int) $new_task->assigned_to > 0) {
            self::slack_notify_task_assignment($new_task, $settings);
        }

        self::redirect_with_notice('success', 'Task created successfully.');
    }

    public static function handle_delete_task() {
        if (! self::current_user_can_manage_tasks()) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'simple-task-management'));
        }

        check_admin_referer('stm_delete_task');

        global $wpdb;

        $task_id = isset($_GET['task_id']) ? absint($_GET['task_id']) : 0;

        if ($task_id < 1) {
            self::redirect_with_notice('error', 'Invalid task id.');
        }

        $task = self::get_task($task_id);
        if (! $task) {
            self::redirect_with_notice('error', 'Task not found or already deleted.');
        }

        if (! self::current_user_can_delete_task_item($task)) {
            self::redirect_with_notice('error', 'You are not allowed to delete this task.');
        }

        $deleted = $wpdb->delete(self::table_name(), array('id' => $task_id), array('%d'));

        if ($deleted) {
            self::redirect_with_notice('success', 'Task deleted successfully.');
        }

        self::redirect_with_notice('error', 'Task not found or already deleted.');
    }

    public static function handle_update_status() {
        if (! self::current_user_can_manage_tasks() && ! self::current_user_can_access_frontend_dashboard()) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'simple-task-management'));
        }

        check_admin_referer('stm_update_status');

        global $wpdb;

        $task_id = isset($_GET['task_id']) ? absint($_GET['task_id']) : 0;
        $status  = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : 'todo';

        if (! in_array($status, array_keys(self::allowed_statuses()), true)) {
            self::redirect_with_notice('error', 'Invalid status value.');
        }

        if ($task_id < 1) {
            self::redirect_with_notice('error', 'Invalid task id.');
        }

        $task = self::get_task($task_id);
        if (! $task) {
            self::redirect_with_notice('error', 'Task not found.');
        }

        if (! self::current_user_can_change_task_status_item($task)) {
            self::redirect_with_notice('error', 'You are not allowed to update this task.');
        }

        if (
            in_array($status, array('in_progress', 'done'), true) &&
            ! empty($task->due_date) &&
            strtotime($task->due_date . ' 23:59:59') < current_time('timestamp')
        ) {
            if (self::supports_overdue_workflow() && ! in_array((string) $task->overdue_status, array('pending', 'approved'), true)) {
                global $wpdb;
                $wpdb->update(
                    self::table_name(),
                    array(
                        'overdue_status' => 'required',
                        'updated_at'     => current_time('mysql'),
                    ),
                    array('id' => $task_id),
                    array('%s', '%s'),
                    array('%d')
                );
            }
            self::redirect_with_notice('error', 'Task is overdue. Please submit the overdue reason first.');
        }

        $update_data = array(
            'status'     => $status,
            'updated_at' => current_time('mysql'),
        );

        if ('done' === $status && 'done' !== $task->status) {
            $update_data['completed_at'] = current_time('mysql');

            if (self::supports_overdue_workflow() && self::is_task_completed_late($task, $update_data['completed_at'])) {
                $update_data['overdue_status'] = 'required';
            }
        }

        $formats = array();
        foreach ($update_data as $v) {
            if (is_int($v)) {
                $formats[] = '%d';
            } else {
                $formats[] = '%s';
            }
        }

        $updated = $wpdb->update(self::table_name(), $update_data, array('id' => $task_id), $formats, array('%d'));

        if (false === $updated) {
            self::redirect_with_notice('error', 'Failed to update task status.');
        }

        $updated_task = self::get_task($task_id);
        self::maybe_award_points_for_completion($task, $updated_task, get_current_user_id());

        self::redirect_with_notice('success', 'Task status updated.');
    }

    public static function handle_submit_overdue_reason() {
        if (! self::current_user_can_manage_tasks()) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'simple-task-management'));
        }

        check_admin_referer('stm_submit_overdue_reason');

        global $wpdb;

        $task_id = isset($_POST['task_id']) ? absint($_POST['task_id']) : 0;
        $reason  = isset($_POST['overdue_reason']) ? sanitize_textarea_field(wp_unslash($_POST['overdue_reason'])) : '';

        if ($task_id < 1 || '' === $reason) {
            self::redirect_with_notice('error', 'Overdue reason is required.');
        }

        $task = self::get_task($task_id);
        if (! $task || ! self::current_user_can_view_task_item($task)) {
            self::redirect_with_notice('error', 'Task not found or access denied.');
        }

        if (! self::supports_overdue_workflow()) {
            self::redirect_with_notice('error', 'Overdue workflow is not available yet. Please open WP admin once to run plugin upgrade.');
        }

        $due_passed = ! empty($task->due_date) && strtotime($task->due_date . ' 23:59:59') < current_time('timestamp');
        $task_overdue_state = isset($task->overdue_status) ? (string) $task->overdue_status : 'none';

        if (! $due_passed && ! in_array($task_overdue_state, array('required', 'rejected', 'pending'), true)) {
            self::redirect_with_notice('error', 'This task is not overdue yet.');
        }

        $updated = $wpdb->update(
            self::table_name(),
            array(
                'overdue_reason'       => $reason,
                'overdue_status'       => 'pending',
                'overdue_submitted_at' => current_time('mysql'),
                'updated_at'           => current_time('mysql'),
            ),
            array('id' => $task_id),
            array('%s', '%s', '%s', '%s'),
            array('%d')
        );

        if (false === $updated) {
            self::redirect_with_notice('error', 'Failed to submit overdue reason. Please try again.');
        }

        $return_url = isset($_POST['stm_return']) ? esc_url_raw(wp_unslash($_POST['stm_return'])) : '';
        if ($return_url) {
            $url = remove_query_arg(array('stm_notice', 'stm_msg', 'edit_task'), $return_url);
            $url = add_query_arg(
                array(
                    'stm_notice'        => 'success',
                    'stm_msg'           => rawurlencode('Overdue reason submitted for review.'),
                    'stm_overdue_ok_id' => (int) $task_id,
                ),
                $url
            );
            wp_safe_redirect($url);
            exit;
        }

        self::redirect_with_notice('success', 'Overdue reason submitted for review.');
    }

    public static function handle_review_overdue_reason() {
        if (! self::current_user_can_manage_settings()) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'simple-task-management'));
        }

        check_admin_referer('stm_review_overdue_reason');

        global $wpdb;

        $task_id = isset($_GET['task_id']) ? absint($_GET['task_id']) : 0;
        $decision = isset($_GET['decision']) ? sanitize_key(wp_unslash($_GET['decision'])) : '';
        $note = isset($_GET['note']) ? sanitize_text_field(wp_unslash($_GET['note'])) : '';

        if ($task_id < 1 || ! in_array($decision, array('accept', 'reject'), true)) {
            self::redirect_with_notice('error', 'Invalid overdue review request.');
        }

        if (! self::supports_overdue_workflow()) {
            self::redirect_with_notice('error', 'Overdue workflow is not available yet. Please open WP admin once to run plugin upgrade.');
        }

        $task = self::get_task($task_id);
        if (! $task) {
            self::redirect_with_notice('error', 'Task not found.');
        }

        $new_status = 'accept' === $decision ? 'approved' : 'rejected';
        $now = current_time('mysql');
        $review_update = array(
            'overdue_status'      => $new_status,
            'overdue_reviewed_by' => get_current_user_id(),
            'overdue_reviewed_at' => $now,
            'overdue_review_note' => $note,
            'updated_at'          => $now,
        );
        $review_formats = array('%s', '%d', '%s', '%s', '%s');

        if ('accept' === $decision && 'done' !== $task->status) {
            $review_update['status'] = 'done';
            $review_update['completed_at'] = $now;
            $review_formats[] = '%s';
            $review_formats[] = '%s';
        }

        $updated = $wpdb->update(
            self::table_name(),
            $review_update,
            array('id' => $task_id),
            $review_formats,
            array('%d')
        );

        if (false === $updated) {
            self::redirect_with_notice('error', 'Failed to save overdue review.');
        }

        if ('accept' === $decision) {
            $latest_task = self::get_task($task_id);
            if ($latest_task && 'done' === $latest_task->status) {
                $recipient = self::points_recipient_for_task($latest_task, 0);
                self::award_points_to_user_for_task($latest_task, $recipient, 'overdue_approved');
            }
        }

        self::redirect_with_notice('success', 'Overdue reason review saved.');
    }

    private static function is_task_completed_late($task, $completed_at) {
        if (! $task || empty($task->due_date) || empty($completed_at)) {
            return false;
        }

        $due_ts = strtotime($task->due_date . ' 23:59:59');
        $comp_ts = strtotime($completed_at);

        return $due_ts && $comp_ts && $comp_ts > $due_ts;
    }

    private static function points_recipient_for_task($task, $fallback_user_id = 0) {
        if (! empty($task->assigned_to)) {
            return (int) $task->assigned_to;
        }
        if (! empty($task->created_by)) {
            return (int) $task->created_by;
        }

        return (int) $fallback_user_id;
    }

    private static function has_award_for_task($task_id) {
        global $wpdb;

        $id = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT id FROM ' . self::reward_log_table_name() . ' WHERE task_id = %d LIMIT 1',
                (int) $task_id
            )
        );

        return (bool) $id;
    }

    private static function award_points_to_user_for_task($task, $user_id, $event) {
        if (! $task || $user_id < 1) {
            return;
        }

        $settings = self::get_settings();
        if (empty($settings['rewards_enabled'])) {
            return;
        }

        if ('once' === $settings['reward_award_mode'] && self::has_award_for_task($task->id)) {
            return;
        }

        $points = max(0, (int) $task->reward_points);
        if ($points < 1) {
            return;
        }

        global $wpdb;

        $current_points = (int) get_user_meta($user_id, self::USER_POINTS_META, true);
        update_user_meta($user_id, self::USER_POINTS_META, $current_points + $points);

        $wpdb->insert(
            self::reward_log_table_name(),
            array(
                'user_id'    => $user_id,
                'task_id'    => (int) $task->id,
                'points'     => $points,
                'event'      => $event,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%d', '%d', '%s', '%s')
        );
    }

    private static function maybe_award_points_for_completion($old_task, $new_task, $completed_by) {
        $settings = self::get_settings();

        if (empty($settings['rewards_enabled']) || ! $new_task) {
            return;
        }

        $was_done = $old_task && 'done' === $old_task->status;
        $is_done  = 'done' === $new_task->status;

        if (! $is_done || $was_done) {
            return;
        }

        // Award completion points to the user who actually completed the task.
        // Fallback to assignment/creator mapping when completion actor is unknown.
        $recipient_user = (int) $completed_by > 0
            ? (int) $completed_by
            : self::points_recipient_for_task($new_task, 0);
        $completed_at   = ! empty($new_task->completed_at) ? $new_task->completed_at : current_time('mysql');
        $is_late        = self::is_task_completed_late($new_task, $completed_at);

        if ($is_late && (! isset($new_task->overdue_status) || ! in_array($new_task->overdue_status, array('approved'), true))) {
            return;
        }

        self::award_points_to_user_for_task($new_task, $recipient_user, 'completion');
    }

    private static function get_leaderboard($limit = 5) {
        $settings = self::get_settings();

        $users = get_users(
            array(
                'role__in'  => $settings['access_roles'],
                'meta_key'  => self::USER_POINTS_META,
                'orderby'   => 'meta_value_num',
                'order'     => 'DESC',
                'number'    => absint($limit),
                'fields'    => array('ID', 'display_name', 'user_email'),
            )
        );

        return is_array($users) ? $users : array();
    }

    private static function allowed_statuses() {
        return array(
            'todo'        => __('To Do', 'simple-task-management'),
            'in_progress' => __('In Progress', 'simple-task-management'),
            'done'        => __('Done', 'simple-task-management'),
        );
    }

    private static function allowed_priorities() {
        return array(
            'low'    => __('Low', 'simple-task-management'),
            'medium' => __('Medium', 'simple-task-management'),
            'high'   => __('High', 'simple-task-management'),
        );
    }

    private static function status_badge_class($status) {
        switch ($status) {
            case 'done':
                return 'stm-badge-done';
            case 'in_progress':
                return 'stm-badge-progress';
            default:
                return 'stm-badge-todo';
        }
    }

    private static function priority_badge_class($priority) {
        switch ($priority) {
            case 'high':
                return 'stm-badge-high';
            case 'low':
                return 'stm-badge-low';
            default:
                return 'stm-badge-medium';
        }
    }

    private static function medal_for_rank($rank) {
        if (1 === $rank) {
            return '🥇';
        }
        if (2 === $rank) {
            return '🥈';
        }
        if (3 === $rank) {
            return '🥉';
        }

        return '#';
    }

    private static function short_text($text, $limit = 80) {
        $text = trim((string) $text);
        if ('' === $text) {
            return '';
        }

        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($text) <= $limit) {
                return $text;
            }
            return rtrim(mb_substr($text, 0, $limit - 1)) . '...';
        }

        if (strlen($text) <= $limit) {
            return $text;
        }
        return rtrim(substr($text, 0, $limit - 1)) . '...';
    }

    private static function redirect_with_notice($type, $text, $page = 'stm-task-manager') {
        $return_url = isset($_REQUEST['stm_return']) ? esc_url_raw(wp_unslash($_REQUEST['stm_return'])) : '';

        if ($return_url) {
            $url = remove_query_arg(array('stm_notice', 'stm_msg', 'edit_task'), $return_url);
            $url = add_query_arg(
                array(
                    'stm_notice' => sanitize_key($type),
                    'stm_msg'    => rawurlencode($text),
                ),
                $url
            );
        } else {
            $url = add_query_arg(
                array(
                    'page'       => $page,
                    'stm_notice' => sanitize_key($type),
                    'stm_msg'    => rawurlencode($text),
                ),
                admin_url('admin.php')
            );
        }

        wp_safe_redirect($url);
        exit;
    }

    private static function current_request_url() {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host   = isset($_SERVER['HTTP_HOST']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST'])) : '';
        $uri    = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';

        return esc_url_raw($scheme . $host . $uri);
    }

    private static function supports_overdue_workflow() {
        static $supported = null;

        if (null !== $supported) {
            return $supported;
        }

        global $wpdb;
        $column = $wpdb->get_var('SHOW COLUMNS FROM ' . self::table_name() . ' LIKE "overdue_status"');
        $supported = ! empty($column);

        return $supported;
    }

    private static function get_task($task_id) {
        global $wpdb;

        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . self::table_name() . ' WHERE id = %d', $task_id));
    }

    private static function get_tasks($status_filter = '', $search_term = '', $assigned_user_id = 0) {
        global $wpdb;

        $settings = self::get_settings();
        $where    = array();
        $args     = array();

        if ($status_filter && in_array($status_filter, array_keys(self::allowed_statuses()), true)) {
            $where[] = 'status = %s';
            $args[]  = $status_filter;
        }

        if ('' !== $search_term) {
            $where[] = '(title LIKE %s OR description LIKE %s)';
            $like    = '%' . $wpdb->esc_like($search_term) . '%';
            $args[]  = $like;
            $args[]  = $like;
        }

        if ($assigned_user_id > 0) {
            $where[] = 'assigned_to = %d';
            $args[]  = (int) $assigned_user_id;
        }

        if (! self::current_user_can_manage_settings() && ! empty($settings['employee_own_tasks_only'])) {
            $where[] = '(created_by = %d OR assigned_to = %d)';
            $args[]  = get_current_user_id();
            $args[]  = get_current_user_id();
        } elseif ('own' === $settings['visibility'] && ! self::current_user_can_manage_settings()) {
            $where[] = '(created_by = %d OR assigned_to = %d)';
            $args[]  = get_current_user_id();
            $args[]  = get_current_user_id();
        }

        $sql = 'SELECT * FROM ' . self::table_name();

        if (! empty($where)) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }

        $sql .= ' ORDER BY FIELD(status, "todo", "in_progress", "done"), due_date IS NULL, due_date ASC, id DESC';

        if (! empty($args)) {
            $sql = $wpdb->prepare($sql, $args);
        }

        return $wpdb->get_results($sql);
    }

    private static function get_overdue_tasks_for_current_user() {
        if (! self::supports_overdue_workflow()) {
            return array();
        }

        $all = self::get_tasks('', '');
        $results = array();
        $now = current_time('timestamp');

        foreach ($all as $task) {
            if (empty($task->due_date)) {
                continue;
            }

            $due_ts = strtotime($task->due_date . ' 23:59:59');
            if (! $due_ts || $due_ts >= $now) {
                continue;
            }

            $status = isset($task->overdue_status) ? (string) $task->overdue_status : 'none';
            if ('done' !== $task->status || in_array($status, array('required', 'pending', 'rejected'), true)) {
                $results[] = $task;
            }
        }

        return $results;
    }

    private static function get_pending_overdue_for_review() {
        if (! self::supports_overdue_workflow()) {
            return array();
        }

        global $wpdb;

        return $wpdb->get_results(
            'SELECT * FROM ' . self::table_name() . ' WHERE overdue_status IN ("pending","required") ORDER BY due_date ASC, id DESC'
        );
    }

    public static function render_frontend_dashboard_shortcode() {
        if (! defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();

        $current_url = self::current_request_url();
        $base_return_url = remove_query_arg(array('stm_notice', 'stm_msg', 'edit_task', 'stm_overdue_ok_id', 'stmf_search', 'stmf_status', 'stmf_assigned_user_filter', 'stm_refresh'), $current_url);
        $tasks_page_url = self::frontend_tasks_home_url();
        $frontend_refresh_url = add_query_arg('stm_refresh', time(), $tasks_page_url);
        $settings = self::get_settings();
        $guest_login_title = (string) $settings['guest_login_title'];
        $guest_login_subtitle = (string) $settings['guest_login_subtitle'];
        $guest_login_button_text = (string) $settings['guest_login_button_text'];
        $guest_login_note = (string) $settings['guest_login_note'];
        $guest_btn_start = (string) $settings['guest_login_button_color_start'];
        $guest_btn_end = (string) $settings['guest_login_button_color_end'];
        $guest_btn_text = (string) $settings['guest_login_button_text_color'];
        $guest_btn_radius = (int) $settings['guest_login_button_radius'];

        if (! is_user_logged_in()) {
            $login_url = self::frontend_login_url($tasks_page_url);
            ob_start();
            ?>
            <div class="stm-front stm-front-guest">
                <style>
                    .stm-front { font-family: "Manrope", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color:#1e293b; }
                    .stm-front-guest {
                        background:
                            radial-gradient(circle at 0% 0%, rgba(56,189,248,.16), transparent 45%),
                            radial-gradient(circle at 100% 100%, rgba(167,139,250,.15), transparent 50%),
                            #f8fafc;
                        border:1px solid #dbeafe;
                        border-radius:20px;
                        padding:26px;
                        box-shadow:0 16px 40px rgba(30,41,59,.08);
                    }
                    .stm-guest-wrap { max-width:760px; margin:0 auto; text-align:center; }
                    .stm-guest-icon {
                        width:64px; height:64px; border-radius:16px; margin:0 auto 14px;
                        display:grid; place-items:center; font-size:28px;
                        background:linear-gradient(135deg, #e0f2fe, #ede9fe);
                        border:1px solid #bfdbfe;
                    }
                    .stm-guest-title { margin:0 0 8px; font-size:32px; line-height:1.1; color:#0f172a; font-weight:800; }
                    .stm-guest-sub { margin:0 auto 16px; max-width:560px; color:#475569; font-size:16px; }
                    .stm-guest-btn {
                        display:inline-flex; align-items:center; gap:8px; text-decoration:none;
                        background:linear-gradient(90deg, <?php echo esc_attr($guest_btn_start); ?>, <?php echo esc_attr($guest_btn_end); ?>);
                        color:<?php echo esc_attr($guest_btn_text); ?>; border-radius:<?php echo esc_attr((string) $guest_btn_radius); ?>px; padding:12px 18px; font-weight:700;
                        box-shadow:0 10px 26px rgba(37,99,235,.24);
                    }
                    .stm-guest-note { margin-top:12px; font-size:13px; color:#64748b; }
                    .stm-guest-credit { margin-top:16px; font-size:12px; opacity:.56; color:#334155; }
                    .stm-guest-credit a { color:inherit; text-decoration:none; transition:opacity .16s ease, color .16s ease; }
                    .stm-guest-credit a:hover { opacity:1; color:#0f172a; }
                    @media (max-width: 640px) {
                        .stm-front-guest { padding:18px; border-radius:14px; }
                        .stm-guest-title { font-size:26px; }
                        .stm-guest-sub { font-size:15px; }
                        .stm-guest-btn { width:100%; justify-content:center; }
                    }
                </style>
                <div class="stm-guest-wrap">
                    <div class="stm-guest-icon">🔐</div>
                    <h2 class="stm-guest-title"><?php echo esc_html($guest_login_title); ?></h2>
                    <p class="stm-guest-sub"><?php echo esc_html($guest_login_subtitle); ?></p>
                    <a class="stm-guest-btn" href="<?php echo esc_url($login_url); ?>">
                        <span>→</span>
                        <?php echo esc_html($guest_login_button_text); ?>
                    </a>
                    <div class="stm-guest-note"><?php echo esc_html($guest_login_note); ?></div>
                    <div class="stm-guest-credit">
                        Design By - <a href="https://amandubey.com" target="_blank" rel="noopener noreferrer">Aman Dubey</a>
                    </div>
                </div>
            </div>
            <?php
            return (string) ob_get_clean();
        }

        if (! self::current_user_can_access_frontend_dashboard()) {
            return '<div class="stm-front"><p>' . esc_html__('You are not allowed to view this dashboard.', 'simple-task-management') . '</p></div>';
        }

        $statuses   = self::allowed_statuses();
        $priorities = self::allowed_priorities();
        $settings   = self::get_settings();
        $dashboard_title = ! empty($settings['dashboard_title']) ? (string) $settings['dashboard_title'] : 'Daily Taks';
        wp_enqueue_style('dashicons');
        $is_settings_manager = self::current_user_can_manage_settings();
        $assignable_users = self::get_assignable_users();
        $leaderboard      = self::get_leaderboard(10);

        $editing_id = isset($_GET['edit_task']) ? absint($_GET['edit_task']) : 0;
        $editing_task = $editing_id ? self::get_task($editing_id) : null;
        if ($editing_task && ! self::current_user_can_edit_task_item($editing_task)) {
            return '<div class="stm-front"><p>' . esc_html__('You are not allowed to edit this task.', 'simple-task-management') . '</p></div>';
        }

        $search     = isset($_GET['stmf_search']) ? sanitize_text_field(wp_unslash($_GET['stmf_search'])) : '';
        $status     = isset($_GET['stmf_status']) ? sanitize_key(wp_unslash($_GET['stmf_status'])) : '';
        $assigned_user_filter = isset($_GET['stmf_assigned_user_filter']) ? absint($_GET['stmf_assigned_user_filter']) : 0;
        $show_admin_employee_filter = $is_settings_manager && ! empty($settings['admin_employee_filter_enabled']);
        if (! $show_admin_employee_filter) {
            $assigned_user_filter = 0;
        }
        $all_tasks  = self::get_tasks($status, $search, $assigned_user_filter);
        $per_page = max(1, (int) $settings['tasks_per_page']);
        $current_page = isset($_GET['stmf_page']) ? max(1, absint($_GET['stmf_page'])) : 1;
        $total_tasks = count($all_tasks);
        $total_pages = max(1, (int) ceil($total_tasks / $per_page));
        if ($current_page > $total_pages) {
            $current_page = $total_pages;
        }
        $tasks = array_slice($all_tasks, ($current_page - 1) * $per_page, $per_page);
        $frontend_pagination_base_url = remove_query_arg(
            array('stm_notice', 'stm_msg', 'edit_task', 'stm_overdue_ok_id', 'stm_refresh', 'stmf_page'),
            $current_url
        );
        $overdue_tasks = self::get_overdue_tasks_for_current_user();
        $pending_overdue = $is_settings_manager ? self::get_pending_overdue_for_review() : array();

        $notice_type = isset($_GET['stm_notice']) ? sanitize_key(wp_unslash($_GET['stm_notice'])) : '';
        $notice_msg  = isset($_GET['stm_msg']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['stm_msg']))) : '';
        $overdue_ok_id = isset($_GET['stm_overdue_ok_id']) ? absint($_GET['stm_overdue_ok_id']) : 0;
        $suppress_top_notice = ('Overdue reason submitted for review.' === $notice_msg);

        $todo = 0;
        $progress = 0;
        $done = 0;

        foreach ($all_tasks as $task) {
            if ('todo' === $task->status) {
                $todo++;
            } elseif ('in_progress' === $task->status) {
                $progress++;
            } elseif ('done' === $task->status) {
                $done++;
            }
        }

        $my_points = (int) get_user_meta(get_current_user_id(), self::USER_POINTS_META, true);
        $auto_refresh_enabled = ! empty($settings['auto_refresh_enabled'])
            && ! empty($settings['auto_refresh_frontend'])
            && self::auto_refresh_allowed_for_scope((string) $settings['auto_refresh_user_scope'], $is_settings_manager);
        $auto_refresh_only_visible = ! empty($settings['auto_refresh_only_visible']);
        $auto_refresh_ms = max(10, min(3600, (int) $settings['auto_refresh_interval'])) * 1000;
        $show_assigned_to = $is_settings_manager;

        ob_start();
        ?>
        <div class="stm-front">
            <style>
                .stm-front { font-family: "Manrope", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color:#1e293b; max-width:1280px; margin:0 auto; overflow-x:hidden; }
                .stm-front *, .stm-front *::before, .stm-front *::after { box-sizing:border-box; }
                .stm-front .stm-shell { background:#f8fafc; border:1px solid #dbeafe; border-radius:18px; padding:14px; box-shadow:0 10px 28px rgba(15,23,42,.06); }
                .stm-front .stm-head { display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; margin:4px 2px 20px; }
                .stm-front .stm-title { margin:0; font-size:40px; line-height:1.05; color:#0f172a; font-weight:800; letter-spacing:-.02em; }
                .stm-front .stm-head-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; justify-content:flex-end; }
                .stm-front .stm-user {
                    background:#fff; border:1px solid #dbeafe; border-radius:999px;
                    padding:8px 12px; font-size:15px; color:#334155;
                }
                .stm-front .stm-user strong { color:#0f766e; }
                .stm-front .stm-top-link {
                    display:inline-flex; align-items:center; justify-content:center;
                    min-height:34px; padding:6px 12px; border-radius:10px; font-size:13px;
                    text-decoration:none; border:1px solid #bfdbfe; background:#eff6ff; color:#1d4ed8; font-weight:700;
                }
                .stm-front .stm-metrics { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; margin-bottom:14px; }
                .stm-front .stm-metric { border:1px solid #e2e8f0; border-radius:14px; padding:14px; background:#fff; position:relative; overflow:hidden; }
                .stm-front .stm-metric::before {
                    content:"";
                    position:absolute;
                    right:-18px;
                    top:-18px;
                    width:94px;
                    height:94px;
                    border-radius:999px;
                    opacity:.92;
                    pointer-events:none;
                }
                .stm-front .stm-metric::after {
                    content:"";
                    position:absolute;
                    right:18px;
                    top:18px;
                    width:32px;
                    height:32px;
                    opacity:.72;
                    background-repeat:no-repeat;
                    background-size:contain;
                    pointer-events:none;
                }
                .stm-front .stm-metric h4 { margin:0 0 4px; font-size:14px; color:#475569; text-transform:uppercase; letter-spacing:.04em; }
                .stm-front .stm-metric .v { font-size:34px; line-height:1; color:#0f172a; font-weight:800; }
                .stm-front .m1 { background:linear-gradient(135deg, #eef5ff, #f7fbff); }
                .stm-front .m2 { background:linear-gradient(135deg, #fff5e9, #fffaf2); }
                .stm-front .m3 { background:linear-gradient(135deg, #ecfff3, #f7fff9); }
                .stm-front .m4 { background:linear-gradient(135deg, #f2efff, #f8f6ff); }
                .stm-front .m1::before { background:radial-gradient(circle at 30% 30%, rgba(37,99,235,.18) 0%, rgba(37,99,235,.08) 62%, rgba(37,99,235,0) 100%); }
                .stm-front .m2::before { background:radial-gradient(circle at 30% 30%, rgba(194,65,12,.18) 0%, rgba(194,65,12,.08) 62%, rgba(194,65,12,0) 100%); }
                .stm-front .m3::before { background:radial-gradient(circle at 30% 30%, rgba(21,128,61,.18) 0%, rgba(21,128,61,.08) 62%, rgba(21,128,61,0) 100%); }
                .stm-front .m4::before { background:radial-gradient(circle at 30% 30%, rgba(109,40,217,.18) 0%, rgba(109,40,217,.08) 62%, rgba(109,40,217,0) 100%); }
                .stm-front .m1::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232563eb' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='6' y='4' width='12' height='16' rx='2'/%3E%3Cpath d='M9 2h6v4H9z'/%3E%3Cpath d='M9 10h6M9 14h4'/%3E%3C/svg%3E"); }
                .stm-front .m2::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23c2410c' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 12a9 9 0 10-3 6.7'/%3E%3Cpath d='M21 4v8h-8'/%3E%3C/svg%3E"); }
                .stm-front .m3::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2315803d' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='9'/%3E%3Cpath d='M8.5 12.5l2.2 2.2 4.8-4.8'/%3E%3C/svg%3E"); }
                .stm-front .m4::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236d28d9' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='8' r='2.5'/%3E%3Cpath d='M8.5 20h7l1.2-4.5L12 13l-4.7 2.5z'/%3E%3Cpath d='M6 10l-2 2m14-2l2 2'/%3E%3C/svg%3E"); }
                .stm-front .stm-quick-actions { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:12px; }
                .stm-front .quick-btn {
                    display:inline-flex; align-items:center; gap:6px; text-decoration:none;
                    border-radius:10px; border:1px solid #bfdbfe; background:#eff6ff;
                    color:#1d4ed8; font-weight:700; font-size:13px; padding:8px 12px; min-height:36px;
                    cursor:pointer;
                }
                .stm-front .quick-btn.secondary { border-color:#dbeafe; background:#f8fbff; color:#334155; }
                .stm-front .quick-btn .dashicons { font-size:14px; width:14px; height:14px; line-height:14px; }

                .stm-front .stm-wrap { border:1px solid #e2e8f0; border-radius:14px; padding:12px; background:#fff; }
                .stm-front .stm-layout { display:grid; grid-template-columns:1fr; gap:14px; align-items:start; }
                .stm-front .stm-layout > div:first-child { display:none; }
                .stm-front .stm-filter { display:grid; grid-template-columns:minmax(220px,1fr) 170px 210px auto; gap:8px; margin-bottom:12px; align-items:center; }
                .stm-front .stm-filter.no-employee { grid-template-columns:minmax(220px,1fr) 170px auto; }
                .stm-front .stm-filter > * { width:100%; min-width:0; }
                .stm-front input,.stm-front select,.stm-front button { min-height:40px; border-radius:10px; border:1px solid #cbd5e1; padding:8px 10px; font-size:14px; }
                .stm-front button { background:linear-gradient(90deg, #2563eb, #4f46e5); color:#fff; border-color:#2563eb; cursor:pointer; font-weight:700; }
                .stm-front .btn-secondary { background:#fff; color:#334155; border-color:#cbd5e1; margin-left:6px; }
                .stm-front .tiny {
                    min-height:32px; padding:6px 10px; font-size:12px; border-radius:10px;
                    display:inline-flex; align-items:center; gap:6px; text-decoration:none; margin-right:0;
                }
                .stm-front .tiny .dashicons { font-size:14px; width:14px; height:14px; line-height:14px; }
                .stm-front .tiny.view { background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; }
                .stm-front .tiny.edit { background:#eef2ff; color:#3730a3; border:1px solid #c7d2fe; }
                .stm-front .tiny.status { background:#fff7ed; color:#9a3412; border:1px solid #fed7aa; }
                .stm-front .tiny.delete { background:#fef2f2; color:#b91c1c; border:1px solid #fecaca; }
                .stm-front .table-actions { white-space:nowrap; }
                .stm-front .table-actions .action-icon {
                    position:relative;
                    width:34px;
                    min-width:34px;
                    height:34px;
                    padding:0;
                    justify-content:center;
                    border-radius:10px;
                }
                .stm-front .table-actions .action-icon::after {
                    content:attr(data-tip);
                    position:absolute;
                    left:50%;
                    bottom:calc(100% + 6px);
                    transform:translateX(-50%) translateY(4px);
                    background:#0f172a;
                    color:#fff;
                    font-size:11px;
                    line-height:1.2;
                    padding:5px 7px;
                    border-radius:6px;
                    white-space:nowrap;
                    opacity:0;
                    pointer-events:none;
                    transition:all .16s ease;
                    z-index:20;
                }
                .stm-front .table-actions .action-icon:hover::after { opacity:1; transform:translateX(-50%) translateY(0); }

                .stm-front .table-wrap { overflow-x:auto; border:1px solid #dbe7f7; border-radius:12px; background:#fff; box-shadow:0 8px 24px rgba(15,23,42,.06); }
                .stm-front table { width:100%; border-collapse:collapse; border-spacing:0; min-width:860px; box-shadow:none !important; }
                .stm-front th,.stm-front td {
                    border:0 !important;
                    border-bottom:1px solid #edf2fb !important;
                    border-left:none !important;
                    border-right:none !important;
                    box-shadow:none !important;
                    padding:13px 12px;
                    text-align:left;
                    font-size:14px;
                    vertical-align:top;
                }
                .stm-front thead th {
                    background:#f5f9ff;
                    color:#334155;
                    font-weight:700;
                    text-transform:uppercase;
                    letter-spacing:.02em;
                    font-size:12px;
                    border-bottom:1px solid #dbe7f7;
                }
                .stm-front thead th:first-child { border-top-left-radius:12px; }
                .stm-front thead th:last-child { border-top-right-radius:12px; }
                .stm-front tbody tr:nth-child(even) { background:#fbfdff; }
                .stm-front tbody tr:hover { background:#ecf5ff; }
                .stm-front .desc { display:block; margin-top:2px; color:#64748b; font-size:12px; }
                .stm-front .stm-badge { border-radius:999px; padding:3px 9px; font-size:11px; font-weight:700; display:inline-block; text-transform:uppercase; letter-spacing:.03em; }
                .stm-front .todo { background:#eaf2ff; color:#1d4ed8; }
                .stm-front .progress { background:#fff3e8; color:#c2410c; }
                .stm-front .done { background:#eafcf1; color:#15803d; }
                .stm-front .low { background:#f8fafc; color:#475467; }
                .stm-front .medium { background:#eff8ff; color:#175cd3; }
                .stm-front .high { background:#fef2f2; color:#b42318; }
                .stm-front .points { color:#0f766e; font-weight:700; }

                .stm-front .task-cards { display:none; }
                .stm-front .task-card { border:1px solid #dbe7f7; border-radius:14px; padding:14px; margin-bottom:12px; background:#fff; box-shadow:0 2px 10px rgba(15,23,42,.04); }
                .stm-front .task-card-head { display:flex; justify-content:space-between; align-items:flex-start; gap:10px; }
                .stm-front .task-card h5 { margin:0 0 6px; font-size:18px; color:#0f172a; line-height:1.2; }
                .stm-front .task-toggle {
                    border:1px solid #cbd5e1; background:#fff; color:#334155;
                    border-radius:9px; padding:5px 10px; font-size:12px; font-weight:700; cursor:pointer; min-height:30px;
                }
                .stm-front .task-details { display:none; }
                .stm-front .task-card.is-open .task-details { display:block; }
                .stm-front .task-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; margin-top:10px; }
                .stm-front .task-grid > div {
                    border:1px solid #e2e8f0;
                    background:#f8fbff;
                    border-radius:10px;
                    padding:8px 10px;
                    min-height:56px;
                    display:flex;
                    flex-direction:column;
                    justify-content:center;
                }
                .stm-front .task-grid .stm-badge { width:max-content; }
                .stm-front .task-actions { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
                .stm-front .task-actions .tiny { flex:1 1 calc(50% - 8px); justify-content:center; }
                .stm-front .stm-pagination { margin-top:10px; display:flex; gap:6px; flex-wrap:wrap; }
                .stm-front .stm-page-link {
                    display:inline-flex; align-items:center; justify-content:center;
                    min-height:32px; min-width:32px; padding:4px 10px;
                    border:1px solid #cbd5e1; border-radius:8px; background:#fff; color:#334155;
                    text-decoration:none; font-size:12px; font-weight:700;
                }
                .stm-front .stm-page-link.is-active { border-color:#2563eb; background:#eff6ff; color:#1d4ed8; }
                .stm-front .k { color:#64748b; font-size:11px; text-transform:uppercase; margin-bottom:2px; display:block; }
                .stm-front .leader { list-style:none; margin:0; padding:0; }
                .stm-front .leader li { display:flex; justify-content:space-between; border-bottom:1px solid #edf2f7; padding:7px 0; }
                .stm-front .notice { border:1px solid #dbeafe; border-radius:10px; padding:10px; margin:0 0 10px; background:#f8fbff; }
                .stm-front .notice.error { border-color:#fecaca; background:#fef2f2; }
                .stm-front .overdue-card { border:1px solid #fecaca; border-radius:12px; padding:10px; margin-bottom:10px; background:#fff7f7; }
                .stm-front .overdue-card h5 { margin:0 0 6px; color:#9f1239; }
                .stm-front .overdue-reason { width:100%; min-height:70px; border:1px solid #fca5a5; border-radius:8px; padding:8px; }
                .stm-front .review-card { border:1px solid #fde68a; background:#fffbeb; border-radius:10px; padding:10px; margin-bottom:10px; }
                .stm-front dialog { border:none; border-radius:12px; width:min(560px,92vw); }
                .stm-front dialog::backdrop { background:rgba(15,23,42,.35); }
                .stm-front .stm-credit {
                    margin-top:12px;
                    text-align:center;
                    font-size:12px;
                    opacity:.56;
                    color:#334155;
                }
                .stm-front .stm-credit a {
                    color:inherit;
                    text-decoration:none;
                    transition:opacity .16s ease, color .16s ease;
                }
                .stm-front .stm-credit a:hover {
                    opacity:1;
                    color:#0f172a;
                }
                .stm-front .stm-dialog-head {
                    display:flex; justify-content:space-between; align-items:center;
                    padding:10px 12px; border-bottom:1px solid #e2e8f0;
                }
                .stm-front .stm-dialog-body { padding:12px; max-height:72vh; overflow:auto; }

                @media (max-width: 1100px) {
                    .stm-front .stm-title { font-size:32px; }
                    .stm-front .stm-metrics { grid-template-columns:repeat(2,minmax(0,1fr)); }
                }
                @media (max-width: 1024px) {
                    .stm-front .stm-shell { padding:10px; border-radius:12px; }
                    .stm-front .stm-shell, .stm-front .stm-wrap, .stm-front .task-cards, .stm-front .task-card { width:100%; overflow:hidden; }
                    .stm-front .stm-title { font-size:28px; }
                    .stm-front .stm-filter { grid-template-columns:1fr 138px; }
                    .stm-front .stm-filter.no-employee > input[type="search"] { grid-column:1 / -1; }
                    .stm-front .stm-filter.no-employee > select { grid-column:1 / 2; }
                    .stm-front .stm-filter.no-employee > button { grid-column:2 / 3; }
                    .stm-front .stm-filter:not(.no-employee) { grid-template-columns:1fr 1fr; }
                    .stm-front .stm-filter:not(.no-employee) > input[type="search"] { grid-column:1 / -1; }
                    .stm-front .stm-filter:not(.no-employee) > button { grid-column:1 / -1; }
                    .stm-front .stm-filter input,
                    .stm-front .stm-filter select,
                    .stm-front .stm-filter button { width:100% !important; max-width:100%; min-width:0; }
                    .stm-front .stm-filter > button { width:100%; margin:0; }
                    .stm-front .stm-head { margin-bottom:16px; }
                    .stm-front .stm-head-right { width:100%; justify-content:flex-start; flex-wrap:wrap; overflow:visible; }
                    .stm-front .stm-top-link { flex:0 1 auto; }
                    .stm-front .stm-user { width:auto; border-radius:999px; flex:0 1 auto; }
                    .stm-front .table-wrap { display:none; }
                    .stm-front .task-cards { display:block; }
                    .stm-front .task-card { padding:12px; }
                    .stm-front .task-card h5 { font-size:17px; }
                    .stm-front .task-card-head { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:10px; align-items:start; }
                    .stm-front .task-toggle { display:inline-flex; }
                    .stm-front .task-details { display:none; }
                    .stm-front .task-grid { grid-template-columns:1fr; }
                    .stm-front .task-grid > div { min-height:0; }
                    .stm-front .task-card .desc { white-space:normal; overflow-wrap:anywhere; word-break:break-word; }
                    .stm-front .task-actions .tiny { flex:1 1 calc(50% - 8px); width:auto; }
                }
                @media (max-width: 460px) {
                    .stm-front .stm-filter.no-employee { grid-template-columns:minmax(0,1fr) 120px; }
                    .stm-front .stm-filter.no-employee > input[type="search"] { grid-column:1 / -1 !important; }
                    .stm-front .stm-filter.no-employee > select { grid-column:1 / 2 !important; }
                    .stm-front .stm-filter.no-employee > button { grid-column:2 / 3 !important; min-height:44px; }
                    .stm-front .stm-filter:not(.no-employee) { grid-template-columns:1fr; }
                    .stm-front .stm-filter:not(.no-employee) > * { grid-column:1 / -1 !important; }
                    .stm-front .task-grid { grid-template-columns:1fr; }
                    .stm-front .task-card-head { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:8px; align-items:start; }
                    .stm-front .task-actions .tiny { flex:1 1 100%; width:100%; }
                }
            </style>
            <div class="stm-shell">
                <?php if ($notice_type && $notice_msg && ! $suppress_top_notice) : ?>
                    <div class="notice <?php echo esc_attr('success' === $notice_type ? '' : 'error'); ?>"><?php echo esc_html($notice_msg); ?></div>
                <?php endif; ?>
                <div class="stm-head">
                    <h3 class="stm-title"><?php echo esc_html($dashboard_title); ?></h3>
                    <div class="stm-head-right">
                        <a class="stm-top-link" href="<?php echo esc_url($tasks_page_url); ?>"><?php echo esc_html__('Tasks Home', 'simple-task-management'); ?></a>
                        <a class="stm-top-link" href="<?php echo esc_url($frontend_refresh_url); ?>"><?php echo esc_html__('Refresh', 'simple-task-management'); ?></a>
                        <div class="stm-user"><?php echo esc_html(wp_get_current_user()->display_name); ?> · <strong><?php echo esc_html__('Points', 'simple-task-management'); ?>: <?php echo esc_html((string) $my_points); ?></strong></div>
                    </div>
                </div>

                <div class="stm-metrics">
                    <div class="stm-metric m1"><h4><?php echo esc_html__('To Do', 'simple-task-management'); ?></h4><div class="v"><?php echo esc_html((string) $todo); ?></div></div>
                    <div class="stm-metric m2"><h4><?php echo esc_html__('In Progress', 'simple-task-management'); ?></h4><div class="v"><?php echo esc_html((string) $progress); ?></div></div>
                    <div class="stm-metric m3"><h4><?php echo esc_html__('Completed', 'simple-task-management'); ?></h4><div class="v"><?php echo esc_html((string) $done); ?></div></div>
                    <div class="stm-metric m4"><h4><?php echo esc_html__('My Reward Points', 'simple-task-management'); ?></h4><div class="v"><?php echo esc_html((string) $my_points); ?></div></div>
                </div>

                <div class="stm-quick-actions">
                    <?php if ($is_settings_manager) : ?>
                        <button type="button" class="quick-btn" id="stmf-open-task-dialog">
                            <span class="dashicons dashicons-plus-alt2"></span>
                            <?php echo esc_html($editing_task ? __('Edit Task', 'simple-task-management') : __('Add New Task', 'simple-task-management')); ?>
                        </button>
                    <?php endif; ?>
                    <button type="button" class="quick-btn secondary" id="stmf-open-leaderboard-dialog">
                        <span class="dashicons dashicons-awards"></span>
                        <?php echo esc_html__('Leaderboard', 'simple-task-management'); ?>
                    </button>
                </div>

                <?php if (! empty($overdue_tasks)) : ?>
                    <div class="stm-wrap" style="margin-bottom:12px;">
                        <h4 style="margin:0 0 10px;"><?php echo esc_html__('Overdue Tasks - Submit Reason', 'simple-task-management'); ?></h4>
                        <?php foreach ($overdue_tasks as $overdue_task) : ?>
                            <div class="overdue-card">
                                <h5><?php echo esc_html($overdue_task->title); ?> (<?php echo esc_html($overdue_task->due_date); ?>)</h5>
                                <?php if ('pending' === $overdue_task->overdue_status) : ?>
                                    <p style="margin:0 0 8px;"><?php echo esc_html__('Reason submitted and pending review by admin/editor.', 'simple-task-management'); ?></p>
                                    <div style="font-size:13px;color:#475569;"><?php echo esc_html((string) $overdue_task->overdue_reason); ?></div>
                                <?php else : ?>
                                    <p style="margin:0 0 8px;"><?php echo esc_html__('Task is overdue. Submit reason for late completion/review.', 'simple-task-management'); ?></p>
                                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                        <input type="hidden" name="action" value="stm_submit_overdue_reason">
                                        <input type="hidden" name="task_id" value="<?php echo esc_attr((string) (int) $overdue_task->id); ?>">
                                        <input type="hidden" name="stm_return" value="<?php echo esc_attr($base_return_url); ?>">
                                        <?php wp_nonce_field('stm_submit_overdue_reason'); ?>
                                        <textarea class="overdue-reason" name="overdue_reason" required placeholder="<?php echo esc_attr__('Why was this task delayed?', 'simple-task-management'); ?>"><?php echo esc_textarea((string) $overdue_task->overdue_reason); ?></textarea>
                                        <div style="margin-top:8px;">
                                            <button type="submit" class="tiny"><?php echo esc_html__('Submit Reason', 'simple-task-management'); ?></button>
                                            <span style="font-size:12px;color:#64748b;margin-left:8px;"><?php echo esc_html__('Current status:', 'simple-task-management'); ?> <?php echo esc_html($overdue_task->overdue_status ? $overdue_task->overdue_status : 'none'); ?></span>
                                        </div>
                                        <?php if ($overdue_ok_id === (int) $overdue_task->id) : ?>
                                            <div style="margin-top:8px;color:#15803d;font-size:12px;font-weight:600;"><?php echo esc_html__('Overdue reason submitted for review.', 'simple-task-management'); ?></div>
                                        <?php endif; ?>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if (! empty($pending_overdue)) : ?>
                    <div class="stm-wrap" style="margin-bottom:12px;">
                        <h4 style="margin:0 0 10px;"><?php echo esc_html__('Overdue Reviews (Admin/Editor)', 'simple-task-management'); ?></h4>
                        <?php foreach ($pending_overdue as $pending_task) : ?>
                            <div class="review-card">
                                <strong><?php echo esc_html($pending_task->title); ?></strong>
                                <div style="font-size:12px;color:#475569;margin-top:4px;">
                                    <?php echo esc_html__('Assigned By:', 'simple-task-management'); ?> <?php echo esc_html(self::user_name((int) $pending_task->created_by)); ?>
                                    · <?php echo esc_html__('Assigned To:', 'simple-task-management'); ?> <?php echo esc_html(self::user_name((int) $pending_task->assigned_to)); ?>
                                </div>
                                <div style="font-size:13px;margin:6px 0;"><?php echo esc_html__('Reason:', 'simple-task-management'); ?> <?php echo esc_html((string) $pending_task->overdue_reason); ?></div>
                                <?php
                                $accept_url = wp_nonce_url(
                                    add_query_arg(
                                        array(
                                            'action'     => 'stm_review_overdue_reason',
                                            'task_id'    => (int) $pending_task->id,
                                            'decision'   => 'accept',
                                            'stm_return' => $base_return_url,
                                        ),
                                        admin_url('admin-post.php')
                                    ),
                                    'stm_review_overdue_reason'
                                );
                                $reject_url = wp_nonce_url(
                                    add_query_arg(
                                        array(
                                            'action'     => 'stm_review_overdue_reason',
                                            'task_id'    => (int) $pending_task->id,
                                            'decision'   => 'reject',
                                            'stm_return' => $base_return_url,
                                        ),
                                        admin_url('admin-post.php')
                                    ),
                                    'stm_review_overdue_reason'
                                );
                                ?>
                                <a class="tiny" href="<?php echo esc_url($accept_url); ?>">✅ <?php echo esc_html__('Accept', 'simple-task-management'); ?></a>
                                <a class="tiny" href="<?php echo esc_url($reject_url); ?>">❌ <?php echo esc_html__('Reject', 'simple-task-management'); ?></a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="stm-layout">
                    <?php if ($is_settings_manager) : ?>
                    <div>
                        <div class="stm-wrap" style="margin-bottom:12px;">
                            <h4 style="margin:0 0 10px;"><?php echo esc_html($editing_task ? 'Edit Task' : 'Add New Task'); ?></h4>
                            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                <input type="hidden" name="action" value="stm_save_task" />
                                <input type="hidden" name="task_id" value="<?php echo esc_attr($editing_task ? (int) $editing_task->id : 0); ?>" />
                                <input type="hidden" name="stm_return" value="<?php echo esc_attr($base_return_url); ?>" />
                                <?php wp_nonce_field('stm_save_task'); ?>
                                <p><input class="stm-input" name="title" required placeholder="<?php echo esc_attr__('Task title', 'simple-task-management'); ?>" value="<?php echo esc_attr($editing_task ? $editing_task->title : ''); ?>"></p>
                                <p><textarea class="stm-textarea stm-input" name="description" placeholder="<?php echo esc_attr__('Description', 'simple-task-management'); ?>"><?php echo esc_textarea($editing_task ? $editing_task->description : ''); ?></textarea></p>
                                <p><select class="stm-select stm-input" name="assigned_to"><option value="0"><?php echo esc_html__('Unassigned', 'simple-task-management'); ?></option><?php foreach ($assignable_users as $assignable_user) : ?><option value="<?php echo esc_attr((string) $assignable_user->ID); ?>" <?php selected($editing_task ? (int) $editing_task->assigned_to : 0, (int) $assignable_user->ID); ?>><?php echo esc_html($assignable_user->display_name); ?></option><?php endforeach; ?></select></p>
                                <p><input class="stm-input" name="due_date" type="date" value="<?php echo esc_attr($editing_task ? $editing_task->due_date : ''); ?>" <?php echo ! empty($settings['require_due_date']) ? 'required' : ''; ?>></p>
                                <p><select class="stm-select stm-input" name="priority"><?php foreach ($priorities as $priority_key => $priority_label) : ?><option value="<?php echo esc_attr($priority_key); ?>" <?php selected($editing_task ? $editing_task->priority : $settings['default_priority'], $priority_key); ?>><?php echo esc_html($priority_label); ?></option><?php endforeach; ?></select></p>
                                <p><input class="stm-input" type="number" min="0" name="reward_points" placeholder="<?php echo esc_attr__('Reward Points', 'simple-task-management'); ?>" value="<?php echo esc_attr($editing_task ? (string) $editing_task->reward_points : (string) self::default_reward_for_priority($settings['default_priority'])); ?>"></p>
                                <button type="submit"><?php echo esc_html($editing_task ? __('Update Task', 'simple-task-management') : __('Create Task', 'simple-task-management')); ?></button>
                                <?php if ($editing_task) : ?><a class="btn-secondary tiny" href="<?php echo esc_url($base_return_url); ?>"><?php echo esc_html__('Cancel', 'simple-task-management'); ?></a><?php endif; ?>
                            </form>
                        </div>
                        <?php endif; ?>

                        <div class="stm-wrap">
                            <h4 style="margin:0 0 10px;"><?php echo esc_html__('Leaderboard', 'simple-task-management'); ?></h4>
                            <ul class="leader">
                                <?php if (empty($leaderboard)) : ?>
                                    <li><?php echo esc_html__('No points yet', 'simple-task-management'); ?></li>
                                <?php else : ?>
                                    <?php foreach ($leaderboard as $index => $row_user) : ?>
                                        <li><span><?php echo esc_html(self::medal_for_rank($index + 1) . ' ' . $row_user->display_name); ?></span><strong class="points"><?php echo esc_html((string) (int) get_user_meta($row_user->ID, self::USER_POINTS_META, true)); ?></strong></li>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php if ($is_settings_manager) : ?>
                    </div>
                    <?php endif; ?>

                    <div class="stm-wrap">
                        <form method="get" action="<?php echo esc_url($base_return_url); ?>" class="stm-filter <?php echo $show_admin_employee_filter ? '' : 'no-employee'; ?>">
                            <input type="search" name="stmf_search" value="<?php echo esc_attr($search); ?>" placeholder="<?php echo esc_attr__('Search tasks...', 'simple-task-management'); ?>">
                            <select name="stmf_status">
                                <option value=""><?php echo esc_html__('All Status', 'simple-task-management'); ?></option>
                                <?php foreach ($statuses as $status_key => $status_label) : ?>
                                    <option value="<?php echo esc_attr($status_key); ?>" <?php selected($status, $status_key); ?>><?php echo esc_html($status_label); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if ($show_admin_employee_filter) : ?>
                                <select name="stmf_assigned_user_filter">
                                    <option value="0"><?php echo esc_html__('All Employees', 'simple-task-management'); ?></option>
                                    <?php foreach ($assignable_users as $assignable_user) : ?>
                                        <option value="<?php echo esc_attr((string) $assignable_user->ID); ?>" <?php selected($assigned_user_filter, (int) $assignable_user->ID); ?>>
                                            <?php echo esc_html($assignable_user->display_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                            <button type="submit"><?php echo esc_html__('Apply', 'simple-task-management'); ?></button>
                        </form>

                        <div class="table-wrap">
                            <table>
                                <thead>
                                    <tr>
                                        <th><?php echo esc_html__('Task', 'simple-task-management'); ?></th>
                                        <th><?php echo esc_html__('Assigned By', 'simple-task-management'); ?></th>
                                        <?php if ($show_assigned_to) : ?><th><?php echo esc_html__('Assigned To', 'simple-task-management'); ?></th><?php endif; ?>
                                        <th><?php echo esc_html__('Priority', 'simple-task-management'); ?></th>
                                        <th><?php echo esc_html__('Status', 'simple-task-management'); ?></th>
                                        <th><?php echo esc_html__('Due', 'simple-task-management'); ?></th>
                                        <th><?php echo esc_html__('Reward', 'simple-task-management'); ?></th>
                                        <th><?php echo esc_html__('Actions', 'simple-task-management'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($tasks)) : ?>
                                        <tr><td colspan="<?php echo esc_attr($show_assigned_to ? '8' : '7'); ?>"><?php echo esc_html__('No tasks found.', 'simple-task-management'); ?></td></tr>
                                    <?php else : ?>
                                        <?php foreach ($tasks as $task) : ?>
                                            <tr>
                                                <td><?php echo esc_html($task->title); ?><?php if (! empty($task->description)) : ?><span class="desc"><?php echo esc_html(self::short_text($task->description, 80)); ?></span><?php endif; ?></td>
                                                <td><?php echo esc_html(self::user_name((int) $task->created_by)); ?></td>
                                                <?php if ($show_assigned_to) : ?><td><?php echo esc_html(self::user_name((int) $task->assigned_to)); ?></td><?php endif; ?>
                                                <td><span class="stm-badge <?php echo esc_attr(self::priority_badge_class($task->priority)); ?>"><?php echo esc_html(isset($priorities[$task->priority]) ? $priorities[$task->priority] : $task->priority); ?></span></td>
                                                <td><span class="stm-badge <?php echo esc_attr('in_progress' === $task->status ? 'progress' : ('done' === $task->status ? 'done' : 'todo')); ?>"><?php echo esc_html(isset($statuses[$task->status]) ? $statuses[$task->status] : $task->status); ?></span></td>
                                                <td><?php echo esc_html($task->due_date ? $task->due_date : 'No due date'); ?></td>
                                                <td class="points">+<?php echo esc_html((string) (int) $task->reward_points); ?></td>
                                                <td class="table-actions">
                                                    <button type="button" class="tiny view action-icon stmf-view-btn"
                                                        data-tip="<?php echo esc_attr__('View Task', 'simple-task-management'); ?>"
                                                        title="<?php echo esc_attr__('View Task', 'simple-task-management'); ?>"
                                                        aria-label="<?php echo esc_attr__('View Task', 'simple-task-management'); ?>"
                                                        data-title="<?php echo esc_attr($task->title); ?>"
                                                        data-description="<?php echo esc_attr((string) $task->description); ?>"
                                                        data-assignedby="<?php echo esc_attr(self::user_name((int) $task->created_by)); ?>"
                                                        data-assignedto="<?php echo esc_attr(self::user_name((int) $task->assigned_to)); ?>"
                                                        data-priority="<?php echo esc_attr(isset($priorities[$task->priority]) ? $priorities[$task->priority] : $task->priority); ?>"
                                                        data-status="<?php echo esc_attr(isset($statuses[$task->status]) ? $statuses[$task->status] : $task->status); ?>"
                                                        data-due="<?php echo esc_attr($task->due_date ? $task->due_date : 'No due date'); ?>"
                                                        data-reward="<?php echo esc_attr((string) (int) $task->reward_points); ?>">
                                                        <span class="dashicons dashicons-visibility"></span>
                                                    </button>
                                                    <?php
                                                    $base_action_args = array('stm_return' => $base_return_url, 'task_id' => (int) $task->id);
                                                    if ('todo' === $task->status) { $next_status = 'in_progress'; $next_label = __('Start', 'simple-task-management'); $next_icon = 'dashicons-controls-play'; }
                                                    elseif ('in_progress' === $task->status) { $next_status = 'done'; $next_label = __('Complete', 'simple-task-management'); $next_icon = 'dashicons-yes-alt'; }
                                                    else { $next_status = 'todo'; $next_label = __('Reopen', 'simple-task-management'); $next_icon = 'dashicons-update'; }
                                                    $status_url = wp_nonce_url(add_query_arg(array_merge($base_action_args, array('action' => 'stm_update_status', 'status' => $next_status)), admin_url('admin-post.php')), 'stm_update_status');
                                                    $delete_url = wp_nonce_url(add_query_arg(array_merge($base_action_args, array('action' => 'stm_delete_task')), admin_url('admin-post.php')), 'stm_delete_task');
                                                    $edit_url = add_query_arg('edit_task', (int) $task->id, $base_return_url);
                                                    ?>
                                                    <?php if (self::current_user_can_edit_task_item($task)) : ?><a class="tiny edit action-icon" data-tip="<?php echo esc_attr__('Edit Task', 'simple-task-management'); ?>" title="<?php echo esc_attr__('Edit Task', 'simple-task-management'); ?>" aria-label="<?php echo esc_attr__('Edit Task', 'simple-task-management'); ?>" href="<?php echo esc_url($edit_url); ?>"><span class="dashicons dashicons-edit"></span></a><?php endif; ?>
                                                    <?php if (self::current_user_can_change_task_status_item($task)) : ?><a class="tiny status action-icon" data-tip="<?php echo esc_attr($next_label); ?>" title="<?php echo esc_attr($next_label); ?>" aria-label="<?php echo esc_attr($next_label); ?>" href="<?php echo esc_url($status_url); ?>"><span class="dashicons <?php echo esc_attr($next_icon); ?>"></span></a><?php endif; ?>
                                                    <?php if (self::current_user_can_delete_task_item($task)) : ?><a class="tiny delete action-icon" data-tip="<?php echo esc_attr__('Delete Task', 'simple-task-management'); ?>" title="<?php echo esc_attr__('Delete Task', 'simple-task-management'); ?>" aria-label="<?php echo esc_attr__('Delete Task', 'simple-task-management'); ?>" href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Delete this task?');"><span class="dashicons dashicons-trash"></span></a><?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="task-cards">
                            <?php if (empty($tasks)) : ?>
                                <p><?php echo esc_html__('No tasks found.', 'simple-task-management'); ?></p>
                            <?php else : ?>
                                <?php foreach ($tasks as $task) : ?>
                                    <?php
                                    $status_badge_class = 'in_progress' === $task->status ? 'progress' : ('done' === $task->status ? 'done' : 'todo');
                                    $status_label = isset($statuses[$task->status]) ? $statuses[$task->status] : $task->status;
                                    ?>
                                    <article class="task-card">
                                        <div class="task-card-head">
                                            <div>
                                                <h5><?php echo esc_html($task->title); ?></h5>
                                                <span class="stm-badge <?php echo esc_attr($status_badge_class); ?>"><?php echo esc_html($status_label); ?></span>
                                            </div>
                                            <button type="button" class="task-toggle stm-task-toggle" aria-expanded="false"><?php echo esc_html__('Show details', 'simple-task-management'); ?></button>
                                        </div>
                                        <div class="task-details">
                                        <?php if (! empty($task->description)) : ?><div class="desc"><?php echo esc_html($task->description); ?></div><?php endif; ?>
                                        <div class="task-grid">
                                            <div><span class="k"><?php echo esc_html__('Assigned By', 'simple-task-management'); ?></span><?php echo esc_html(self::user_name((int) $task->created_by)); ?></div>
                                            <?php if ($show_assigned_to) : ?><div><span class="k"><?php echo esc_html__('Assigned To', 'simple-task-management'); ?></span><?php echo esc_html(self::user_name((int) $task->assigned_to)); ?></div><?php endif; ?>
                                            <div><span class="k"><?php echo esc_html__('Priority', 'simple-task-management'); ?></span><span class="stm-badge <?php echo esc_attr(self::priority_badge_class($task->priority)); ?>"><?php echo esc_html(isset($priorities[$task->priority]) ? $priorities[$task->priority] : $task->priority); ?></span></div>
                                            <div><span class="k"><?php echo esc_html__('Status', 'simple-task-management'); ?></span><span class="stm-badge <?php echo esc_attr($status_badge_class); ?>"><?php echo esc_html($status_label); ?></span></div>
                                            <div><span class="k"><?php echo esc_html__('Due', 'simple-task-management'); ?></span><?php echo esc_html($task->due_date ? $task->due_date : 'No due date'); ?></div>
                                            <div><span class="k"><?php echo esc_html__('Reward', 'simple-task-management'); ?></span><span class="points">+<?php echo esc_html((string) (int) $task->reward_points); ?></span></div>
                                        </div>
                                        <div class="task-actions">
                                            <button type="button" class="tiny view stmf-view-btn"
                                                data-title="<?php echo esc_attr($task->title); ?>"
                                                data-description="<?php echo esc_attr((string) $task->description); ?>"
                                                data-assignedby="<?php echo esc_attr(self::user_name((int) $task->created_by)); ?>"
                                                data-assignedto="<?php echo esc_attr(self::user_name((int) $task->assigned_to)); ?>"
                                                data-priority="<?php echo esc_attr(isset($priorities[$task->priority]) ? $priorities[$task->priority] : $task->priority); ?>"
                                                data-status="<?php echo esc_attr(isset($statuses[$task->status]) ? $statuses[$task->status] : $task->status); ?>"
                                                data-due="<?php echo esc_attr($task->due_date ? $task->due_date : 'No due date'); ?>"
                                                data-reward="<?php echo esc_attr((string) (int) $task->reward_points); ?>">
                                                <span class="dashicons dashicons-visibility"></span>
                                                <?php echo esc_html__('View', 'simple-task-management'); ?>
                                            </button>
                                            <?php
                                            $base_action_args_m = array('stm_return' => $base_return_url, 'task_id' => (int) $task->id);
                                            if ('todo' === $task->status) { $next_status_m = 'in_progress'; $next_label_m = __('Start', 'simple-task-management'); $next_icon_m = 'dashicons-controls-play'; }
                                            elseif ('in_progress' === $task->status) { $next_status_m = 'done'; $next_label_m = __('Complete', 'simple-task-management'); $next_icon_m = 'dashicons-yes-alt'; }
                                            else { $next_status_m = 'todo'; $next_label_m = __('Reopen', 'simple-task-management'); $next_icon_m = 'dashicons-update'; }
                                            $status_url_m = wp_nonce_url(add_query_arg(array_merge($base_action_args_m, array('action' => 'stm_update_status', 'status' => $next_status_m)), admin_url('admin-post.php')), 'stm_update_status');
                                            $delete_url_m = wp_nonce_url(add_query_arg(array_merge($base_action_args_m, array('action' => 'stm_delete_task')), admin_url('admin-post.php')), 'stm_delete_task');
                                            $edit_url_m = add_query_arg('edit_task', (int) $task->id, $base_return_url);
                                            ?>
                                            <?php if (self::current_user_can_edit_task_item($task)) : ?><a class="tiny edit" href="<?php echo esc_url($edit_url_m); ?>"><span class="dashicons dashicons-edit"></span><?php echo esc_html__('Edit', 'simple-task-management'); ?></a><?php endif; ?>
                                            <?php if (self::current_user_can_change_task_status_item($task)) : ?><a class="tiny status" href="<?php echo esc_url($status_url_m); ?>"><span class="dashicons <?php echo esc_attr($next_icon_m); ?>"></span><?php echo esc_html($next_label_m); ?></a><?php endif; ?>
                                            <?php if (self::current_user_can_delete_task_item($task)) : ?><a class="tiny delete" href="<?php echo esc_url($delete_url_m); ?>" onclick="return confirm('Delete this task?');"><span class="dashicons dashicons-trash"></span><?php echo esc_html__('Delete', 'simple-task-management'); ?></a><?php endif; ?>
                                        </div>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <?php if ($total_pages > 1) : ?>
                            <div class="stm-pagination">
                                <?php for ($page_num = 1; $page_num <= $total_pages; $page_num++) : ?>
                                    <?php
                                    $page_url = add_query_arg('stmf_page', $page_num, $frontend_pagination_base_url);
                                    $is_active_page = $page_num === $current_page;
                                    ?>
                                    <a class="stm-page-link <?php echo $is_active_page ? 'is-active' : ''; ?>" href="<?php echo esc_url($page_url); ?>">
                                        <?php echo esc_html((string) $page_num); ?>
                                    </a>
                                <?php endfor; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="stm-credit">Design By - <a href="https://amandubey.com" target="_blank" rel="noopener noreferrer">Aman Dubey</a></div>
            <?php if ($is_settings_manager) : ?>
            <dialog id="stmf-task-dialog">
                <div class="stm-dialog-head">
                    <strong><?php echo esc_html($editing_task ? __('Edit Task', 'simple-task-management') : __('Add New Task', 'simple-task-management')); ?></strong>
                    <button type="button" class="tiny" id="stmf-task-close"><?php echo esc_html__('Close', 'simple-task-management'); ?></button>
                </div>
                <div class="stm-dialog-body">
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="stm_save_task" />
                        <input type="hidden" name="task_id" value="<?php echo esc_attr($editing_task ? (int) $editing_task->id : 0); ?>" />
                        <input type="hidden" name="stm_return" value="<?php echo esc_attr($base_return_url); ?>" />
                        <?php wp_nonce_field('stm_save_task'); ?>
                        <p><input class="stm-input" name="title" required placeholder="<?php echo esc_attr__('Task title', 'simple-task-management'); ?>" value="<?php echo esc_attr($editing_task ? $editing_task->title : ''); ?>"></p>
                        <p><textarea class="stm-textarea stm-input" name="description" placeholder="<?php echo esc_attr__('Description', 'simple-task-management'); ?>"><?php echo esc_textarea($editing_task ? $editing_task->description : ''); ?></textarea></p>
                        <p><select class="stm-select stm-input" name="assigned_to"><option value="0"><?php echo esc_html__('Unassigned', 'simple-task-management'); ?></option><?php foreach ($assignable_users as $assignable_user) : ?><option value="<?php echo esc_attr((string) $assignable_user->ID); ?>" <?php selected($editing_task ? (int) $editing_task->assigned_to : 0, (int) $assignable_user->ID); ?>><?php echo esc_html($assignable_user->display_name); ?></option><?php endforeach; ?></select></p>
                        <p><input class="stm-input" name="due_date" type="date" value="<?php echo esc_attr($editing_task ? $editing_task->due_date : ''); ?>" <?php echo ! empty($settings['require_due_date']) ? 'required' : ''; ?>></p>
                        <p><select class="stm-select stm-input" name="priority"><?php foreach ($priorities as $priority_key => $priority_label) : ?><option value="<?php echo esc_attr($priority_key); ?>" <?php selected($editing_task ? $editing_task->priority : $settings['default_priority'], $priority_key); ?>><?php echo esc_html($priority_label); ?></option><?php endforeach; ?></select></p>
                        <p><input class="stm-input" type="number" min="0" name="reward_points" placeholder="<?php echo esc_attr__('Reward Points', 'simple-task-management'); ?>" value="<?php echo esc_attr($editing_task ? (string) $editing_task->reward_points : (string) self::default_reward_for_priority($settings['default_priority'])); ?>"></p>
                        <button type="submit"><?php echo esc_html($editing_task ? __('Update Task', 'simple-task-management') : __('Create Task', 'simple-task-management')); ?></button>
                    </form>
                </div>
            </dialog>
            <?php endif; ?>
            <dialog id="stmf-leader-dialog">
                <div class="stm-dialog-head">
                    <strong><?php echo esc_html__('Leaderboard', 'simple-task-management'); ?></strong>
                    <button type="button" class="tiny" id="stmf-leader-close"><?php echo esc_html__('Close', 'simple-task-management'); ?></button>
                </div>
                <div class="stm-dialog-body">
                    <ul class="leader">
                        <?php if (empty($leaderboard)) : ?>
                            <li><?php echo esc_html__('No points yet', 'simple-task-management'); ?></li>
                        <?php else : ?>
                            <?php foreach ($leaderboard as $index => $row_user) : ?>
                                <li><span><?php echo esc_html(self::medal_for_rank($index + 1) . ' ' . $row_user->display_name); ?></span><strong class="points"><?php echo esc_html((string) (int) get_user_meta($row_user->ID, self::USER_POINTS_META, true)); ?></strong></li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </dialog>
            <dialog id="stmf-view-dialog">
                <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px;border-bottom:1px solid #e2e8f0;">
                    <strong id="stmf-v-title"></strong>
                    <button type="button" class="tiny" id="stmf-v-close"><?php echo esc_html__('Close', 'simple-task-management'); ?></button>
                </div>
                <div style="padding:12px;">
                    <p><strong><?php echo esc_html__('Task To Do:', 'simple-task-management'); ?></strong></p>
                    <p id="stmf-v-desc"></p>
                </div>
            </dialog>
            <script>
                (function() {
                    var taskDialog = document.getElementById('stmf-task-dialog');
                    var openTaskBtn = document.getElementById('stmf-open-task-dialog');
                    var closeTaskBtn = document.getElementById('stmf-task-close');
                    if (taskDialog && openTaskBtn) {
                        openTaskBtn.addEventListener('click', function() {
                            if (taskDialog.showModal) { taskDialog.showModal(); }
                        });
                    }
                    if (taskDialog && closeTaskBtn) {
                        closeTaskBtn.addEventListener('click', function() { taskDialog.close(); });
                    }

                    var leaderDialog = document.getElementById('stmf-leader-dialog');
                    var openLeaderBtn = document.getElementById('stmf-open-leaderboard-dialog');
                    var closeLeaderBtn = document.getElementById('stmf-leader-close');
                    if (leaderDialog && openLeaderBtn) {
                        openLeaderBtn.addEventListener('click', function() {
                            if (leaderDialog.showModal) { leaderDialog.showModal(); }
                        });
                    }
                    if (leaderDialog && closeLeaderBtn) {
                        closeLeaderBtn.addEventListener('click', function() { leaderDialog.close(); });
                    }

                    <?php if ($editing_task && $is_settings_manager) : ?>
                    if (taskDialog && taskDialog.showModal) {
                        taskDialog.showModal();
                    }
                    <?php endif; ?>

                    var dialog = document.getElementById('stmf-view-dialog');
                    if (!dialog) { return; }
                    var closeBtn = document.getElementById('stmf-v-close');
                    var btns = document.querySelectorAll('.stmf-view-btn');
                    var showDetailsText = '<?php echo esc_js(__('Show details', 'simple-task-management')); ?>';
                    var hideDetailsText = '<?php echo esc_js(__('Hide details', 'simple-task-management')); ?>';
                    btns.forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            document.getElementById('stmf-v-title').textContent = btn.getAttribute('data-title') || '';
                            document.getElementById('stmf-v-desc').textContent = btn.getAttribute('data-description') || '';
                            if (dialog.showModal) { dialog.showModal(); }
                        });
                    });
                    if (closeBtn) {
                        closeBtn.addEventListener('click', function() { dialog.close(); });
                    }

                    var cardsWrap = document.querySelector('.task-cards');
                    if (cardsWrap) {
                        cardsWrap.addEventListener('click', function(e) {
                            var toggleBtn = e.target.closest('.stm-task-toggle');
                            if (!toggleBtn) {
                                return;
                            }
                            var card = toggleBtn.closest('.task-card');
                            if (!card) {
                                return;
                            }
                            var isOpen = card.classList.toggle('is-open');
                            toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
                            toggleBtn.textContent = isOpen ? hideDetailsText : showDetailsText;
                        });
                    }

                })();
                <?php if ($auto_refresh_enabled) : ?>
                (function() {
                    var ms = <?php echo (int) $auto_refresh_ms; ?>;
                    var onlyVisible = <?php echo $auto_refresh_only_visible ? 'true' : 'false'; ?>;
                    if (!ms || ms < 10000) {
                        ms = 60000;
                    }

                    function refreshUrl() {
                        try {
                            var u = new URL(window.location.href);
                            u.searchParams.set('stm_refresh', String(Date.now()));
                            return u.toString();
                        } catch (e) {
                            var href = window.location.href;
                            var cleaned = href.replace(/([?&])stm_refresh=[^&]*/g, '$1').replace(/[?&]$/, '');
                            var sep = cleaned.indexOf('?') === -1 ? '?' : '&';
                            return cleaned + sep + 'stm_refresh=' + Date.now();
                        }
                    }

                    window.setInterval(function() {
                        if (onlyVisible && document.hidden) {
                            return;
                        }
                        window.location.href = refreshUrl();
                    }, ms);
                })();
                <?php endif; ?>
            </script>
        </div>
        <?php

        return (string) ob_get_clean();
    }

    public static function render_admin_page() {
        if (! self::current_user_can_manage_tasks()) {
            wp_die(esc_html__('You are not allowed to access this page.', 'simple-task-management'));
        }

        $statuses         = self::allowed_statuses();
        $priorities       = self::allowed_priorities();
        $settings         = self::get_settings();
        $dashboard_title  = ! empty($settings['dashboard_title']) ? (string) $settings['dashboard_title'] : 'Daily Taks';
        $is_settings_manager = self::current_user_can_manage_settings();
        $assignable_users = self::get_assignable_users();
        $leaderboard      = self::get_leaderboard(10);
        $pending_overdue_admin = $is_settings_manager ? self::get_pending_overdue_for_review() : array();

        $editing_id = isset($_GET['edit_task']) ? absint($_GET['edit_task']) : 0;
        $task       = $editing_id ? self::get_task($editing_id) : null;

        if ($task && ! self::current_user_can_edit_task_item($task)) {
            self::redirect_with_notice('error', 'You are not allowed to edit this task.');
        }

        $status_filter = isset($_GET['status_filter']) ? sanitize_key(wp_unslash($_GET['status_filter'])) : '';
        $search_term   = isset($_GET['task_search']) ? sanitize_text_field(wp_unslash($_GET['task_search'])) : '';
        $assigned_user_filter = isset($_GET['assigned_user_filter']) ? absint($_GET['assigned_user_filter']) : 0;
        $show_admin_employee_filter = $is_settings_manager && ! empty($settings['admin_employee_filter_enabled']);
        if (! $show_admin_employee_filter) {
            $assigned_user_filter = 0;
        }
        $all_tasks = self::get_tasks($status_filter, $search_term, $assigned_user_filter);
        $per_page = max(1, (int) $settings['tasks_per_page']);
        $current_page = isset($_GET['stmb_page']) ? max(1, absint($_GET['stmb_page'])) : 1;
        $total_tasks = count($all_tasks);
        $total_pages = max(1, (int) ceil($total_tasks / $per_page));
        if ($current_page > $total_pages) {
            $current_page = $total_pages;
        }
        $tasks = array_slice($all_tasks, ($current_page - 1) * $per_page, $per_page);
        $backend_pagination_base_args = array(
            'page' => 'stm-task-manager',
            'task_search' => $search_term,
            'status_filter' => $status_filter,
        );
        if ($show_admin_employee_filter) {
            $backend_pagination_base_args['assigned_user_filter'] = $assigned_user_filter;
        }

        $notice_type = isset($_GET['stm_notice']) ? sanitize_key(wp_unslash($_GET['stm_notice'])) : '';
        $notice_msg  = isset($_GET['stm_msg']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['stm_msg']))) : '';

        $count_todo        = 0;
        $count_in_progress = 0;
        $count_done        = 0;

        foreach ($all_tasks as $item) {
            if ('todo' === $item->status) {
                $count_todo++;
            } elseif ('in_progress' === $item->status) {
                $count_in_progress++;
            } elseif ('done' === $item->status) {
                $count_done++;
            }
        }

        $my_points = (int) get_user_meta(get_current_user_id(), self::USER_POINTS_META, true);
        $auto_refresh_enabled = ! empty($settings['auto_refresh_enabled'])
            && ! empty($settings['auto_refresh_backend'])
            && self::auto_refresh_allowed_for_scope((string) $settings['auto_refresh_user_scope'], $is_settings_manager);
        $auto_refresh_only_visible = ! empty($settings['auto_refresh_only_visible']);
        $auto_refresh_ms = max(10, min(3600, (int) $settings['auto_refresh_interval'])) * 1000;
        $show_assigned_to = $is_settings_manager;

        ?>
        <div class="wrap">
            <style>
                .stm-main { max-width:1400px; }
                .stm-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; gap:10px; flex-wrap:wrap; }
                .stm-top-right { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
                .stm-title { margin:0; font-size:30px; color:#334155; font-weight:700; }
                .stm-top-link {
                    display:inline-flex;
                    align-items:center;
                    border:1px solid #bfdbfe;
                    background:#eff6ff;
                    color:#1d4ed8;
                    border-radius:10px;
                    padding:7px 12px;
                    text-decoration:none;
                    font-weight:600;
                    font-size:12px;
                }
                .stm-user-chip {
                    background:#f8fafc;
                    border:1px solid #dbeafe;
                    color:#1e3a8a;
                    border-radius:999px;
                    padding:8px 14px;
                    font-weight:600;
                }
                .stm-points-strong { color:#0f766e; font-weight:700; }

                .stm-metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin:10px 0 18px; }
                .stm-metric { border-radius:14px; padding:14px; border:1px solid #e2e8f0; position:relative; overflow:hidden; }
                .stm-metric::before {
                    content:"";
                    position:absolute;
                    right:-18px;
                    top:-18px;
                    width:94px;
                    height:94px;
                    border-radius:999px;
                    opacity:.92;
                    pointer-events:none;
                }
                .stm-metric::after {
                    content:"";
                    position:absolute;
                    right:18px;
                    top:18px;
                    width:32px;
                    height:32px;
                    opacity:.72;
                    background-repeat:no-repeat;
                    background-size:contain;
                    pointer-events:none;
                }
                .stm-metric-label { color:#475569; font-size:12px; text-transform:uppercase; letter-spacing:.04em; display:block; margin-bottom:6px; font-weight:600; }
                .stm-metric-value { font-size:30px; font-weight:800; color:#0f172a; line-height:1.1; }
                .stm-metric-icon { display:none; }
                .stm-card-todo { background:#f0f7ff; }
                .stm-card-progress { background:#fff8f1; }
                .stm-card-done { background:#f2fff7; }
                .stm-card-points { background:#f7f5ff; }
                .stm-card-todo::before { background:radial-gradient(circle at 30% 30%, rgba(37,99,235,.18) 0%, rgba(37,99,235,.08) 62%, rgba(37,99,235,0) 100%); }
                .stm-card-progress::before { background:radial-gradient(circle at 30% 30%, rgba(194,65,12,.18) 0%, rgba(194,65,12,.08) 62%, rgba(194,65,12,0) 100%); }
                .stm-card-done::before { background:radial-gradient(circle at 30% 30%, rgba(21,128,61,.18) 0%, rgba(21,128,61,.08) 62%, rgba(21,128,61,0) 100%); }
                .stm-card-points::before { background:radial-gradient(circle at 30% 30%, rgba(109,40,217,.18) 0%, rgba(109,40,217,.08) 62%, rgba(109,40,217,0) 100%); }
                .stm-card-todo::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232563eb' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='6' y='4' width='12' height='16' rx='2'/%3E%3Cpath d='M9 2h6v4H9z'/%3E%3Cpath d='M9 10h6M9 14h4'/%3E%3C/svg%3E"); }
                .stm-card-progress::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23c2410c' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M21 12a9 9 0 10-3 6.7'/%3E%3Cpath d='M21 4v8h-8'/%3E%3C/svg%3E"); }
                .stm-card-done::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2315803d' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='9'/%3E%3Cpath d='M8.5 12.5l2.2 2.2 4.8-4.8'/%3E%3C/svg%3E"); }
                .stm-card-points::after { background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%236d28d9' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='8' r='2.5'/%3E%3Cpath d='M8.5 20h7l1.2-4.5L12 13l-4.7 2.5z'/%3E%3Cpath d='M6 10l-2 2m14-2l2 2'/%3E%3C/svg%3E"); }
                .stm-admin-quick-actions { display:flex; gap:8px; flex-wrap:wrap; margin:0 0 14px; }
                .stm-admin-quick-actions .stm-btn { min-height:36px; }

                .stm-layout { display:grid; grid-template-columns:1fr; gap:18px; align-items:start; }
                .stm-layout > div:first-child { display:none; }
                .stm-card { background:#fff; border:1px solid #e2e8f0; border-radius:14px; box-shadow:0 1px 2px rgba(15,23,42,.04); }
                .stm-card-header { padding:14px 16px; border-bottom:1px solid #f1f5f9; font-weight:700; color:#334155; }
                .stm-card-body { padding:14px 16px; }
                .stm-form-row { margin-bottom:12px; }
                .stm-form-row label { display:block; margin-bottom:5px; font-weight:600; color:#334155; }
                .stm-grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:10px; }

                .stm-input,
                .stm-select,
                .stm-textarea,
                .stm-search {
                    width:100%;
                    min-height:38px;
                    border:1px solid #cbd5e1;
                    border-radius:10px;
                    padding:8px 10px;
                    box-sizing:border-box;
                    background:#fff;
                }

                .stm-textarea { min-height:96px; }

                .stm-btn {
                    display:inline-flex;
                    align-items:center;
                    gap:6px;
                    border-radius:10px;
                    padding:7px 12px;
                    text-decoration:none;
                    font-weight:600;
                    font-size:12px;
                    border:1px solid transparent;
                    cursor:pointer;
                }
                .stm-btn-primary { background:#2563eb; color:#fff; }
                .stm-btn-secondary { background:#fff; color:#334155; border-color:#cbd5e1; }
                .stm-btn-edit { background:#eef2ff; color:#3730a3; border-color:#c7d2fe; }
                .stm-btn-status { background:#fff7ed; color:#9a3412; border-color:#fed7aa; }
                .stm-btn-delete { background:#fef2f2; color:#b91c1c; border-color:#fecaca; }
                .stm-btn-view { background:#eff6ff; color:#1d4ed8; border-color:#bfdbfe; }
                .stm-action-group .action-icon {
                    position:relative;
                    width:34px;
                    min-width:34px;
                    height:34px;
                    padding:0;
                    justify-content:center;
                }
                .stm-action-group .action-icon::after {
                    content:attr(data-tip);
                    position:absolute;
                    left:50%;
                    bottom:calc(100% + 6px);
                    transform:translateX(-50%) translateY(4px);
                    background:#0f172a;
                    color:#fff;
                    font-size:11px;
                    line-height:1.2;
                    padding:5px 7px;
                    border-radius:6px;
                    white-space:nowrap;
                    opacity:0;
                    pointer-events:none;
                    transition:all .16s ease;
                    z-index:20;
                }
                .stm-action-group .action-icon:hover::after { opacity:1; transform:translateX(-50%) translateY(0); }

                .stm-filter-row { display:flex; gap:8px; align-items:center; margin-bottom:12px; flex-wrap:nowrap; }
                .stm-filter-row .stm-search { flex:1 1 auto; min-width:240px; }
                .stm-filter-row .stm-select { width:auto; min-width:160px; }
                .stm-filter-row .stm-btn { white-space:nowrap; }

                .stm-badge { display:inline-block; border-radius:999px; padding:3px 9px; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.03em; }
                .stm-badge-todo { background:#eaf2ff; color:#1d4ed8; }
                .stm-badge-progress { background:#fff3e8; color:#c2410c; }
                .stm-badge-done { background:#eafcf1; color:#15803d; }
                .stm-badge-low { background:#f8fafc; color:#475467; }
                .stm-badge-medium { background:#eff8ff; color:#175cd3; }
                .stm-badge-high { background:#fef2f2; color:#b42318; }

                .stm-meta { color:#64748b; font-size:12px; margin-top:4px; }
                .stm-points { color:#0f766e; font-weight:700; }

                .stm-table-wrap { overflow-x:auto; border:1px solid #dbe7f7; border-radius:12px; background:#fff; box-shadow:0 8px 24px rgba(15,23,42,.06); }
                .stm-table-wrap table.widefat { border:none; box-shadow:none; border-collapse:collapse; }
                .stm-table-wrap table.widefat thead th {
                    background:#f5f9ff;
                    border-bottom:1px solid #dbe7f7;
                    text-transform:uppercase;
                    letter-spacing:.02em;
                    font-size:12px;
                    color:#334155;
                }
                .stm-table-wrap table.widefat thead th:first-child { border-top-left-radius:12px; }
                .stm-table-wrap table.widefat thead th:last-child { border-top-right-radius:12px; }
                .stm-table-wrap table.widefat td,
                .stm-table-wrap table.widefat th {
                    padding:13px 12px;
                    border-left:none !important;
                    border-right:none !important;
                    box-shadow:none !important;
                }
                .stm-table-wrap table.widefat tbody td { border-bottom:1px solid #edf2fb !important; }
                .stm-table-wrap table.widefat tbody tr:nth-child(even) { background:#fbfdff; }
                .stm-table-wrap table.widefat tbody tr:hover { background:#ecf5ff; }
                .stm-action-group { display:flex; gap:6px; flex-wrap:wrap; }

                .stm-task-cards { display:none; }
                .stm-task-item {
                    border:1px solid #e2e8f0;
                    border-radius:12px;
                    padding:10px;
                    margin-bottom:10px;
                    background:#fff;
                }
                .stm-task-item h4 { margin:0 0 6px 0; font-size:15px; color:#334155; }
                .stm-task-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; font-size:13px; color:#475569; margin:8px 0; }
                .stm-k { color:#64748b; font-size:11px; text-transform:uppercase; }
                .stm-pagination { margin-top:10px; display:flex; gap:6px; flex-wrap:wrap; }
                .stm-page-link {
                    display:inline-flex; align-items:center; justify-content:center;
                    min-height:32px; min-width:32px; padding:4px 10px;
                    border:1px solid #cbd5e1; border-radius:8px; background:#fff; color:#334155;
                    text-decoration:none; font-size:12px; font-weight:700;
                }
                .stm-page-link.is-active { border-color:#2563eb; background:#eff6ff; color:#1d4ed8; }

                .stm-leader-list { margin:0; padding:0; list-style:none; }
                .stm-leader-item { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f1f5f9; }
                .stm-medal { font-size:16px; margin-right:6px; }

                dialog#stm-view-dialog {
                    border:none;
                    border-radius:12px;
                    width:min(560px, 92vw);
                    padding:0;
                }
                dialog.stm-admin-dialog {
                    border:none;
                    border-radius:12px;
                    width:min(640px, 94vw);
                    padding:0;
                }
                dialog.stm-admin-dialog::backdrop { background:rgba(15,23,42,.35); }
                #stm-view-dialog::backdrop { background:rgba(15,23,42,.35); }
                .stm-dialog-head { padding:14px 16px; border-bottom:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center; }
                .stm-dialog-body { padding:14px 16px; }

                @media (max-width: 1200px) {
                    .stm-layout { grid-template-columns:1fr; }
                    .stm-metrics { grid-template-columns:repeat(2,1fr); }
                }
                @media (max-width: 1024px) {
                    .stm-metrics { grid-template-columns:1fr; }
                    .stm-grid-2 { grid-template-columns:1fr; }
                    .stm-top { margin-bottom:16px; }
                    .stm-top-right { width:100%; justify-content:flex-start; flex-wrap:wrap; overflow:visible; }
                    .stm-user-chip { width:auto; border-radius:999px; flex:0 1 auto; }
                    .stm-filter-row { flex-wrap:wrap; }
                    .stm-filter-row .stm-search { width:100%; min-width:0; }
                    .stm-filter-row .stm-select { width:100%; min-width:0; }
                    .stm-filter-row .stm-btn { width:100%; justify-content:center; }
                    .stm-table-wrap { display:none; }
                    .stm-task-cards { display:block; }
                    .stm-task-item { width:100%; overflow:hidden; }
                    .stm-task-grid { grid-template-columns:1fr; }
                    .stm-action-group { width:100%; display:flex; gap:8px; flex-wrap:wrap; }
                    .stm-action-group .stm-btn { flex:1 1 calc(50% - 8px); justify-content:center; }
                }
                @media (max-width: 460px) {
                    .stm-action-group .stm-btn { flex:1 1 100%; }
                }
            </style>

            <?php if ($notice_type && $notice_msg) : ?>
                <div class="notice notice-<?php echo esc_attr('success' === $notice_type ? 'success' : 'error'); ?> is-dismissible">
                    <p><?php echo esc_html($notice_msg); ?></p>
                </div>
            <?php endif; ?>

            <main class="stm-main">
                <div class="stm-top">
                    <h1 class="stm-title"><?php echo esc_html($dashboard_title); ?></h1>
                    <div class="stm-top-right">
                        <a class="stm-top-link" href="<?php echo esc_url(self::frontend_tasks_home_url()); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Tasks Home', 'simple-task-management'); ?></a>
                        <a class="stm-top-link" href="<?php echo esc_url(add_query_arg('stm_refresh', time(), admin_url('admin.php?page=stm-task-manager'))); ?>"><?php echo esc_html__('Refresh', 'simple-task-management'); ?></a>
                        <div class="stm-user-chip">
                            <span class="dashicons dashicons-admin-users" style="font-size:16px;line-height:1.1;"></span>
                            <?php echo esc_html(wp_get_current_user()->display_name); ?>
                            · <span class="stm-points-strong"><?php echo esc_html__('Points:', 'simple-task-management'); ?> <?php echo esc_html((string) $my_points); ?></span>
                        </div>
                    </div>
                </div>

                <div class="stm-metrics">
                    <div class="stm-metric stm-card-todo">
                        <span class="stm-metric-icon dashicons dashicons-clipboard"></span>
                        <span class="stm-metric-label"><?php echo esc_html__('To Do', 'simple-task-management'); ?></span>
                        <span class="stm-metric-value"><?php echo esc_html((string) $count_todo); ?></span>
                    </div>
                    <div class="stm-metric stm-card-progress">
                        <span class="stm-metric-icon dashicons dashicons-update"></span>
                        <span class="stm-metric-label"><?php echo esc_html__('In Progress', 'simple-task-management'); ?></span>
                        <span class="stm-metric-value"><?php echo esc_html((string) $count_in_progress); ?></span>
                    </div>
                    <div class="stm-metric stm-card-done">
                        <span class="stm-metric-icon dashicons dashicons-yes-alt"></span>
                        <span class="stm-metric-label"><?php echo esc_html__('Completed', 'simple-task-management'); ?></span>
                        <span class="stm-metric-value"><?php echo esc_html((string) $count_done); ?></span>
                    </div>
                    <div class="stm-metric stm-card-points">
                        <span class="stm-metric-icon dashicons dashicons-awards"></span>
                        <span class="stm-metric-label"><?php echo esc_html__('My Reward Points', 'simple-task-management'); ?></span>
                        <span class="stm-metric-value"><?php echo esc_html((string) $my_points); ?></span>
                    </div>
                </div>

                <div class="stm-admin-quick-actions">
                    <?php if ($is_settings_manager) : ?>
                        <button type="button" class="stm-btn stm-btn-primary" id="stm-open-task-dialog">
                            <span class="dashicons dashicons-plus-alt2" style="font-size:14px;line-height:1.2;"></span>
                            <?php echo esc_html($task ? __('Edit Task', 'simple-task-management') : __('Add New Task', 'simple-task-management')); ?>
                        </button>
                    <?php endif; ?>
                    <button type="button" class="stm-btn stm-btn-secondary" id="stm-open-leaderboard-dialog">
                        <span class="dashicons dashicons-awards" style="font-size:14px;line-height:1.2;"></span>
                        <?php echo esc_html__('Leaderboard', 'simple-task-management'); ?>
                    </button>
                </div>

                <?php if (! empty($pending_overdue_admin)) : ?>
                    <div class="stm-card" style="margin-bottom:14px;">
                        <div class="stm-card-header"><?php echo esc_html__('Pending Overdue Reason Reviews', 'simple-task-management'); ?></div>
                        <div class="stm-card-body">
                            <?php foreach ($pending_overdue_admin as $pending_item) : ?>
                                <div style="border:1px solid #fde68a;background:#fffbeb;border-radius:10px;padding:10px;margin-bottom:8px;">
                                    <strong><?php echo esc_html($pending_item->title); ?></strong>
                                    <div style="font-size:12px;color:#475569;margin-top:4px;">
                                        <?php echo esc_html__('Assigned By:', 'simple-task-management'); ?> <?php echo esc_html(self::user_name((int) $pending_item->created_by)); ?>
                                        · <?php echo esc_html__('Assigned To:', 'simple-task-management'); ?> <?php echo esc_html(self::user_name((int) $pending_item->assigned_to)); ?>
                                    </div>
                                    <div style="margin:4px 0 8px;"><?php echo esc_html__('Reason:', 'simple-task-management'); ?> <?php echo esc_html((string) $pending_item->overdue_reason); ?></div>
                                    <?php
                                    $accept_u = wp_nonce_url(
                                        add_query_arg(
                                            array(
                                                'action'  => 'stm_review_overdue_reason',
                                                'task_id' => (int) $pending_item->id,
                                                'decision'=> 'accept',
                                            ),
                                            admin_url('admin-post.php')
                                        ),
                                        'stm_review_overdue_reason'
                                    );
                                    $reject_u = wp_nonce_url(
                                        add_query_arg(
                                            array(
                                                'action'  => 'stm_review_overdue_reason',
                                                'task_id' => (int) $pending_item->id,
                                                'decision'=> 'reject',
                                            ),
                                            admin_url('admin-post.php')
                                        ),
                                        'stm_review_overdue_reason'
                                    );
                                    ?>
                                    <a class="stm-btn stm-btn-status" href="<?php echo esc_url($accept_u); ?>">✅ <?php echo esc_html__('Accept', 'simple-task-management'); ?></a>
                                    <a class="stm-btn stm-btn-delete" href="<?php echo esc_url($reject_u); ?>">❌ <?php echo esc_html__('Reject', 'simple-task-management'); ?></a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="stm-layout">
                    <div>
                        <?php if ($is_settings_manager) : ?>
                        <div class="stm-card" style="margin-bottom:14px;">
                            <div class="stm-card-header"><?php echo esc_html($task ? 'Edit Task' : 'Add New Task'); ?></div>
                            <div class="stm-card-body">
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                                    <input type="hidden" name="action" value="stm_save_task" />
                                    <input type="hidden" name="task_id" value="<?php echo esc_attr($task ? (int) $task->id : 0); ?>" />
                                    <?php wp_nonce_field('stm_save_task'); ?>

                                    <div class="stm-form-row">
                                        <label for="stm-title"><?php echo esc_html__('Task Title', 'simple-task-management'); ?></label>
                                        <input id="stm-title" name="title" type="text" class="stm-input" required value="<?php echo esc_attr($task ? $task->title : ''); ?>" />
                                    </div>

                                    <div class="stm-form-row">
                                        <label for="stm-description"><?php echo esc_html__('Description', 'simple-task-management'); ?></label>
                                        <textarea id="stm-description" name="description" class="stm-textarea"><?php echo esc_textarea($task ? $task->description : ''); ?></textarea>
                                    </div>

                                    <div class="stm-grid-2">
                                        <div class="stm-form-row">
                                            <label for="stm-assigned-to"><?php echo esc_html__('Assign To', 'simple-task-management'); ?></label>
                                            <select id="stm-assigned-to" name="assigned_to" class="stm-select">
                                                <option value="0"><?php echo esc_html__('Unassigned', 'simple-task-management'); ?></option>
                                                <?php foreach ($assignable_users as $assignable_user) : ?>
                                                    <option value="<?php echo esc_attr((string) $assignable_user->ID); ?>" <?php selected($task ? (int) $task->assigned_to : 0, (int) $assignable_user->ID); ?>>
                                                        <?php echo esc_html($assignable_user->display_name); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="stm-form-row">
                                            <label for="stm-due-date"><?php echo esc_html__('Due Date', 'simple-task-management'); ?></label>
                                            <input id="stm-due-date" name="due_date" type="date" class="stm-input" value="<?php echo esc_attr($task ? $task->due_date : ''); ?>" <?php echo ! empty($settings['require_due_date']) ? 'required' : ''; ?> />
                                        </div>
                                    </div>

                                    <div class="stm-grid-2">
                                        <div class="stm-form-row">
                                            <label for="stm-priority"><?php echo esc_html__('Priority', 'simple-task-management'); ?></label>
                                            <select id="stm-priority" name="priority" class="stm-select">
                                                <?php foreach ($priorities as $priority_key => $priority_label) : ?>
                                                    <option value="<?php echo esc_attr($priority_key); ?>" <?php selected($task ? $task->priority : $settings['default_priority'], $priority_key); ?>>
                                                        <?php echo esc_html($priority_label); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="stm-form-row">
                                            <label for="stm-reward-points"><?php echo esc_html__('Reward Points', 'simple-task-management'); ?></label>
                                            <input id="stm-reward-points" name="reward_points" type="number" min="0" class="stm-input" value="<?php echo esc_attr($task ? (string) $task->reward_points : (string) self::default_reward_for_priority($settings['default_priority'])); ?>" />
                                        </div>
                                    </div>

                                    <button type="submit" class="stm-btn stm-btn-primary">
                                        <span class="dashicons dashicons-plus-alt2" style="font-size:14px;line-height:1.2;"></span>
                                        <?php echo esc_html($task ? __('Update Task', 'simple-task-management') : __('Create Task', 'simple-task-management')); ?>
                                    </button>
                                    <?php if ($task) : ?>
                                        <a class="stm-btn stm-btn-secondary" href="<?php echo esc_url(admin_url('admin.php?page=stm-task-manager')); ?>"><?php echo esc_html__('Cancel', 'simple-task-management'); ?></a>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="stm-card">
                            <div class="stm-card-header"><?php echo esc_html__('Leaderboard', 'simple-task-management'); ?></div>
                            <div class="stm-card-body">
                                <?php if (empty($leaderboard)) : ?>
                                    <p><?php echo esc_html__('No points earned yet.', 'simple-task-management'); ?></p>
                                <?php else : ?>
                                    <ul class="stm-leader-list">
                                        <?php foreach ($leaderboard as $index => $row_user) : ?>
                                            <?php $rank = $index + 1; ?>
                                            <li class="stm-leader-item">
                                                <span>
                                                    <span class="stm-medal"><?php echo esc_html(self::medal_for_rank($rank)); ?></span>
                                                    <?php if ($rank > 3) : ?>
                                                        <?php echo esc_html('#' . $rank); ?>
                                                    <?php endif; ?>
                                                    <?php echo esc_html($row_user->display_name); ?>
                                                </span>
                                                <strong class="stm-points"><?php echo esc_html((string) (int) get_user_meta($row_user->ID, self::USER_POINTS_META, true)); ?></strong>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="stm-card">
                        <div class="stm-card-header"><?php echo esc_html__('Active Tasks', 'simple-task-management'); ?></div>
                        <div class="stm-card-body">
                            <form method="get" class="stm-filter-row">
                                <input type="hidden" name="page" value="stm-task-manager" />
                                <input type="search" name="task_search" class="stm-search" value="<?php echo esc_attr($search_term); ?>" placeholder="<?php echo esc_attr__('Search task title or description...', 'simple-task-management'); ?>" />
                                <select name="status_filter" class="stm-select" style="width:auto;min-width:160px;">
                                    <option value=""><?php echo esc_html__('All Status', 'simple-task-management'); ?></option>
                                    <?php foreach ($statuses as $status_key => $status_label) : ?>
                                        <option value="<?php echo esc_attr($status_key); ?>" <?php selected($status_filter, $status_key); ?>><?php echo esc_html($status_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($show_admin_employee_filter) : ?>
                                    <select name="assigned_user_filter" class="stm-select" style="width:auto;min-width:200px;">
                                        <option value="0"><?php echo esc_html__('All Employees', 'simple-task-management'); ?></option>
                                        <?php foreach ($assignable_users as $assignable_user) : ?>
                                            <option value="<?php echo esc_attr((string) $assignable_user->ID); ?>" <?php selected($assigned_user_filter, (int) $assignable_user->ID); ?>>
                                                <?php echo esc_html($assignable_user->display_name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php endif; ?>
                                <button class="stm-btn stm-btn-primary" type="submit">
                                    <span class="dashicons dashicons-search" style="font-size:14px;line-height:1.2;"></span>
                                    <?php echo esc_html__('Apply', 'simple-task-management'); ?>
                                </button>
                            </form>

                            <div class="stm-table-wrap">
                                <table class="widefat striped">
                                    <thead>
                                        <tr>
                                            <th><?php echo esc_html__('Task Name', 'simple-task-management'); ?></th>
                                            <th><?php echo esc_html__('Assigned By', 'simple-task-management'); ?></th>
                                            <?php if ($show_assigned_to) : ?><th><?php echo esc_html__('Assigned To', 'simple-task-management'); ?></th><?php endif; ?>
                                            <th><?php echo esc_html__('Priority', 'simple-task-management'); ?></th>
                                            <th><?php echo esc_html__('Status', 'simple-task-management'); ?></th>
                                            <th><?php echo esc_html__('Due Date', 'simple-task-management'); ?></th>
                                            <th><?php echo esc_html__('Reward', 'simple-task-management'); ?></th>
                                            <th><?php echo esc_html__('Actions', 'simple-task-management'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($tasks)) : ?>
                                            <tr><td colspan="<?php echo esc_attr($show_assigned_to ? '8' : '7'); ?>"><?php echo esc_html__('No tasks found.', 'simple-task-management'); ?></td></tr>
                                        <?php else : ?>
                                            <?php foreach ($tasks as $item) : ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo esc_html($item->title); ?></strong>
                                                        <?php if (! empty($item->description)) : ?>
                                                            <div class="stm-meta"><?php echo esc_html(self::short_text($item->description, 80)); ?></div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo esc_html(self::user_name((int) $item->created_by)); ?></td>
                                                    <?php if ($show_assigned_to) : ?><td><?php echo esc_html(self::user_name((int) $item->assigned_to)); ?></td><?php endif; ?>
                                                    <td><span class="stm-badge <?php echo esc_attr(self::priority_badge_class($item->priority)); ?>"><?php echo esc_html(isset($priorities[$item->priority]) ? $priorities[$item->priority] : $item->priority); ?></span></td>
                                                    <td><span class="stm-badge <?php echo esc_attr(self::status_badge_class($item->status)); ?>"><?php echo esc_html(isset($statuses[$item->status]) ? $statuses[$item->status] : $item->status); ?></span></td>
                                                    <td>
                                                        <?php echo esc_html($item->due_date ? $item->due_date : 'No due date'); ?>
                                                        <div class="stm-meta"><?php echo esc_html(mysql2date('Y-m-d H:i', $item->updated_at)); ?></div>
                                                    </td>
                                                    <td><span class="stm-points">+<?php echo esc_html((string) (int) $item->reward_points); ?></span></td>
                                                    <td>
                                                        <div class="stm-action-group">
                                                            <button type="button" class="stm-btn stm-btn-view action-icon stm-view-btn"
                                                                data-tip="<?php echo esc_attr__('View Task', 'simple-task-management'); ?>"
                                                                title="<?php echo esc_attr__('View Task', 'simple-task-management'); ?>"
                                                                aria-label="<?php echo esc_attr__('View Task', 'simple-task-management'); ?>"
                                                                data-title="<?php echo esc_attr($item->title); ?>"
                                                                data-description="<?php echo esc_attr((string) $item->description); ?>"
                                                                data-assignedby="<?php echo esc_attr(self::user_name((int) $item->created_by)); ?>"
                                                                data-assignedto="<?php echo esc_attr(self::user_name((int) $item->assigned_to)); ?>"
                                                                data-priority="<?php echo esc_attr(isset($priorities[$item->priority]) ? $priorities[$item->priority] : $item->priority); ?>"
                                                                data-status="<?php echo esc_attr(isset($statuses[$item->status]) ? $statuses[$item->status] : $item->status); ?>"
                                                                data-due="<?php echo esc_attr($item->due_date ? $item->due_date : 'No due date'); ?>"
                                                                data-reward="<?php echo esc_attr((string) (int) $item->reward_points); ?>">
                                                                <span class="dashicons dashicons-visibility" style="font-size:14px;line-height:1.2;"></span>
                                                            </button>

                                                            <?php if (self::current_user_can_edit_task_item($item)) : ?>
                                                                <a class="stm-btn stm-btn-edit action-icon" data-tip="<?php echo esc_attr__('Edit Task', 'simple-task-management'); ?>" title="<?php echo esc_attr__('Edit Task', 'simple-task-management'); ?>" aria-label="<?php echo esc_attr__('Edit Task', 'simple-task-management'); ?>" href="<?php echo esc_url(add_query_arg(array('page' => 'stm-task-manager', 'edit_task' => (int) $item->id), admin_url('admin.php'))); ?>">
                                                                    <span class="dashicons dashicons-edit" style="font-size:14px;line-height:1.2;"></span>
                                                                </a>
                                                            <?php endif; ?>

                                                            <?php if (self::current_user_can_view_task_item($item)) : ?>
                                                                <?php
                                                                if ('todo' === $item->status) {
                                                                    $next_status = 'in_progress';
                                                                    $next_label  = __('Start', 'simple-task-management');
                                                                    $next_icon   = 'dashicons-controls-play';
                                                                } elseif ('in_progress' === $item->status) {
                                                                    $next_status = 'done';
                                                                    $next_label  = __('Complete', 'simple-task-management');
                                                                    $next_icon   = 'dashicons-yes-alt';
                                                                } else {
                                                                    $next_status = 'todo';
                                                                    $next_label  = __('Reopen', 'simple-task-management');
                                                                    $next_icon   = 'dashicons-update';
                                                                }

                                                                $status_url = wp_nonce_url(
                                                                    add_query_arg(
                                                                        array(
                                                                            'action'  => 'stm_update_status',
                                                                            'task_id' => (int) $item->id,
                                                                            'status'  => $next_status,
                                                                        ),
                                                                        admin_url('admin-post.php')
                                                                    ),
                                                                    'stm_update_status'
                                                                );
                                                                ?>
                                                                <a class="stm-btn stm-btn-status action-icon" data-tip="<?php echo esc_attr($next_label); ?>" title="<?php echo esc_attr($next_label); ?>" aria-label="<?php echo esc_attr($next_label); ?>" href="<?php echo esc_url($status_url); ?>">
                                                                    <span class="dashicons <?php echo esc_attr($next_icon); ?>" style="font-size:14px;line-height:1.2;"></span>
                                                                </a>
                                                            <?php endif; ?>

                                                            <?php if (self::current_user_can_delete_task_item($item)) : ?>
                                                                <?php
                                                                $delete_url = wp_nonce_url(
                                                                    add_query_arg(
                                                                        array(
                                                                            'action'  => 'stm_delete_task',
                                                                            'task_id' => (int) $item->id,
                                                                        ),
                                                                        admin_url('admin-post.php')
                                                                    ),
                                                                    'stm_delete_task'
                                                                );
                                                                ?>
                                                                <a class="stm-btn stm-btn-delete action-icon" data-tip="<?php echo esc_attr__('Delete Task', 'simple-task-management'); ?>" title="<?php echo esc_attr__('Delete Task', 'simple-task-management'); ?>" aria-label="<?php echo esc_attr__('Delete Task', 'simple-task-management'); ?>" href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Delete this task?');">
                                                                    <span class="dashicons dashicons-trash" style="font-size:14px;line-height:1.2;"></span>
                                                                </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="stm-task-cards">
                                <?php if (empty($tasks)) : ?>
                                    <p><?php echo esc_html__('No tasks found.', 'simple-task-management'); ?></p>
                                <?php else : ?>
                                    <?php foreach ($tasks as $item) : ?>
                                        <div class="stm-task-item">
                                            <h4><?php echo esc_html($item->title); ?></h4>
                                            <?php if (! empty($item->description)) : ?>
                                                <div class="stm-meta"><?php echo esc_html($item->description); ?></div>
                                            <?php endif; ?>

                                            <div class="stm-task-grid">
                                                <div><span class="stm-k"><?php echo esc_html__('Assigned By', 'simple-task-management'); ?></span><br><?php echo esc_html(self::user_name((int) $item->created_by)); ?></div>
                                                <?php if ($show_assigned_to) : ?><div><span class="stm-k"><?php echo esc_html__('Assigned To', 'simple-task-management'); ?></span><br><?php echo esc_html(self::user_name((int) $item->assigned_to)); ?></div><?php endif; ?>
                                                <div><span class="stm-k"><?php echo esc_html__('Reward', 'simple-task-management'); ?></span><br><span class="stm-points">+<?php echo esc_html((string) (int) $item->reward_points); ?></span></div>
                                                <div><span class="stm-k"><?php echo esc_html__('Priority', 'simple-task-management'); ?></span><br><span class="stm-badge <?php echo esc_attr(self::priority_badge_class($item->priority)); ?>"><?php echo esc_html(isset($priorities[$item->priority]) ? $priorities[$item->priority] : $item->priority); ?></span></div>
                                                <div><span class="stm-k"><?php echo esc_html__('Status', 'simple-task-management'); ?></span><br><span class="stm-badge <?php echo esc_attr(self::status_badge_class($item->status)); ?>"><?php echo esc_html(isset($statuses[$item->status]) ? $statuses[$item->status] : $item->status); ?></span></div>
                                                <div><span class="stm-k"><?php echo esc_html__('Due Date', 'simple-task-management'); ?></span><br><?php echo esc_html($item->due_date ? $item->due_date : 'No due date'); ?></div>
                                                <div><span class="stm-k"><?php echo esc_html__('Updated', 'simple-task-management'); ?></span><br><?php echo esc_html(mysql2date('Y-m-d H:i', $item->updated_at)); ?></div>
                                            </div>

                                            <div class="stm-action-group">
                                                <button type="button" class="stm-btn stm-btn-view stm-view-btn"
                                                    data-title="<?php echo esc_attr($item->title); ?>"
                                                    data-description="<?php echo esc_attr((string) $item->description); ?>"
                                                    data-assignedby="<?php echo esc_attr(self::user_name((int) $item->created_by)); ?>"
                                                    data-assignedto="<?php echo esc_attr(self::user_name((int) $item->assigned_to)); ?>"
                                                    data-priority="<?php echo esc_attr(isset($priorities[$item->priority]) ? $priorities[$item->priority] : $item->priority); ?>"
                                                    data-status="<?php echo esc_attr(isset($statuses[$item->status]) ? $statuses[$item->status] : $item->status); ?>"
                                                    data-due="<?php echo esc_attr($item->due_date ? $item->due_date : 'No due date'); ?>"
                                                    data-reward="<?php echo esc_attr((string) (int) $item->reward_points); ?>">
                                                    <?php echo esc_html__('View', 'simple-task-management'); ?>
                                                </button>

                                                <?php if (self::current_user_can_edit_task_item($item)) : ?>
                                                    <a class="stm-btn stm-btn-edit" href="<?php echo esc_url(add_query_arg(array('page' => 'stm-task-manager', 'edit_task' => (int) $item->id), admin_url('admin.php'))); ?>"><?php echo esc_html__('Edit', 'simple-task-management'); ?></a>
                                                <?php endif; ?>

                                                <?php if (self::current_user_can_delete_task_item($item)) : ?>
                                                    <?php $delete_url_m = wp_nonce_url(add_query_arg(array('action' => 'stm_delete_task', 'task_id' => (int) $item->id), admin_url('admin-post.php')), 'stm_delete_task'); ?>
                                                    <a class="stm-btn stm-btn-delete" href="<?php echo esc_url($delete_url_m); ?>" onclick="return confirm('Delete this task?');"><?php echo esc_html__('Delete', 'simple-task-management'); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <?php if ($total_pages > 1) : ?>
                                <div class="stm-pagination">
                                    <?php for ($page_num = 1; $page_num <= $total_pages; $page_num++) : ?>
                                        <?php
                                        $page_url = add_query_arg(array_merge($backend_pagination_base_args, array('stmb_page' => $page_num)), admin_url('admin.php'));
                                        $is_active_page = $page_num === $current_page;
                                        ?>
                                        <a class="stm-page-link <?php echo $is_active_page ? 'is-active' : ''; ?>" href="<?php echo esc_url($page_url); ?>">
                                            <?php echo esc_html((string) $page_num); ?>
                                        </a>
                                    <?php endfor; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>

            <?php if ($is_settings_manager) : ?>
            <dialog id="stm-task-dialog" class="stm-admin-dialog">
                <div class="stm-dialog-head">
                    <strong><?php echo esc_html($task ? __('Edit Task', 'simple-task-management') : __('Add New Task', 'simple-task-management')); ?></strong>
                    <button type="button" class="stm-btn stm-btn-secondary" id="stm-close-task-dialog"><?php echo esc_html__('Close', 'simple-task-management'); ?></button>
                </div>
                <div class="stm-dialog-body">
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="stm_save_task" />
                        <input type="hidden" name="task_id" value="<?php echo esc_attr($task ? (int) $task->id : 0); ?>" />
                        <?php wp_nonce_field('stm_save_task'); ?>
                        <div class="stm-form-row">
                            <label><?php echo esc_html__('Task Title', 'simple-task-management'); ?></label>
                            <input name="title" type="text" class="stm-input" required value="<?php echo esc_attr($task ? $task->title : ''); ?>" />
                        </div>
                        <div class="stm-form-row">
                            <label><?php echo esc_html__('Description', 'simple-task-management'); ?></label>
                            <textarea name="description" class="stm-textarea"><?php echo esc_textarea($task ? $task->description : ''); ?></textarea>
                        </div>
                        <div class="stm-grid-2">
                            <div class="stm-form-row">
                                <label><?php echo esc_html__('Assign To', 'simple-task-management'); ?></label>
                                <select name="assigned_to" class="stm-select">
                                    <option value="0"><?php echo esc_html__('Unassigned', 'simple-task-management'); ?></option>
                                    <?php foreach ($assignable_users as $assignable_user) : ?>
                                        <option value="<?php echo esc_attr((string) $assignable_user->ID); ?>" <?php selected($task ? (int) $task->assigned_to : 0, (int) $assignable_user->ID); ?>>
                                            <?php echo esc_html($assignable_user->display_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="stm-form-row">
                                <label><?php echo esc_html__('Due Date', 'simple-task-management'); ?></label>
                                <input name="due_date" type="date" class="stm-input" value="<?php echo esc_attr($task ? $task->due_date : ''); ?>" <?php echo ! empty($settings['require_due_date']) ? 'required' : ''; ?> />
                            </div>
                        </div>
                        <div class="stm-grid-2">
                            <div class="stm-form-row">
                                <label><?php echo esc_html__('Priority', 'simple-task-management'); ?></label>
                                <select name="priority" class="stm-select">
                                    <?php foreach ($priorities as $priority_key => $priority_label) : ?>
                                        <option value="<?php echo esc_attr($priority_key); ?>" <?php selected($task ? $task->priority : $settings['default_priority'], $priority_key); ?>><?php echo esc_html($priority_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="stm-form-row">
                                <label><?php echo esc_html__('Reward Points', 'simple-task-management'); ?></label>
                                <input name="reward_points" type="number" min="0" class="stm-input" value="<?php echo esc_attr($task ? (string) $task->reward_points : (string) self::default_reward_for_priority($settings['default_priority'])); ?>" />
                            </div>
                        </div>
                        <button type="submit" class="stm-btn stm-btn-primary">
                            <span class="dashicons dashicons-plus-alt2" style="font-size:14px;line-height:1.2;"></span>
                            <?php echo esc_html($task ? __('Update Task', 'simple-task-management') : __('Create Task', 'simple-task-management')); ?>
                        </button>
                    </form>
                </div>
            </dialog>
            <?php endif; ?>
            <dialog id="stm-leaderboard-dialog" class="stm-admin-dialog">
                <div class="stm-dialog-head">
                    <strong><?php echo esc_html__('Leaderboard', 'simple-task-management'); ?></strong>
                    <button type="button" class="stm-btn stm-btn-secondary" id="stm-close-leaderboard-dialog"><?php echo esc_html__('Close', 'simple-task-management'); ?></button>
                </div>
                <div class="stm-dialog-body">
                    <?php if (empty($leaderboard)) : ?>
                        <p><?php echo esc_html__('No points earned yet.', 'simple-task-management'); ?></p>
                    <?php else : ?>
                        <ul class="stm-leader-list">
                            <?php foreach ($leaderboard as $index => $row_user) : ?>
                                <?php $rank = $index + 1; ?>
                                <li class="stm-leader-item">
                                    <span>
                                        <span class="stm-medal"><?php echo esc_html(self::medal_for_rank($rank)); ?></span>
                                        <?php if ($rank > 3) : ?><?php echo esc_html('#' . $rank); ?><?php endif; ?>
                                        <?php echo esc_html($row_user->display_name); ?>
                                    </span>
                                    <strong class="stm-points"><?php echo esc_html((string) (int) get_user_meta($row_user->ID, self::USER_POINTS_META, true)); ?></strong>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </dialog>

            <dialog id="stm-view-dialog">
                <div class="stm-dialog-head">
                    <strong id="stm-view-title"></strong>
                    <button type="button" class="stm-btn stm-btn-secondary" id="stm-close-dialog"><?php echo esc_html__('Close', 'simple-task-management'); ?></button>
                </div>
                <div class="stm-dialog-body">
                    <p id="stm-view-description"></p>
                    <p><strong><?php echo esc_html__('Assigned By:', 'simple-task-management'); ?></strong> <span id="stm-view-assignedby"></span></p>
                    <?php if ($show_assigned_to) : ?><p><strong><?php echo esc_html__('Assigned To:', 'simple-task-management'); ?></strong> <span id="stm-view-assignedto"></span></p><?php endif; ?>
                    <p><strong><?php echo esc_html__('Priority:', 'simple-task-management'); ?></strong> <span id="stm-view-priority"></span></p>
                    <p><strong><?php echo esc_html__('Status:', 'simple-task-management'); ?></strong> <span id="stm-view-status"></span></p>
                    <p><strong><?php echo esc_html__('Due Date:', 'simple-task-management'); ?></strong> <span id="stm-view-due"></span></p>
                    <p><strong><?php echo esc_html__('Reward Points:', 'simple-task-management'); ?></strong> +<span id="stm-view-reward"></span></p>
                </div>
            </dialog>

            <script>
                (function() {
                    var taskDialog = document.getElementById('stm-task-dialog');
                    var openTaskBtn = document.getElementById('stm-open-task-dialog');
                    var closeTaskBtn = document.getElementById('stm-close-task-dialog');
                    if (taskDialog && openTaskBtn) {
                        openTaskBtn.addEventListener('click', function() {
                            if (taskDialog.showModal) { taskDialog.showModal(); }
                        });
                    }
                    if (taskDialog && closeTaskBtn) {
                        closeTaskBtn.addEventListener('click', function() { taskDialog.close(); });
                    }

                    var leaderDialog = document.getElementById('stm-leaderboard-dialog');
                    var openLeaderBtn = document.getElementById('stm-open-leaderboard-dialog');
                    var closeLeaderBtn = document.getElementById('stm-close-leaderboard-dialog');
                    if (leaderDialog && openLeaderBtn) {
                        openLeaderBtn.addEventListener('click', function() {
                            if (leaderDialog.showModal) { leaderDialog.showModal(); }
                        });
                    }
                    if (leaderDialog && closeLeaderBtn) {
                        closeLeaderBtn.addEventListener('click', function() { leaderDialog.close(); });
                    }

                    <?php if ($task && $is_settings_manager) : ?>
                    if (taskDialog && taskDialog.showModal) {
                        taskDialog.showModal();
                    }
                    <?php endif; ?>

                    var dialog = document.getElementById('stm-view-dialog');
                    if (!dialog) {
                        return;
                    }

                    var buttons = document.querySelectorAll('.stm-view-btn');
                    var closeBtn = document.getElementById('stm-close-dialog');

                    buttons.forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            document.getElementById('stm-view-title').textContent = btn.getAttribute('data-title') || '';
                            document.getElementById('stm-view-description').textContent = btn.getAttribute('data-description') || '';
                            document.getElementById('stm-view-assignedby').textContent = btn.getAttribute('data-assignedby') || '';
                            var assignedToAdminEl = document.getElementById('stm-view-assignedto');
                            if (assignedToAdminEl) {
                                assignedToAdminEl.textContent = btn.getAttribute('data-assignedto') || '';
                            }
                            document.getElementById('stm-view-priority').textContent = btn.getAttribute('data-priority') || '';
                            document.getElementById('stm-view-status').textContent = btn.getAttribute('data-status') || '';
                            document.getElementById('stm-view-due').textContent = btn.getAttribute('data-due') || '';
                            document.getElementById('stm-view-reward').textContent = btn.getAttribute('data-reward') || '0';

                            if (typeof dialog.showModal === 'function') {
                                dialog.showModal();
                            }
                        });
                    });

                    if (closeBtn) {
                        closeBtn.addEventListener('click', function() {
                            dialog.close();
                        });
                    }
                })();
                <?php if ($auto_refresh_enabled) : ?>
                (function() {
                    var ms = <?php echo (int) $auto_refresh_ms; ?>;
                    var onlyVisible = <?php echo $auto_refresh_only_visible ? 'true' : 'false'; ?>;
                    if (!ms || ms < 10000) {
                        ms = 60000;
                    }

                    function refreshUrl() {
                        try {
                            var u = new URL(window.location.href);
                            u.searchParams.set('stm_refresh', String(Date.now()));
                            return u.toString();
                        } catch (e) {
                            var href = window.location.href;
                            var cleaned = href.replace(/([?&])stm_refresh=[^&]*/g, '$1').replace(/[?&]$/, '');
                            var sep = cleaned.indexOf('?') === -1 ? '?' : '&';
                            return cleaned + sep + 'stm_refresh=' + Date.now();
                        }
                    }

                    window.setInterval(function() {
                        if (onlyVisible && document.hidden) {
                            return;
                        }
                        window.location.href = refreshUrl();
                    }, ms);
                })();
                <?php endif; ?>
            </script>
        </div>
        <?php
    }

    public static function render_settings_page() {
        if (! self::current_user_can_manage_settings()) {
            wp_die(esc_html__('You are not allowed to access settings.', 'simple-task-management'));
        }

        $settings   = self::get_settings();
        $roles      = self::available_roles();
        $statuses   = self::allowed_statuses();
        $priorities = self::allowed_priorities();
        $pages      = get_pages(array('sort_column' => 'post_title', 'sort_order' => 'ASC'));
        $leaderboard_users = self::get_leaderboard(200);
        $assignable_users = self::get_assignable_users();
        $slack_command_endpoint = rest_url('stm/v1/slack-command');
        $slack_guide_pdf_url = plugins_url('Slack-Integration-Guide.pdf', __FILE__);
        $slack_guide_text_url = plugins_url('Slack-Integration-Guide-Clean.txt', __FILE__);

        $notice_type = isset($_GET['stm_notice']) ? sanitize_key(wp_unslash($_GET['stm_notice'])) : '';
        $notice_msg  = isset($_GET['stm_msg']) ? sanitize_text_field(rawurldecode(wp_unslash($_GET['stm_msg']))) : '';

        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Task Manager Settings', 'simple-task-management'); ?></h1>

            <?php if ($notice_type && $notice_msg) : ?>
                <div class="notice notice-<?php echo esc_attr('success' === $notice_type ? 'success' : 'error'); ?> is-dismissible">
                    <p><?php echo esc_html($notice_msg); ?></p>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="stm_save_settings" />
                <?php wp_nonce_field('stm_save_settings'); ?>

                <h2><?php echo esc_html__('Access & Visibility', 'simple-task-management'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Task Access Roles', 'simple-task-management'); ?></th>
                        <td>
                            <?php foreach ($roles as $role_key => $role_label) : ?>
                                <label style="display:block;margin-bottom:4px;">
                                    <input type="checkbox" name="access_roles[]" value="<?php echo esc_attr($role_key); ?>" <?php checked(in_array($role_key, $settings['access_roles'], true)); ?> />
                                    <?php echo esc_html($role_label . ' (' . $role_key . ')'); ?>
                                </label>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Settings Access Roles', 'simple-task-management'); ?></th>
                        <td>
                            <?php foreach ($roles as $role_key => $role_label) : ?>
                                <label style="display:block;margin-bottom:4px;">
                                    <input type="checkbox" name="settings_roles[]" value="<?php echo esc_attr($role_key); ?>" <?php checked(in_array($role_key, $settings['settings_roles'], true)); ?> />
                                    <?php echo esc_html($role_label . ' (' . $role_key . ')'); ?>
                                </label>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-visibility"><?php echo esc_html__('Task Visibility', 'simple-task-management'); ?></label></th>
                        <td>
                            <select id="stm-visibility" name="visibility">
                                <option value="all" <?php selected($settings['visibility'], 'all'); ?>><?php echo esc_html__('Show all tasks', 'simple-task-management'); ?></option>
                                <option value="own" <?php selected($settings['visibility'], 'own'); ?>><?php echo esc_html__('Show only created/assigned tasks (except settings managers)', 'simple-task-management'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Employees See Own Tasks Only', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="employee_own_tasks_only" value="1" <?php checked(! empty($settings['employee_own_tasks_only'])); ?> />
                                <?php echo esc_html__('Non admin/editor users can only see tasks assigned to them or created by them.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                </table>

                <h2><?php echo esc_html__('Frontend Dashboard', 'simple-task-management'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Frontend Dashboard', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="frontend_enabled" value="1" <?php checked(! empty($settings['frontend_enabled'])); ?> />
                                <?php echo esc_html__('Allow selected roles to use dashboard shortcode on frontend.', 'simple-task-management'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('Use shortcode: [stm_frontend_dashboard]', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Frontend Roles', 'simple-task-management'); ?></th>
                        <td>
                            <?php foreach ($roles as $role_key => $role_label) : ?>
                                <label style="display:block;margin-bottom:4px;">
                                    <input type="checkbox" name="frontend_roles[]" value="<?php echo esc_attr($role_key); ?>" <?php checked(in_array($role_key, $settings['frontend_roles'], true)); ?> />
                                    <?php echo esc_html($role_label . ' (' . $role_key . ')'); ?>
                                </label>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-frontend-page-id"><?php echo esc_html__('Frontend Dashboard Page', 'simple-task-management'); ?></label></th>
                        <td>
                            <select id="stm-frontend-page-id" name="frontend_page_id">
                                <option value="0"><?php echo esc_html__('Select a page', 'simple-task-management'); ?></option>
                                <?php foreach ($pages as $page) : ?>
                                    <option value="<?php echo esc_attr((string) $page->ID); ?>" <?php selected((int) $settings['frontend_page_id'], (int) $page->ID); ?>>
                                        <?php echo esc_html($page->post_title . ' (#' . $page->ID . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-frontend-tasks-home-url"><?php echo esc_html__('Tasks Home URL', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-frontend-tasks-home-url" type="url" name="frontend_tasks_home_url" value="<?php echo esc_attr((string) $settings['frontend_tasks_home_url']); ?>" class="regular-text" placeholder="https://example.com/tasks/" />
                            <p class="description"><?php echo esc_html__('Optional. Used for Tasks Home button and forced user redirects. If empty, Frontend Dashboard Page URL is used.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-frontend-login-url"><?php echo esc_html__('Login Page URL', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-frontend-login-url" type="url" name="frontend_login_url" value="<?php echo esc_attr((string) $settings['frontend_login_url']); ?>" class="regular-text" placeholder="https://example.com/login/" />
                            <p class="description"><?php echo esc_html__('Optional. Used for frontend "Login To Continue" button. If empty, WordPress default login URL is used.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-frontend-login-redirect-param"><?php echo esc_html__('Login Redirect Parameter', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-frontend-login-redirect-param" type="text" name="frontend_login_redirect_param" value="<?php echo esc_attr((string) $settings['frontend_login_redirect_param']); ?>" class="regular-text" placeholder="redirect_to" />
                            <p class="description"><?php echo esc_html__('Query parameter name used by your login page for redirect target. Default: redirect_to', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-frontend-logout-redirect-url"><?php echo esc_html__('Logout Redirect URL', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-frontend-logout-redirect-url" type="url" name="frontend_logout_redirect_url" value="<?php echo esc_attr((string) $settings['frontend_logout_redirect_url']); ?>" class="regular-text" placeholder="https://example.com/logged-out/" />
                            <p class="description"><?php echo esc_html__('Optional. If set, users will be redirected to this URL after logout.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-guest-login-title"><?php echo esc_html__('Guest Login Title', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-guest-login-title" type="text" name="guest_login_title" value="<?php echo esc_attr((string) $settings['guest_login_title']); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-guest-login-subtitle"><?php echo esc_html__('Guest Login Subtitle', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-guest-login-subtitle" type="text" name="guest_login_subtitle" value="<?php echo esc_attr((string) $settings['guest_login_subtitle']); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-guest-login-button-text"><?php echo esc_html__('Login Button Text', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-guest-login-button-text" type="text" name="guest_login_button_text" value="<?php echo esc_attr((string) $settings['guest_login_button_text']); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-guest-login-note"><?php echo esc_html__('Guest Login Note', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-guest-login-note" type="text" name="guest_login_note" value="<?php echo esc_attr((string) $settings['guest_login_note']); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Login Button Style', 'simple-task-management'); ?></th>
                        <td>
                            <label for="stm-guest-login-btn-start" style="margin-right:12px;">
                                <?php echo esc_html__('Gradient Start', 'simple-task-management'); ?>
                                <input id="stm-guest-login-btn-start" type="color" name="guest_login_button_color_start" value="<?php echo esc_attr((string) $settings['guest_login_button_color_start']); ?>" />
                            </label>
                            <label for="stm-guest-login-btn-end" style="margin-right:12px;">
                                <?php echo esc_html__('Gradient End', 'simple-task-management'); ?>
                                <input id="stm-guest-login-btn-end" type="color" name="guest_login_button_color_end" value="<?php echo esc_attr((string) $settings['guest_login_button_color_end']); ?>" />
                            </label>
                            <label for="stm-guest-login-btn-text" style="margin-right:12px;">
                                <?php echo esc_html__('Text Color', 'simple-task-management'); ?>
                                <input id="stm-guest-login-btn-text" type="color" name="guest_login_button_text_color" value="<?php echo esc_attr((string) $settings['guest_login_button_text_color']); ?>" />
                            </label>
                            <label for="stm-guest-login-btn-radius">
                                <?php echo esc_html__('Radius', 'simple-task-management'); ?>
                                <input id="stm-guest-login-btn-radius" type="number" min="0" max="30" step="1" name="guest_login_button_radius" value="<?php echo esc_attr((string) (int) $settings['guest_login_button_radius']); ?>" style="width:84px;" />
                            </label>
                            <p class="description"><?php echo esc_html__('Customize the frontend guest login button style.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Redirect After Login', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="frontend_redirect" value="1" <?php checked(! empty($settings['frontend_redirect'])); ?> />
                                <?php echo esc_html__('Redirect selected frontend roles to the frontend dashboard page after login.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-dashboard-title"><?php echo esc_html__('Dashboard Title', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-dashboard-title" type="text" name="dashboard_title" value="<?php echo esc_attr((string) $settings['dashboard_title']); ?>" class="regular-text" />
                            <p class="description"><?php echo esc_html__('Custom title shown on frontend and backend task dashboards.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Force Tasks Page Only', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="frontend_force_tasks_only" value="1" <?php checked(! empty($settings['frontend_force_tasks_only'])); ?> />
                                <?php echo esc_html__('Force selected frontend roles to always land on tasks page and block WordPress dashboard access (except settings managers).', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Employee Task Filter', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="admin_employee_filter_enabled" value="1" <?php checked(! empty($settings['admin_employee_filter_enabled'])); ?> />
                                <?php echo esc_html__('Show employee-name filter for admin/editor task tables (backend and frontend dashboard).', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Auto Refresh', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="auto_refresh_enabled" value="1" <?php checked(! empty($settings['auto_refresh_enabled'])); ?> />
                                <?php echo esc_html__('Auto-refresh task dashboards for latest updates.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Auto Refresh On', 'simple-task-management'); ?></th>
                        <td>
                            <label style="display:block;margin-bottom:4px;">
                                <input type="checkbox" name="auto_refresh_frontend" value="1" <?php checked(! empty($settings['auto_refresh_frontend'])); ?> />
                                <?php echo esc_html__('Frontend dashboard', 'simple-task-management'); ?>
                            </label>
                            <label style="display:block;">
                                <input type="checkbox" name="auto_refresh_backend" value="1" <?php checked(! empty($settings['auto_refresh_backend'])); ?> />
                                <?php echo esc_html__('Backend dashboard', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-auto-refresh-user-scope"><?php echo esc_html__('Auto Refresh User Condition', 'simple-task-management'); ?></label></th>
                        <td>
                            <select id="stm-auto-refresh-user-scope" name="auto_refresh_user_scope">
                                <option value="all" <?php selected($settings['auto_refresh_user_scope'], 'all'); ?>><?php echo esc_html__('All users', 'simple-task-management'); ?></option>
                                <option value="admin_editor_only" <?php selected($settings['auto_refresh_user_scope'], 'admin_editor_only'); ?>><?php echo esc_html__('Admin/Editor only', 'simple-task-management'); ?></option>
                                <option value="users_only" <?php selected($settings['auto_refresh_user_scope'], 'users_only'); ?>><?php echo esc_html__('Non admin/editor users only', 'simple-task-management'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Refresh Only When Tab Is Active', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="auto_refresh_only_visible" value="1" <?php checked(! empty($settings['auto_refresh_only_visible'])); ?> />
                                <?php echo esc_html__('Skip auto refresh when browser tab is in background.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-auto-refresh-interval"><?php echo esc_html__('Refresh Interval (seconds)', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-auto-refresh-interval" type="number" min="10" max="3600" name="auto_refresh_interval" value="<?php echo esc_attr((string) $settings['auto_refresh_interval']); ?>" />
                            <p class="description"><?php echo esc_html__('Recommended: 30 to 120 seconds.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-tasks-per-page"><?php echo esc_html__('Tasks Per Page', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-tasks-per-page" type="number" min="1" max="100" name="tasks_per_page" value="<?php echo esc_attr((string) $settings['tasks_per_page']); ?>" />
                            <p class="description"><?php echo esc_html__('Controls pagination size on frontend and backend task lists.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                </table>

                <h2><?php echo esc_html__('Slack Integration', 'simple-task-management'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Slack Integration', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="slack_enabled" value="1" <?php checked(! empty($settings['slack_enabled'])); ?> />
                                <?php echo esc_html__('Allow Slack channel task creation and assignment notifications.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-slack-command-endpoint"><?php echo esc_html__('Slack Command Endpoint', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-slack-command-endpoint" type="text" readonly class="regular-text code" value="<?php echo esc_attr($slack_command_endpoint); ?>" />
                            <p class="description"><?php echo esc_html__('Use this URL in your Slack Slash Command request URL.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Integration Guide', 'simple-task-management'); ?></th>
                        <td>
                            <a class="button button-secondary" href="<?php echo esc_url($slack_guide_pdf_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Open Slack Guide (PDF)', 'simple-task-management'); ?></a>
                            <a class="button button-link" href="<?php echo esc_url($slack_guide_text_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Open Text Version', 'simple-task-management'); ?></a>
                            <p class="description"><?php echo esc_html__('Guide files are bundled with this plugin package.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-slack-signing-secret"><?php echo esc_html__('Slack Signing Secret', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-slack-signing-secret" type="text" name="slack_signing_secret" value="<?php echo esc_attr((string) $settings['slack_signing_secret']); ?>" class="regular-text" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-slack-bot-token"><?php echo esc_html__('Slack Bot Token', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-slack-bot-token" type="text" name="slack_bot_token" value="<?php echo esc_attr((string) $settings['slack_bot_token']); ?>" class="regular-text" />
                            <p class="description"><?php echo esc_html__('Required for posting assignment notifications. Recommended bot scopes: chat:write, im:write.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-slack-channel-id"><?php echo esc_html__('Slack Channel ID', 'simple-task-management'); ?></label></th>
                        <td>
                            <input id="stm-slack-channel-id" type="text" name="slack_channel_id" value="<?php echo esc_attr((string) $settings['slack_channel_id']); ?>" class="regular-text" />
                            <p class="description"><?php echo esc_html__('Example: C0123456789. Restricts command channel and sets notification destination.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Allow Task Create From Slack Command', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="slack_allow_create_from_command" value="1" <?php checked(! empty($settings['slack_allow_create_from_command'])); ?> />
                                <?php echo esc_html__('Create tasks from Slack slash command requests.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Notify On Assignment', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="slack_notify_on_assign" value="1" <?php checked(! empty($settings['slack_notify_on_assign'])); ?> />
                                <?php echo esc_html__('Send Slack channel notification when a task is assigned.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Notify Assigned User In DM', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="slack_notify_on_assign_dm" value="1" <?php checked(! empty($settings['slack_notify_on_assign_dm'])); ?> />
                                <?php echo esc_html__('Send direct bot message to assigned user chat when task is assigned (requires user mapping).', 'simple-task-management'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('If DM fails, add im:write scope in Slack app and reinstall the app.', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('User Mapping (WordPress -> Slack User ID)', 'simple-task-management'); ?></th>
                        <td>
                            <?php foreach ($assignable_users as $assignable_user) : ?>
                                <?php $mapped_id = isset($settings['slack_user_map'][(int) $assignable_user->ID]) ? (string) $settings['slack_user_map'][(int) $assignable_user->ID] : ''; ?>
                                <label style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
                                    <span style="min-width:180px;"><?php echo esc_html($assignable_user->display_name . ' (#' . $assignable_user->ID . ')'); ?></span>
                                    <input type="text" name="slack_user_map[<?php echo esc_attr((string) (int) $assignable_user->ID); ?>]" value="<?php echo esc_attr($mapped_id); ?>" placeholder="U012ABCDEF" />
                                </label>
                            <?php endforeach; ?>
                            <p class="description"><?php echo esc_html__('Slash command format: @username|Task title|Description|due:YYYY-MM-DD|priority:high|reward:20', 'simple-task-management'); ?></p>
                        </td>
                    </tr>
                </table>

                <h2><?php echo esc_html__('Task Permissions', 'simple-task-management'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Allow User Edit', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="allow_user_edit" value="1" <?php checked(! empty($settings['allow_user_edit'])); ?> />
                                <?php echo esc_html__('Allow non-settings users to edit tasks.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Allow User Delete', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="allow_user_delete" value="1" <?php checked(! empty($settings['allow_user_delete'])); ?> />
                                <?php echo esc_html__('Allow non-settings users to delete tasks.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                </table>

                <h2><?php echo esc_html__('Task Defaults', 'simple-task-management'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="stm-default-status"><?php echo esc_html__('Default New Task Status', 'simple-task-management'); ?></label></th>
                        <td>
                            <select id="stm-default-status" name="default_status">
                                <?php foreach ($statuses as $status_key => $status_label) : ?>
                                    <option value="<?php echo esc_attr($status_key); ?>" <?php selected($settings['default_status'], $status_key); ?>><?php echo esc_html($status_label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-default-priority"><?php echo esc_html__('Default New Task Priority', 'simple-task-management'); ?></label></th>
                        <td>
                            <select id="stm-default-priority" name="default_priority">
                                <?php foreach ($priorities as $priority_key => $priority_label) : ?>
                                    <option value="<?php echo esc_attr($priority_key); ?>" <?php selected($settings['default_priority'], $priority_key); ?>><?php echo esc_html($priority_label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Require Due Date', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="require_due_date" value="1" <?php checked(! empty($settings['require_due_date'])); ?> />
                                <?php echo esc_html__('Make due date mandatory for all tasks.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                </table>

                <h2><?php echo esc_html__('Rewards', 'simple-task-management'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Rewards', 'simple-task-management'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="rewards_enabled" value="1" <?php checked(! empty($settings['rewards_enabled'])); ?> />
                                <?php echo esc_html__('Award points when task is completed.', 'simple-task-management'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="stm-reward-award-mode"><?php echo esc_html__('Award Mode', 'simple-task-management'); ?></label></th>
                        <td>
                            <select id="stm-reward-award-mode" name="reward_award_mode">
                                <option value="once" <?php selected($settings['reward_award_mode'], 'once'); ?>><?php echo esc_html__('Once per task', 'simple-task-management'); ?></option>
                                <option value="repeat" <?php selected($settings['reward_award_mode'], 'repeat'); ?>><?php echo esc_html__('Every completion (re-open allowed)', 'simple-task-management'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Points by Priority', 'simple-task-management'); ?></th>
                        <td>
                            <label><?php echo esc_html__('Low', 'simple-task-management'); ?> <input type="number" min="0" name="reward_low" value="<?php echo esc_attr((string) $settings['reward_low']); ?>" /></label>
                            &nbsp;&nbsp;
                            <label><?php echo esc_html__('Medium', 'simple-task-management'); ?> <input type="number" min="0" name="reward_medium" value="<?php echo esc_attr((string) $settings['reward_medium']); ?>" /></label>
                            &nbsp;&nbsp;
                            <label><?php echo esc_html__('High', 'simple-task-management'); ?> <input type="number" min="0" name="reward_high" value="<?php echo esc_attr((string) $settings['reward_high']); ?>" /></label>
                        </td>
                    </tr>
                </table>

                <?php submit_button(__('Save Settings', 'simple-task-management')); ?>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=stm-task-manager')); ?>"><?php echo esc_html__('Back to Tasks', 'simple-task-management'); ?></a>
            </form>

            <hr style="margin:24px 0;" />
            <h2><?php echo esc_html__('Leaderboard Management', 'simple-task-management'); ?></h2>
            <p><?php echo esc_html__('Reset all points, remove a single user from leaderboard, or manually set user points.', 'simple-task-management'); ?></p>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php echo esc_html__('Reset All Points', 'simple-task-management'); ?></th>
                    <td>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;">
                            <input type="hidden" name="action" value="stm_manage_leaderboard" />
                            <input type="hidden" name="operation" value="reset_all" />
                            <?php wp_nonce_field('stm_manage_leaderboard'); ?>
                            <button type="submit" class="button button-secondary" onclick="return confirm('Reset points for all users?');"><?php echo esc_html__('Reset Leaderboard', 'simple-task-management'); ?></button>
                        </form>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Remove User', 'simple-task-management'); ?></th>
                    <td>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                            <input type="hidden" name="action" value="stm_manage_leaderboard" />
                            <input type="hidden" name="operation" value="remove_user" />
                            <?php wp_nonce_field('stm_manage_leaderboard'); ?>
                            <select name="user_id" required>
                                <option value=""><?php echo esc_html__('Select user from leaderboard', 'simple-task-management'); ?></option>
                                <?php foreach ($leaderboard_users as $lb_user) : ?>
                                    <option value="<?php echo esc_attr((string) $lb_user->ID); ?>">
                                        <?php echo esc_html($lb_user->display_name . ' (' . (int) get_user_meta($lb_user->ID, self::USER_POINTS_META, true) . ' pts)'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="button button-secondary" onclick="return confirm('Remove this user from leaderboard?');"><?php echo esc_html__('Remove User', 'simple-task-management'); ?></button>
                        </form>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Set User Points', 'simple-task-management'); ?></th>
                    <td>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                            <input type="hidden" name="action" value="stm_manage_leaderboard" />
                            <input type="hidden" name="operation" value="set_points" />
                            <?php wp_nonce_field('stm_manage_leaderboard'); ?>
                            <select name="user_id" required>
                                <option value=""><?php echo esc_html__('Select user', 'simple-task-management'); ?></option>
                                <?php foreach ($assignable_users as $assignable_user) : ?>
                                    <option value="<?php echo esc_attr((string) $assignable_user->ID); ?>">
                                        <?php echo esc_html($assignable_user->display_name . ' (' . (int) get_user_meta($assignable_user->ID, self::USER_POINTS_META, true) . ' pts)'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" min="0" name="points" value="0" required />
                            <button type="submit" class="button button-primary"><?php echo esc_html__('Update Points', 'simple-task-management'); ?></button>
                        </form>
                    </td>
                </tr>
            </table>

            <hr style="margin:24px 0;" />
            <h2><?php echo esc_html__('Task Data Tools', 'simple-task-management'); ?></h2>
            <p><?php echo esc_html__('Reset all tasks or export task data in table format.', 'simple-task-management'); ?></p>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php echo esc_html__('Reset Tasks', 'simple-task-management'); ?></th>
                    <td>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;">
                            <input type="hidden" name="action" value="stm_task_data_tools" />
                            <input type="hidden" name="operation" value="reset_tasks" />
                            <?php wp_nonce_field('stm_task_data_tools'); ?>
                            <button type="submit" class="button button-secondary" onclick="return confirm('Reset all tasks? This cannot be undone.');"><?php echo esc_html__('Reset All Tasks', 'simple-task-management'); ?></button>
                        </form>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Export Tasks', 'simple-task-management'); ?></th>
                    <td>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                            <input type="hidden" name="action" value="stm_task_data_tools" />
                            <input type="hidden" name="operation" value="export_tasks" />
                            <?php wp_nonce_field('stm_task_data_tools'); ?>
                            <select name="export_format">
                                <option value="csv"><?php echo esc_html__('CSV', 'simple-task-management'); ?></option>
                                <option value="xlsx"><?php echo esc_html__('Excel (.xls)', 'simple-task-management'); ?></option>
                                <option value="pdf"><?php echo esc_html__('PDF Ready (HTML Table)', 'simple-task-management'); ?></option>
                            </select>
                            <button type="submit" class="button button-primary"><?php echo esc_html__('Download Export', 'simple-task-management'); ?></button>
                        </form>
                        <p class="description"><?php echo esc_html__('PDF Ready exports a print-friendly table file that can be saved as PDF from browser print dialog.', 'simple-task-management'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        <?php
    }
}

STM_Simple_Task_Management::init();
