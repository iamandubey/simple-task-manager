# Slack Integration Guide (Simple Task Management v1.8.0)

## 1. What you can do
- Create tasks from Slack using a slash command.
- Auto-assign tasks to mapped WordPress users.
- Send Slack notification when a task is assigned.
- Works on Slack Free plan.

## 2. Prerequisites
- WordPress site is live over HTTPS.
- Plugin version `1.8.0` installed and active.
- Admin access to:
  - WordPress admin panel
  - Slack workspace/app settings

## 3. WordPress first setup
1. Go to `WordPress Admin -> Task Manager -> Settings`.
2. Open the **Slack Integration** section.
3. Enable:
   - `Enable Slack Integration`
   - `Allow Task Create From Slack Command`
   - `Notify On Assignment` (recommended)
4. Keep this page open; you will paste Slack values here.
5. Copy the **Slack Command Endpoint** shown there.

Example endpoint format:
- `https://yourdomain.com/wp-json/stm/v1/slack-command`

## 4. Create Slack app
1. Open: https://api.slack.com/apps
2. Click **Create New App**.
3. Choose **From scratch**.
4. Enter app name (example: `Task Manager Bot`) and select your workspace.

## 5. Add Slash Command
1. In your app settings, open **Slash Commands**.
2. Click **Create New Command**.
3. Suggested command: `/taskassign`
4. Set **Request URL** to your WordPress endpoint:
   - `https://yourdomain.com/wp-json/stm/v1/slack-command`
5. Add short description and usage hint.
6. Save.

## 6. Enable bot token for notifications
1. In Slack app, open **OAuth & Permissions**.
2. Under **Bot Token Scopes**, add:
   - `chat:write`
3. Click **Install to Workspace** (or Reinstall if prompted).
4. Copy the **Bot User OAuth Token** (`xoxb-...`).

## 7. Get Signing Secret
1. In Slack app, open **Basic Information**.
2. In **App Credentials**, copy **Signing Secret**.

## 8. Get Channel ID
1. Open Slack web client.
2. Open your tasks channel.
3. Channel ID is in URL, like `C0123456789`.
4. Optional: you can also use a private channel if the app is invited.

## 9. Fill plugin Slack settings
Back in `Task Manager -> Settings -> Slack Integration`:
1. Paste **Slack Signing Secret**.
2. Paste **Slack Bot Token** (`xoxb-...`).
3. Enter **Slack Channel ID** (`C...`).
4. Save settings.

## 10. Map users (very important)
In **User Mapping (WordPress -> Slack User ID)**:
1. For each WordPress user, paste Slack User ID (`U...`) in their row.
2. Save settings.

How to get Slack User ID:
- Open user profile in Slack and copy member ID (starts with `U`).
- Or use mention format and inspect ID from Slack tools.

## 11. Command format to create task
Use this format in Slack:

`@username|Task title|Description|due:YYYY-MM-DD|priority:high|reward:20`

Notes:
- `@username` can be Slack mention or mapped username.
- `priority` allowed: `low`, `medium`, `high`.
- `due` and `reward` are optional but recommended.
- If reward not provided, plugin default reward is used.

Example:

`@aman|Prepare monthly report|Collect data and submit summary|due:2026-03-10|priority:high|reward:30`

## 12. What happens after command
- Plugin validates Slack signature.
- Plugin checks allowed channel (if channel ID is set).
- Plugin resolves assignee via mapping.
- Task is created in WordPress.
- Assignment notification is posted in Slack channel.
- Assignee is mentioned (if mapping exists).

## 13. Troubleshooting
### A) "Invalid Slack signature"
- Recheck Signing Secret in plugin settings.
- Ensure endpoint URL is exactly correct.
- Ensure request is coming directly from Slack.

### B) "This command is not allowed in this channel"
- Command used in wrong channel.
- Update `Slack Channel ID` or run command in configured channel.

### C) "Assignee not mapped"
- Add Slack User ID (`U...`) for that WordPress user in mapping table.

### D) Notifications not posting
- Verify bot token starts with `xoxb-`.
- Ensure `chat:write` scope added.
- Reinstall app after scope changes.
- Ensure app is invited to the target channel.

### E) Endpoint not reachable
- WordPress site must be publicly accessible over HTTPS.
- Check firewall/security plugins blocking `/wp-json/`.

## 14. Security best practices
- Keep Signing Secret and Bot Token private.
- Rotate tokens if leaked.
- Restrict to one channel via Channel ID.
- Keep WordPress and plugin updated.

## 15. Important links (official)
- Slack Apps: https://api.slack.com/apps
- Slash Commands: https://api.slack.com/interactivity/slash-commands
- Verify Slack requests: https://api.slack.com/authentication/verifying-requests-from-slack
- chat.postMessage API: https://api.slack.com/methods/chat.postMessage
- OAuth & tokens: https://api.slack.com/authentication/oauth-v2
- Slack scopes: https://api.slack.com/scopes
- WordPress REST API: https://developer.wordpress.org/rest-api/

## 16. Quick checklist
- [ ] Plugin v1.8.0 active
- [ ] Slack integration enabled in settings
- [ ] Slash command created
- [ ] Endpoint URL set
- [ ] Signing Secret set
- [ ] Bot Token set
- [ ] Channel ID set
- [ ] User mapping completed
- [ ] Test command successful
